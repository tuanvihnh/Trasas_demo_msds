from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from typing import List, Literal, Optional
from app.db.session import get_db
from app.models.models import Appendix
from app.models.models import Regulation
from app.schemas.schemas import AppendixCreate, AppendixUpdate, AppendixOut
from app.services.appendix import to_out
from app.utils.resolve import resolve_regulation_id
from app.utils.response import conflict, not_found, ok
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import or_, asc, desc, text

router = APIRouter()

# ========== LIST ==========
@router.get("/", summary="List appendices")
def list_appendices(
    db: Session = Depends(get_db),
    q: Optional[str] = None,
    title: Optional[str] = None,
    regulation_id: Optional[int] = None,
    regulation: Optional[str] = None,
    content: Optional[str] = None,
    note: Optional[str] = None,
    law_text: Optional[str] = None,
    status: Optional[int] = None,
    created_by: Optional[str] = None,
    updated_by: Optional[str] = None,
    created_at: Optional[str] = None,
    updated_at: Optional[str] = None,
    page: Optional[int] = Query(1, ge=1),
    size: Optional[int] = Query(50, ge=1),
    sort_field: Literal["id", "title", "content", "note", "law_text", "regulation", "regulation_id", "status", "created_at", "updated_at"] = Query("id"),
    sort_order: Literal["asc", "desc"] = Query("asc"),
):
    """Lấy danh sách appendix với phân trang và lọc.
    - Có thể lọc theo nhiều trường: q (tìm trong title, content, note, law_text, regulation_text, regulation_id), title, regulation_id, regulation (theo code của regulation), content, note, law_text, status, created_by, updated_by, created_at (theo ngày), updated_at (theo ngày).
    - Mặc định page=1, size=50.
    - Mặc định sort_field=id, sort_order=asc.
    - Trả về danh sách appendix.
    """
    qry = db.query(Appendix).options(joinedload(Appendix.regulation))



    if q:
        like = f"%{q}%"
        qry = qry.filter(or_(
                             Appendix.title.ilike(like),
                             Appendix.content.ilike(like),
                                Appendix.note.ilike(like),
                                Appendix.law_text.ilike(like),
                                Appendix.status.ilike(like),
                                Appendix.regulation_text.ilike(like),
                                Appendix.regulation_id.ilike(like),
                                Appendix.id.ilike(like),
                                Appendix.created_at.ilike(like),
                                Appendix.updated_at.ilike(like),
                                
                                
                             ))
    
    if title:
        qry = qry.filter(Appendix.title.ilike(f"%{title}%"))
    if regulation_id:
        qry = qry.filter(Appendix.regulation_id == regulation_id)
    if regulation:
        qry = qry.join(Regulation).filter(Regulation.code.ilike(f"%{regulation}%"))
    if content:
        qry = qry.filter(Appendix.content.ilike(f"%{content}%"))
    if note:
        qry = qry.filter(Appendix.note.ilike(f"%{note}%"))
    if law_text:
        qry = qry.filter(Appendix.law_text.ilike(f"%{law_text}%"))
    if status is not None:
        qry = qry.filter(Appendix.status == status)
    # if created_by:
    #     qry = qry.filter(getattr(Appendix, "created_by", None).ilike(f"%{created_by}%"))
    # if updated_by:
    #     qry = qry.filter(getattr(Appendix, "updated_by", None).ilike(f"%{updated_by}%"))
    if created_at:
        qry = qry.filter(text("DATE(created_at) = :cdate")).params(cdate=created_at)
    if updated_at:
        qry = qry.filter(text("DATE(updated_at) = :udate")).params(udate=updated_at)
    
    
    ORDER_MAP = {
        "id": Appendix.id,
        "title": Appendix.title,
        "content": Appendix.content,
        "note": Appendix.note,
        "law_text": Appendix.law_text,
        "regulation": getattr(Appendix, "regulation_text", Appendix.id),
        "regulation_id": Appendix.regulation_id,
        "status": Appendix.status,
        "updated_at": getattr(Appendix, "updated_at", Appendix.id),
        "created_at": getattr(Appendix, "created_at", Appendix.id),
    }

    # tolerant với client cũ
    sort_field = (sort_field or "id").lower()
    if sort_field == "code":                 # client cũ gửi "code" -> rơi về "id"
        sort_field = "id"
    order_col = ORDER_MAP.get(sort_field, Appendix.id)

    sort_order = (sort_order or "asc").lower()
    qry = qry.order_by(asc(order_col) if sort_order == "asc" else desc(order_col))

    total = qry.count()
    rows = qry.offset((page - 1) * size).limit(size).all()
    return ok({"page": page, "size": size, "total": total, "items": [to_out(x) for x in rows]}, "Fetched successfully")

# ========== GET BY ID ==========
@router.get("/{appendix_id}", summary="Get appendix by id")
def get_appendix(appendix_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin appendix theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông tin appendix.
    """
    obj = (
        db.query(Appendix)
          .options(joinedload(Appendix.regulation))
          .filter(Appendix.id == appendix_id)
          .first()
    )
    if not obj:
        return not_found("appendix not found")
    return ok(to_out(obj), "Fetched successfully")

# ========== CREATE ==========
@router.post("/", summary="Create appendix")
def create_appendix(payload: AppendixCreate, db: Session = Depends(get_db)):
    """Tạo appendix mới.
    - Trả về thông tin appendix mới.
    - Nếu regulation_id không tồn tại, trả về lỗi 404.
    - Nếu trùng title trong cùng regulation, trả về lỗi 409.
    """
    # xác thực regulation
    reg = db.get(Regulation, payload.regulation_id)
    if not reg:
        return not_found("regulation_id không tồn tại")

    # tránh trùng code + title trong cùng regulation
    dup = db.query(Appendix).filter(
        
        Appendix.title == payload.title,
        Appendix.regulation_id == reg.id,
        Appendix.status == (payload.status or 1),
        Appendix.note == payload.note,
        Appendix.law_text == payload.law_text,
        Appendix.content == payload.content,
        Appendix.regulation_text == payload.regulation_text,
    ).first()
    # if dup:
    #     return conflict("Appendix bị trùng title trong cùng regulation")


    obj = Appendix(
        title=payload.title,
        content=payload.content,
        note=payload.note,
        law_text=payload.law_text,
        status=payload.status or 1,
        regulation_id=reg.id,
        regulation_text=payload.regulation_text,

    )
    db.add(obj)
    db.commit()
    db.refresh(obj)

    # nạp regulation cho mapper
    obj.regulation = reg
    return ok(to_out(obj), "Created successfully")

# ========== UPDATE ==========
@router.put("/{appendix_id}", summary="Update appendix")
def update_appendix(appendix_id: int, payload: AppendixUpdate, db: Session = Depends(get_db)):
    """Cập nhật thông tin appendix theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Nếu regulation_id mới không tồn tại, trả về lỗi 404.
    - Trả về thông tin appendix đã cập nhật.
    """
    obj = db.query(Appendix).filter(Appendix.id == appendix_id).first()
    if not obj:
        # raise HTTPException(status_code=404, detail="appendix not found")
        return not_found("appendix not found")

    if payload.regulation_id:
        new_reg_id = resolve_regulation_id(db, payload.regulation_id)
        if not new_reg_id:
            # raise HTTPException(status_code=404, detail="regulation not found")
            return not_found("regulation_id không tồn tại")
        obj.regulation_id = new_reg_id

    for f in ["title","content","note","law_text","status"]:
        v = getattr(payload, f, None)
        if v is not None:
            setattr(obj, f, v)
    # if payload.regulation_text is not None:
    #     setattr(obj, "regulation_text", payload.regulation_text)

    dup_check = db.query(Appendix).filter(
        Appendix.id != obj.id,
        Appendix.content == obj.content,
        Appendix.note == obj.note,
        Appendix.law_text == obj.law_text,
        Appendix.status == obj.status,
        Appendix.title == obj.title,
        Appendix.regulation_id == obj.regulation_id

    ).first()
    # if dup_check:
    #     return conflict("Appendix bị trùng title trong cùng regulation")

    db.commit()
    db.refresh(obj)
    reg = db.get(Regulation, obj.regulation_id)
    obj.regulation = reg
    return ok(to_out(obj), "Updated successfully")

# ========== DELETE ==========
@router.delete("/{appendix_id}", summary="Delete appendix")
def delete_appendix(appendix_id: int, db: Session = Depends(get_db)):
    """Xoá appendix theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Nếu appendix đang được tham chiếu bởi bảng chemical_mappings, trả về lỗi 409.
    - Trả về thông báo xoá thành công.
    """
    obj = db.query(Appendix).filter(Appendix.id == appendix_id).first()
    if not obj:
        # raise HTTPException(status_code=404, detail="appendix not found")
        return not_found("appendix not found")

    # chặn xóa khi có mapping
    cnt = db.execute(
        text("SELECT COUNT(*) FROM chemical_mappings WHERE appendix_id=:aid"),
        {"aid": appendix_id}
    ).scalar()
    if cnt and cnt > 0:
        # raise HTTPException(status_code=409, detail="Cannot delete: appendix is referenced by chemical_mappings")
        return conflict("Không thể xóa: appendix đang được tham chiếu bởi chemical_mappings")
    db.delete(obj)
    db.commit()
    return ok({"deleted": 1}, "Deleted")