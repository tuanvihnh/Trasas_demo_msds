# from fastapi import APIRouter, Depends, HTTPException, Query, status
# from typing import List, Optional
# from datetime import datetime
# from sqlalchemy.orm import Session
# from sqlalchemy.exc import IntegrityError
# from app.models.models import *
# from app.schemas.schemas import *
# from app.utils.paginate_query import paginate_query
# from app.db.session import get_db
# from app.core.security import (
#     hash_password,
#     verify_password,
#     get_current_user,
# )
# from app.core.config import Settings
# from app.utils.response import ok


# router = APIRouter()



# @router.post("/", response_model=ArticleResponse)
# def create_article(article: ArticleCreate, db: Session = Depends(get_db)):
#     db_article = Article(**article.model_dump())
#     db.add(db_article)
#     db.commit()
#     db.refresh(db_article)
#     return ok(db_article, "Created successfully")

# @router.get("/", response_model=List[ArticleResponse])
# def read_articles(page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
#     articles = paginate_query(db.query(Article), page, size).all()
#     return ok(articles, "Fetched successfully", status.HTTP_200_OK)

# @router.get("/{article_id}", response_model=ArticleResponse)
# def read_article(article_id: int, db: Session = Depends(get_db)):
#     article = db.query(Article).filter(Article.id == article_id).first()
#     if article is None:
#         return not_found(message="Article not found")
#     return ok(article, "Fetched successfully", status.HTTP_200_OK)

# @router.put("/{article_id}", response_model=ArticleResponse)
# def update_article(article_id: int, article: ArticleCreate, db: Session = Depends(get_db)):
#     db_article = db.query(Article).filter(Article.id == article_id).first()
#     if db_article is None:
#         return not_found(message="Article not found")
#     for key, value in article.model_dump(exclude_unset=True).items():
#         setattr(db_article, key, value)
#     db.commit()
#     db.refresh(db_article)
#     return ok(db_article, "Updated successfully", status.HTTP_200_OK)

# @router.delete("/{article_id}")
# def delete_article(article_id: int, db: Session = Depends(get_db)):
#     db_article = db.query(Article).filter(Article.id == article_id).first()
#     if db_article is None:
#         return not_found(message="Article not found")
#     db.delete(db_article)
#     db.commit()
#     return ok(None, "Deleted successfully")