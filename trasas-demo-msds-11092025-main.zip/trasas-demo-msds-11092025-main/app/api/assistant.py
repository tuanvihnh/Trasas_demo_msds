from __future__ import annotations
import hashlib
import asyncio
import json
import os
import re
import tempfile
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

from app.core.config import settings

import httpx
from fastapi import APIRouter, File, Form, Header, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field

from app.utils.response import fail

try:
    # New SDK style
    from openai import OpenAI  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeError("Please `pip install openai` (>=1.40) before using this router") from e

router = APIRouter()

# ------------------------------
# Settings / Client
# ------------------------------
def _clean_cas(cas: str) -> str:
    cas = (cas or "").strip()
    if cas.upper() in {"PROPRIETARY", "N.E.", "NE", "N.D.", "ND"}:
        return ""
    return cas


def _get_openai_client() -> OpenAI:
    key = getattr(settings, "openai_api_key", None)
    if not key:
        # Avoid crashing server at import-time; raise inside request instead
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is required in environment (.env)")
    return OpenAI(api_key=key)

# Helpers to support both beta and GA namespaces across SDK versions

def _oid(x: Any) -> Optional[str]:
    """Safe extractor for `id` from SDK object or dict."""
    if hasattr(x, "id"):
        return getattr(x, "id")  # type: ignore[attr-defined]
    if isinstance(x, dict):
        return x.get("id")
    return None


def _vs_api(client: OpenAI):
    """Return the `vector_stores` namespace, compatible across SDK variants."""
    beta = getattr(client, "beta", None)
    vs = getattr(beta, "vector_stores", None) if beta else None
    if vs is None:
        vs = getattr(client, "vector_stores", None)
    if vs is None:
        raise HTTPException(status_code=500, detail="This OpenAI SDK has no vector_stores API. Please upgrade openai>=1.40.")
    return vs


def _vs_file_batches_api(client: OpenAI):
    """Get `vector_stores.file_batches` across SDK variants."""
    vs = _vs_api(client)
    fb = getattr(vs, "file_batches", None)
    if fb is None:
        raise HTTPException(status_code=500, detail="Your OpenAI SDK misses vector_stores.file_batches; upgrade openai>=1.40.")
    return fb


def _norm_opt(s: Optional[str]) -> Optional[str]:
    if s is None:
        return None
    s2 = str(s).strip()
    if s2 == "" or s2.lower() in {"string", "none", "null", "undefined"}:
        return None
    return s2

def _make_idempotency_key(o: Dict[str, Any]) -> str:
    # Ghép vài trường “định danh” ổn định
    base = f"{o.get('msds_no','')}|{o.get('product_name','')}|{o.get('project_id','')}|{json.dumps(o.get('chemical',[]), sort_keys=True)}"
    return hashlib.sha1(base.encode("utf-8")).hexdigest()  # 40 hex chars
# ------------------------------
# Schemas
# ------------------------------
class ChemicalItem(BaseModel):
    chemical_name: str
    cas_number: str
    percentage: float


class MsdsOut(BaseModel):
    product_name: str
    msds_no: str
    manufacturer_name: str
    manufacturer_address: str
    manufacturer_phone: str
    signal_word: str
    hazard_statements: str
    precautionary_statements_text: str
    ghs_symbols_text: str
    composition_info: str
    ingredient_percentage: str
    first_aid_measures: str
    fire_fighting_measures: str
    accidental_release_measures: str
    handling_storage: str
    exposure_control: str
    personal_protection: str
    physical_chemical_properties: str
    stability_reactivity: str
    toxicological_info: str
    ecological_info: str
    disposal_considerations: str
    transport_info: str
    regulatory_info: str
    other_info: str
    status: int
    project_id: int
    chemical: List[ChemicalItem]


class UploadResponse(BaseModel):
    vector_store_id: str
    vector_store_name: Optional[str] = None
    file_count_total: int
    file_count_completed: int
    file_count_failed: int
    files: List[Dict[str, Any]]


class ProcessRequest(BaseModel):
    vector_store_id: str = Field(..., description="ID of an OpenAI Vector Store containing the uploaded MSDS files")
    assistant_id: Optional[str] = Field(None, description="Override the default MSDS assistant id")
    project_id: Optional[int] = Field(None, description="Optional default project_id to suggest to the assistant")


class ProcessResponse(BaseModel):
    run_id: str
    thread_id: str
    vector_store_id: str
    inserted: int
    failed: int
    payload_echo: Union[List[Dict[str, Any]], Dict[str, Any], None]
    intake_results: List[Dict[str, Any]]

# ------------------------------
# Utilities
# ------------------------------

MSDS_EXTRACTION_INSTRUCTIONS = (
    "You are an expert at reading SDS/MSDS documents. Read the attached files via File Search and extract a structured JSON for each distinct product in EXACTLY the following shape. "
    "Return ONLY valid JSON. If multiple MSDS are present across documents, return a JSON array of objects. Otherwise return a single object."
    "Required keys: product_name, msds_no, manufacturer_name, manufacturer_address, manufacturer_phone, signal_word, hazard_statements, "
    "precautionary_statements_text, ghs_symbols_text, composition_info, ingredient_percentage, first_aid_measures, fire_fighting_measures, "
    "accidental_release_measures, handling_storage, exposure_control, personal_protection, physical_chemical_properties, stability_reactivity, "
    "toxicological_info, ecological_info, disposal_considerations, transport_info, regulatory_info, other_info, status, project_id, chemical."
    "Types: status is integer (1=create or active), project_id is integer, chemical is an array of objects with fields: chemical_name (str), cas_number (str), percentage (float). "
    "Percentages should be numeric, not strings. If a field cannot be found, put an empty string for text, 0 for numbers, and an empty array for chemical. "
    "For manufacturer and product identifiers, prefer explicit labels like 'Product name', 'MSDS No', 'SDS No', 'Document number', 'Manufacturer' sections. "
    "For GHS and P-statements, consolidate multiple entries into a single text field separated by semicolons."
    "VERY IMPORTANT: Output must be raw JSON ONLY with no markdown or commentary."
    "You are an expert at reading SDS/MSDS documents. Read the attached files via File Search and extract a structured JSON for each distinct product in EXACTLY the following shape. "
    "Return ONLY valid JSON. If multiple MSDS are present across documents, return a JSON array of objects. Otherwise return a single object.\n\n"
    "Required keys: product_name, msds_no, manufacturer_name, manufacturer_address, manufacturer_phone, signal_word, hazard_statements, "
    "precautionary_statements_text, ghs_symbols_text, composition_info, ingredient_percentage, first_aid_measures, fire_fighting_measures, "
    "accidental_release_measures, handling_storage, exposure_control, personal_protection, physical_chemical_properties, stability_reactivity, "
    "toxicological_info, ecological_info, disposal_considerations, transport_info, regulatory_info, other_info, status, project_id, chemical.\n\n"
    "Types: status is integer (1=create or active), project_id is integer, chemical is an array of objects with fields: chemical_name (str), cas_number (str), percentage (float). "
    "Percentages should be numeric, not strings. If a field cannot be found, put an empty string for text, 0 for numbers, and an empty array for chemical. "
    "For manufacturer and product identifiers, prefer explicit labels like 'Product name', 'MSDS No', 'SDS No', 'Document number', 'Manufacturer' sections. "
    "For GHS and P-statements, consolidate multiple entries into a single text field separated by semicolons.\n\n"
    "VERY IMPORTANT: Output must be raw JSON ONLY with no markdown or commentary."
)

JSON_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", flags=re.MULTILINE)
TRAILING_COMMA_RE = re.compile(r",\s*([}\]])")


def _strip_code_fences(text: str) -> str:
    return JSON_FENCE_RE.sub("", text).strip()


def _fix_trailing_commas(text: str) -> str:
    # Replace trailing commas before closing } or ]
    return TRAILING_COMMA_RE.sub(r"\1", text)


# --- Compatibility helper for differing SDK signatures ---
# Tries several call shapes to maximize compatibility across openai SDK versions.
def _file_batch_retrieve(batches, vector_store_id: str, file_batch_id: str):
    """Retrieve a file_batch status across various OpenAI SDK signatures.
    Tries several call shapes and finally inspects the callable signature.
    """
    import inspect
    # 1) Older positional: (vector_store_id, id)
    try:
        return batches.retrieve(vector_store_id, file_batch_id)
    except TypeError:
        pass
    # 2) Variants with different keyword names for the batch id
    for kw in ("id", "file_batch_id", "batch_id"):
        try:
            return batches.retrieve(vector_store_id=vector_store_id, **{kw: file_batch_id})
        except TypeError:
            continue
    # 3) Some variants accept only the batch id
    try:
        return batches.retrieve(file_batch_id)
    except TypeError:
        pass
    # 4) Inspect the signature to map param names
    try:
        sig = inspect.signature(batches.retrieve)
        params = list(sig.parameters.keys())
        if len(params) == 2:
            return batches.retrieve(**{params[0]: vector_store_id, params[1]: file_batch_id})
        if len(params) == 1:
            return batches.retrieve(file_batch_id)
    except Exception:
        pass
    # 5) Give a clean actionable error
    raise HTTPException(status_code=500, detail=(
        "Incompatible OpenAI SDK for file batch retrieve. "
        "Please upgrade `openai` to >= 1.40 or adjust the call signature to your SDK."
    ))


def parse_assistant_json(content_text: str) -> Union[List[Dict[str, Any]], Dict[str, Any]]:
    text = _fix_trailing_commas(_strip_code_fences(content_text))
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Try a more lenient approach: extract the first {...} or [...] block
        match = re.search(r"(\{.*\}|\[.*\])", text, flags=re.DOTALL)
        if not match:
            raise
        return json.loads(_fix_trailing_commas(match.group(1)))


async def poll_run_until_complete(client: OpenAI, thread_id: str, run_id: str, timeout_s: int = 600) -> Dict[str, Any]:
    """Poll the run until it reaches a terminal state."""
    loop = asyncio.get_event_loop()
    deadline = loop.time() + timeout_s
    last_status: Optional[str] = None
    while loop.time() < deadline:
        run = client.beta.threads.runs.retrieve(thread_id=thread_id, run_id=run_id)
        status = getattr(run, "status", None)
        last_status = status
        if status in {"completed", "failed", "cancelled", "expired"}:
            return run.model_dump() if hasattr(run, "model_dump") else run  # type: ignore[return-value]
        await asyncio.sleep(1.5)
    raise HTTPException(status_code=504, detail=f"Run polling timeout. Last status={last_status}")


@dataclass
class BatchAttachResult:
    total: int
    completed: int
    failed: int
    files: List[Dict[str, Any]]


def _attach_files_to_vector_store(client: OpenAI, vector_store_id: str, openai_file_ids: List[str]) -> BatchAttachResult:
    batches = _vs_file_batches_api(client)
    created = batches.create(vector_store_id=vector_store_id, file_ids=openai_file_ids)

    file_batch_id = _oid(created)
    status_obj = created

    # Ensure counters are always defined
    total = 0
    completed = 0
    failed = 0

    # Poll until files are processed (max ~3 minutes)
    import time

    for _ in range(180):  # ~3 minutes max
        counts = getattr(status_obj, "file_counts", None) or getattr(status_obj, "counts", None)
        if counts is not None:
            # Handle both SDK object and dict
            total = getattr(counts, "total", None) or (counts.get("total") if isinstance(counts, dict) else 0) or 0
            completed = getattr(counts, "completed", None) or (counts.get("completed") if isinstance(counts, dict) else 0) or 0
            failed = getattr(counts, "failed", None) or (counts.get("failed") if isinstance(counts, dict) else 0) or 0
            if total > 0 and (completed + failed) >= total:
                break

        if file_batch_id:
            # Use keyword args to be compatible with SDKs that require both IDs
            status_obj = _file_batch_retrieve(batches, vector_store_id, file_batch_id)

        time.sleep(1.0)

    # List files currently attached
    files_list = _vs_api(client).files.list(vector_store_id=vector_store_id)
    files = [f.model_dump() if hasattr(f, "model_dump") else f for f in getattr(files_list, "data", [])]
    return BatchAttachResult(total=total, completed=completed, failed=failed, files=files)

# ------------------------------
# Routes
# ------------------------------

@router.post("/vector-stores/upload", response_model=UploadResponse)
async def upload_to_vector_store(
    request: Request,
    files: List[UploadFile] = File(..., description="One or many MSDS files: PDF, DOCX, TXT, etc."),
    vector_store_id: Optional[str] = Form(None, description="Existing vector store id to append to. If omitted, a new one is created."),
    vector_store_name: Optional[str] = Form(None, description="Name for a new vector store if vector_store_id isn't provided."),
):
    """Upload files lên OpenAI Vector Store để chuẩn bị trích xuất MSDS."""
    if not files:
        return fail(message="No files provided")

    client = _get_openai_client()

    vs_id = _norm_opt(vector_store_id)
    if vs_id and not vs_id.startswith("vs_"):
        return fail(message="vector_store_id phải có dạng vs_...")

    vs_name: Optional[str] = None

    # 1) Create or reuse a vector store
    if vs_id:
        # Fetch name for response (best effort)
        try:
            vs_obj = _vs_api(client).retrieve(vector_store_id=vs_id)
            vs_name = getattr(vs_obj, "name", None) or (vs_obj.get("name") if isinstance(vs_obj, dict) else None)
        except Exception:
            vs_name = None
    else:
        vs_obj = _vs_api(client).create(name=_norm_opt(vector_store_name) or "MSDS Vector Store")
        vs_id = _oid(vs_obj)
        if not vs_id:
            raise HTTPException(status_code=500, detail="Không lấy được vector_store_id khi tạo mới")
        vs_name = getattr(vs_obj, "name", None) or (vs_obj.get("name") if isinstance(vs_obj, dict) else None)

    # 2) Upload each file to OpenAI files (purpose=assistants) to preserve filenames/extensions
    openai_file_ids: List[str] = []
    temp_paths: List[str] = []
    try:
        for uf in files:
            # Preserve extension - OpenAI uses extension for retrievability hints
            suffix = os.path.splitext(uf.filename or "uploaded.bin")[1] or ".bin"
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                temp_paths.append(tmp.name)
                chunk = await uf.read()
                tmp.write(chunk)
            with open(tmp.name, "rb") as fh:
                created = client.files.create(file=fh, purpose="assistants")
                file_id = _oid(created)
                if not file_id:
                    raise HTTPException(status_code=500, detail="Cannot obtain OpenAI file id")
                openai_file_ids.append(file_id)

        # 3) Attach files to vector store via file batch
        result = _attach_files_to_vector_store(client=client, vector_store_id=vs_id, openai_file_ids=openai_file_ids)

        return UploadResponse(
            vector_store_id=vs_id,
            vector_store_name=vs_name,
            file_count_total=result.total,
            file_count_completed=result.completed,
            file_count_failed=result.failed,
            files=result.files,
        )
    finally:
        for p in temp_paths:
            try:
                os.unlink(p)
            except OSError:
                pass


@router.post("/vector-stores/process", response_model=ProcessResponse)
async def process_vector_store(
    request: Request,
    body: ProcessRequest,
):
    """Dùng Assistant để trích xuất MSDS từ các file trong Vector Store, và gửi kết quả về API intake."""
    vs_id = body.vector_store_id
    assistant_id = body.assistant_id or getattr(settings, "openai_msds_assistant_id", None)
    if not assistant_id:
        return fail(message="assistant_id not provided and OPENAI_MSDS_ASSISTANT_ID not set")

    # Prepare per-run instructions
    extra = " If you cannot find a value, use empty string for text and 0 for numbers."
    if body.project_id is not None:
        extra += f" If project_id is missing in the document, default to {body.project_id}."

    run_instructions = MSDS_EXTRACTION_INSTRUCTIONS + extra

    client = _get_openai_client()

    # 1) Create a thread attached to the vector store
    thread = client.beta.threads.create(
        tool_resources={"file_search": {"vector_store_ids": [vs_id]}},
        messages=[
            {
                "role": "user",
                "content": (
                    "Read all MSDS files in the attached Vector Store, and extract the normalized JSON object(s) as specified. "
                    "Return ONLY the raw JSON (no code fences, no markdown)."
                ),
            }
        ],
    )
    thread_id = _oid(thread)
    if not thread_id:
        raise HTTPException(status_code=500, detail="Cannot create thread")

    # 2) Create a run with the MSDS assistant (pass model only if configured)
    run_kwargs: Dict[str, Any] = {
        "thread_id": thread_id,
        "assistant_id": assistant_id,
        "instructions": run_instructions,
        "tools": [{"type": "file_search"}],
    }
    openai_model = getattr(settings, "openai_model", None)
    if openai_model:
        run_kwargs["model"] = openai_model

    run = client.beta.threads.runs.create(**run_kwargs)
    run_id = _oid(run)
    if not run_id:
        raise HTTPException(status_code=500, detail="Cannot create run")

    # 3) Poll for completion
    run_final = await poll_run_until_complete(client=client, thread_id=thread_id, run_id=run_id)
    if (run_final.get("status") or run_final.get("data", {}).get("status")) != "completed":
        raise HTTPException(status_code=500, detail=f"Run did not complete successfully: {run_final.get('status')}")

    # 4) Fetch the assistant message content
    msgs = client.beta.threads.messages.list(thread_id=thread_id, order="desc", limit=10)
    content_text: Optional[str] = None
    for m in getattr(msgs, "data", []):
        if getattr(m, "role", "") != "assistant":
            continue
        blocks = getattr(m, "content", [])
        for b in blocks:
            if getattr(b, "type", "") == "text":
                text_val = getattr(b, "text", None)
                if text_val and hasattr(text_val, "value") and getattr(text_val, "value"):
                    content_text = text_val.value  # type: ignore[attr-defined]
                    break
        if content_text:
            break

    if not content_text:
        raise HTTPException(status_code=500, detail="No assistant text content found")

    # 5) Parse JSON
    parsed = parse_assistant_json(content_text)
    items: List[Dict[str, Any]] = parsed if isinstance(parsed, list) else [parsed]

    # 6) POST to /api/msds/openai/intake for each item
    api_base = getattr(settings, "api_base_url", None) or ""
    intake_url = f"{api_base.rstrip('/')}/api/msds/openai/intake"
    headers = {"Content-Type": "application/json"}
    

    # Normalizer to coerce types to match intake API expectations
    # - ingredient_percentage: string (e.g., "4.5%" or "4.5")
    # - status: int
    # - project_id: int (fallback from body if missing)
    # - chemical[].percentage: float; cas_number: string; chemical_name: string
    # - keep other fields as strings (ensure None -> "")

    def _normalize_for_intake(obj: Dict[str, Any], default_project_id: Optional[int] = None) -> Dict[str, Any]:
        o = dict(obj)

        # status
        if isinstance(o.get("status"), str):
            try:
                o["status"] = int(o["status"].strip() or 0)
            except Exception:
                o["status"] = 0

        # project_id
        if default_project_id is not None and not o.get("project_id"):
            o["project_id"] = default_project_id

        # ingredient_percentage must be a string for intake
        if "ingredient_percentage" in o:
            val = o.get("ingredient_percentage")
            if val is None:
                o["ingredient_percentage"] = ""
            elif isinstance(val, (int, float)):
                # keep plain numeric as string (no % unless already provided)
                o["ingredient_percentage"] = str(val)
            else:
                # ensure string
                o["ingredient_percentage"] = str(val)

        # chemical array coercion
        chems = o.get("chemical")
        if isinstance(chems, list):
            new_list = []
            for it in chems:
                if not isinstance(it, dict):
                    continue
                name = str(it.get("chemical_name", ""))
                cas = str(it.get("cas_number", ""))
                pct = it.get("percentage", 0.0)
                try:
                    pct = float(pct)
                except Exception:
                    pct = 0.0
                new_list.append({
                    "chemical_name": name,
                    "cas_number": cas,
                    "percentage": pct,
                })
            o["chemical"] = new_list
        else:
            o["chemical"] = []

        # Ensure all non-numeric main fields default to string (no None)
        text_fields = [
            "product_name","msds_no","manufacturer_name","manufacturer_address","manufacturer_phone",
            "signal_word","hazard_statements","precautionary_statements_text","ghs_symbols_text",
            "composition_info","first_aid_measures","fire_fighting_measures","accidental_release_measures",
            "handling_storage","exposure_control","personal_protection","physical_chemical_properties",
            "stability_reactivity","toxicological_info","ecological_info","disposal_considerations",
            "transport_info","regulatory_info","other_info"
        ]
        for k in text_fields:
            if o.get(k) is None:
                o[k] = ""
            elif not isinstance(o[k], (str,)):
                o[k] = str(o[k])

        return o

    intake_results: List[Dict[str, Any]] = []
    success, fail = 0, 0
    async with httpx.AsyncClient(timeout=30.0) as http:
        for obj in items:
            try:
                normalized = _normalize_for_intake(obj, default_project_id=body.project_id)

                # Gửi Idempotency-Key để server (nếu hỗ trợ) ngăn double-insert do retry
                idemp = _make_idempotency_key(normalized)
                req_headers = dict(headers)
                req_headers["Idempotency-Key"] = idemp

                resp = await http.post(intake_url, json=normalized, headers=req_headers)
                ctype = resp.headers.get("content-type", "").lower()
                is_json = ctype.startswith("application/json")
                body_payload = resp.json() if is_json else resp.text

                # --- Duplicate handling (coi là thành công) ---
                treated_success = False
                if resp.status_code == 400:
                    # Chuẩn hóa body về chuỗi để dò “Duplicate entry”
                    txt = body_payload if isinstance(body_payload, str) else json.dumps(body_payload, ensure_ascii=False)
                    if "Duplicate entry" in txt or "duplicate key" in txt.lower():
                        treated_success = True

                intake_results.append({
                    "status_code": resp.status_code,
                    "body": body_payload,
                    "idempotency_key": idemp,
                    "treated_as": "success_duplicate_skip" if treated_success else "normal"
                })

                if resp.status_code < 300 or treated_success:
                    success += 1
                else:
                    fail += 1

            except Exception as ex:  # pragma: no cover
                intake_results.append({"status_code": 0, "error": str(ex)})
                fail += 1

    return ProcessResponse(
        run_id=run_id,
        thread_id=thread_id,
        vector_store_id=vs_id,
        inserted=success,
        failed=fail,
        payload_echo=parsed,
        intake_results=intake_results,
    )
