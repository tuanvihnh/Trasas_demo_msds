from fastapi import APIRouter, Depends, HTTPException, status, Response
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.models import User
from app.schemas.schemas import ErrorOut, LoginIn, RegisterIn, ResponseBase, UserOut, UserResponse  # LoginIn nếu bạn đã định nghĩa
from app.core.security import (
    create_access_token,
    get_current_user,
    hash_password,
    verify_password,
)
from app.utils.response import ok
from app.schemas.schemas import LoginIn

router = APIRouter()


@router.post("/register", response_model=ResponseBase[UserResponse] | ErrorOut, status_code=200)
def register(payload: RegisterIn, db: Session = Depends(get_db), response: Response = None):
    """Đăng ký người dùng mới.
    - Nếu email đã tồn tại, trả về lỗi 409.
    - Trả về thông tin người dùng đã đăng ký (không bao gồm mật khẩu).
    """
    if db.query(User).filter(User.email == payload.email).first():
        if response is not None:
            response.status_code = status.HTTP_409_CONFLICT
        return ErrorOut(status="error", message="Email đã tồn tại")
    user = User(
        username=payload.username,
        email=payload.email,
        password_hash=hash_password(payload.password),
        role=payload.role,  # role bắt buộc theo DB
        status=1,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return {
        "status": "success",
        "message": "Đăng ký thành công",
        "data": user
    }
    # return ok(user, "Đăng ký thành công")


# Nếu bạn đã có LoginIn trong schemas: dùng LoginIn
# from app.schemas.schemas import LoginIn
# @router.post("/login")
# def login(payload: LoginIn, db: Session = Depends(get_db)):


@router.post("/login")
def login(payload: LoginIn, db: Session = Depends(get_db), response: Response = None):
    """Xác thực người dùng và trả về token JWT.
    - Nếu email hoặc mật khẩu không đúng, trả về lỗi 401.
    - Trả về token và thông tin người dùng (không bao gồm mật khẩu).
    """
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        if response is not None:
            response.status_code = status.HTTP_401_UNAUTHORIZED
        return ErrorOut(status="error", message="Tài khoản hoặc mật khẩu không đúng")
    token = create_access_token(user.id)
    return {
        "status":"success",
        "message":"Login successfully",
        "token": token,
        "user": user
    }
    # return ok({"token": token, "user": user}, "Login successfully", status.HTTP_200_OK)



@router.post("/logout")
def logout():
    """Đăng xuất người dùng.
    - Với JWT stateless, chỉ cần client xoá token phía client.
    - Trả về thông báo thành công.
    """
    # JWT stateless: không cần (và không nên) chỉnh DB. Client chỉ cần xoá token phía client.
    return ok(None, "Logout successfully", status.HTTP_200_OK)


@router.get("/me", response_model=ResponseBase[UserOut])
def me(current: User = Depends(get_current_user)):
    """Lấy thông tin người dùng hiện tại từ token.
    - Trả về thông tin người dùng (không bao gồm mật khẩu).
    """
    return {
        "status": "success",
        "message": "thành công",
        "data": current
    }
    
    # return ok(current, "Thành công", status.HTTP_200_OK)
