from fastapi import APIRouter, FastAPI, File, HTTPException, Depends, UploadFile, status, Query, Header
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Literal, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import asc, create_engine, Column, Integer, String, Text, DateTime, DECIMAL, ForeignKey, Boolean, desc, or_
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.sql import func
import base64, hashlib, secrets
from datetime import datetime, timedelta
import json
from sqlalchemy import UniqueConstraint, text, bindparam
from sqlalchemy.exc import IntegrityError
from app.models.models import Appendix, ChemicalMapping , Chemical, Regulation, RegulationAppendix
from app.schemas.common import Paginated, ResponseEnvelope
from app.schemas.schemas import ChemicalCreate, ChemicalResponse, PaginatedChemicals, ChemicalBrief, NotesByCASResponse, NoteItem, NotesByCASSummary
import pdfplumber, os, io, re
from fastapi.middleware.cors import CORSMiddleware
from app.utils.paginate_query import paginate_query
from fastapi.openapi.utils import get_openapi
from fastapi import APIRouter
from app.db.session import get_db
from app.core.security import (
    hash_password,
    verify_password,
    
    get_current_user,
)
from app.db.session import SessionLocal, get_db
from app.core.config import Settings
from app.utils.response import fail, not_found, ok
from sqlalchemy import text as sql_text
from fastapi import APIRouter, Depends, HTTPException, Query, Response, status, Path


router = APIRouter()


@router.get("/regulation_appendix_code", response_model=ResponseEnvelope[PaginatedChemicals])
def chemicals_in_regapp(
    code: Optional[str] = Query(None, description="Regulation code (mã nghị định, ví dụ: 113); bỏ trống để lấy tất cả"),
    q: Optional[str] = Query(None, description="search by name/CAS/HS"),
    page: int = 1,
    size: int = 50,
    db: Session = Depends(get_db),
):
    """
    Lấy danh sách hóa chất liên quan đến phụ lục (Appendix) thuộc một nghị định (Regulation).
    - Nếu truyền `code` thì lọc theo `regulation.code` (vd: '113', '33'...).
    - Hỗ trợ phân trang (page, size).
    """
    offset = (page - 1) * size

    # JOIN: Chemical -> ChemicalMapping -> Appendix -> Regulation
    base = (
        db.query(Chemical)
          .join(ChemicalMapping, ChemicalMapping.chemical_id == Chemical.id)
          .join(Appendix, Appendix.id == ChemicalMapping.appendix_id)
          .join(Regulation, Regulation.id == Appendix.regulation_id, isouter=True)
    )

    if code:
        # so khớp linh hoạt: trim + lower trên regulation.code
        base = base.filter(
            func.lower(func.trim(Regulation.code)) == func.lower(func.trim(code))
        )

    if q:
        like = f"%{q}%"
        base = base.filter(or_(
            Chemical.chemical_name.ilike(like),
            Chemical.chemical_name_vn.ilike(like),
            Chemical.cas_no.ilike(like),
            Chemical.hs_code.ilike(like),
        ))

    # Tổng số hóa chất duy nhất
    total = base.with_entities(Chemical.id).distinct().count()

    # Lấy danh sách id theo trang, sắp xếp theo tên (null sau cùng)
    ids_rows = (
        base.with_entities(
                Chemical.id.label("id"),
                func.min(Chemical.chemical_name).label("nm")
            )
            .group_by(Chemical.id)
            .order_by(func.min(Chemical.chemical_name).is_(None))  # non-null trước
            .order_by(func.min(Chemical.chemical_name).asc())
            .offset(offset).limit(size)
            .all()
    )
    ids = [r.id for r in ids_rows]
    if not ids:
        return ok({"meta": {"total": total, "page": page, "size": size}, "items": []})

    # Nạp chi tiết + Regulation code + ghi chú từ Appendix
    rows = (
        db.query(
            Chemical.id,
            Chemical.chemical_name,
            Chemical.chemical_name_vn,
            Chemical.cas_no,
            Chemical.hs_code,
            getattr(Chemical, "molecular_formula", None).label("molecular_formula")
            if hasattr(Chemical, "molecular_formula") else func.null(),
            Regulation.code,         # <— code ở bảng regulation
            Appendix.note,           # <— note ở appendix
            Appendix.law_text,       # <— law_text ở appendix
        )
        .join(ChemicalMapping, ChemicalMapping.chemical_id == Chemical.id)
        .join(Appendix, Appendix.id == ChemicalMapping.appendix_id)
        .join(Regulation, Regulation.id == Appendix.regulation_id, isouter=True)
        .filter(Chemical.id.in_(ids))
        .all()
    )

    # Gộp theo chemical, gom nhiều appendix/regulation (nếu không lọc theo code)
    agg: Dict[int, Dict] = {}
    for r in rows:
        cid = r[0]
        slot = agg.setdefault(cid, {
            "id": r[0],
            "chemical_name": r[1],
            "chemical_name_vn": r[2],
            "cas_no": r[3],
            "hs_code": r[4],
            "molecular_formula": r[5],
            "codes": [],
            "notes": [],
            "laws": [],
        })
        code_val, note_val, law_val = r[6], r[7], r[8]
        if code_val and code_val not in slot["codes"]:
            slot["codes"].append(code_val)
        if note_val and note_val.strip():
            slot["notes"].append(note_val.strip())
        if law_val and law_val.strip():
            slot["laws"].append(law_val.strip())

    items: List[ChemicalBrief] = []
    for cid in ids:  # giữ thứ tự phân trang
        s = agg.get(cid)
        if not s:
            continue
        items.append(ChemicalBrief(
            id=s["id"],
            chemical_name=s["chemical_name"],
            chemical_name_vn=s["chemical_name_vn"],
            cas_no=s["cas_no"],
            hs_code=s["hs_code"],
            molecular_formula=s["molecular_formula"] if s["molecular_formula"] not in (None, 'NULL') else None,
            # nếu có code lọc thì rows ở trên đã bị lọc theo code → notes/laws chính là của code đó
            note="\n\n".join(s["notes"]) if s["notes"] else None,
            law_text="\n\n".join(s["laws"]) if s["laws"] else None,
            codes=None if code else s["codes"],  # nếu không lọc code, trả danh sách code liên quan
        ))

    return ok({
        "meta": {"total": total, "page": page, "size": size, "code": code},
        "items": items
    }, message="OK")

    

@router.post("/", response_model=ChemicalResponse)
def create_chemical(chemical: ChemicalCreate, db: Session = Depends(get_db)):
    """Tạo hóa chất mới.
    - Nếu CAS No. đã tồn tại, trả về lỗi 409.
    - Trả về thông tin hóa chất mới.
    """
    db_chemical = db.query(Chemical).filter(Chemical.cas_no == chemical.cas_no).first()
    if db_chemical:
        return fail(message="Số cas đã toàn tại")
    db_chemical = Chemical(**chemical.model_dump())
    db.add(db_chemical)
    db.commit()
    db.refresh(db_chemical)
    return ok(db_chemical, "Created successfully")

@router.get("/", response_model=ResponseEnvelope[Paginated[ChemicalResponse]])
def read_chemicals(
    page: int = Query(1, ge=1),
    size: int = Query(10, ge=1, le=100),
    q: str | None = Query(None, description="Search in name, name_vn, cas_no, hs_code"),
    sort_field: Literal["id", "chemical_name", "chemical_name_vn", "cas_no", "hs_code", "updated_at", "created_at"] = "updated_at",
    sort_order: Literal["asc", "desc"] = "desc",
    db: Session = Depends(get_db),
):
    """Lấy danh sách hóa chất với phân trang và sắp xếp.
    - Mặc định page=1, size=10.
    - Kích thước trang tối đa là 100.
    - Hỗ trợ tìm kiếm trong tên, tên tiếng Việt, CAS No., HS Code.
    - Hỗ trợ sắp xếp theo các trường: id, chemical_name, chemical_name_vn, cas_no, hs_code, updated_at, created_at.
    - Trả về danh sách hóa chất.
    """
    base = db.query(Chemical)

    if q:
        term = q.strip()
        hs_code_like = func.replace(Chemical.hs_code, ".", "").ilike(f"%{term.replace('.', '')}%")
        filters = or_(
            Chemical.chemical_name.ilike(f"%{term}%"),
            Chemical.chemical_name_vn.ilike(f"%{term}%"),
            Chemical.cas_no.ilike(f"%{term}%"),
            Chemical.hs_code.ilike(f"%{term}%"),
            hs_code_like,
        )
        base = base.filter(filters)

    # map cột để sort an toàn
    order_col = {
        "id": Chemical.id,
        "chemical_name": Chemical.chemical_name,
        "chemical_name_vn": Chemical.chemical_name_vn,
        "cas_no": Chemical.cas_no,
        "hs_code": Chemical.hs_code,
        "updated_at": Chemical.updated_at,
        "created_at": Chemical.created_at,
    }[sort_field]
    order_by_clause = asc(order_col) if sort_order == "asc" else desc(order_col)

    total = base.count()

    items_orm: list[Chemical] = (
    base.order_by(order_by_clause, Chemical.id.asc())
        .offset((page - 1) * size)
        .limit(size)
        .all()
    )

    items = [
        ChemicalResponse.model_validate(x, from_attributes=True).model_dump()
        for x in items_orm
    ]

    payload = {"page": page, "size": size, "total": total, "items": items}
    return ok(payload, "Fetched successfully", status.HTTP_200_OK)

@router.get("/{chemical_id}", response_model=ChemicalResponse)
def read_chemical(chemical_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin hóa chất theo ID.
    - Trả về thông tin hóa chất.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    chemical = db.query(Chemical).filter(Chemical.id == chemical_id).first()
    if chemical is None:
        return not_found(message="Chemical not found")
    return ok(chemical, "Fetched successfully", status.HTTP_200_OK)

@router.put("/{chemical_id}", response_model=ChemicalResponse)
def update_chemical(chemical_id: int, chemical: ChemicalCreate, db: Session = Depends(get_db)):
    """Cập nhật thông tin hóa chất theo ID.
    - Trả về thông tin hóa chất đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_chemical = db.query(Chemical).filter(Chemical.id == chemical_id).first()
    if db_chemical is None:
        return not_found(message="Chemical not found")
    for key, value in chemical.model_dump(exclude_unset=True).items():
        setattr(db_chemical, key, value)
    db.commit()
    db.refresh(db_chemical)
    return ok(db_chemical, "Updated successfully", status.HTTP_200_OK)

@router.delete("/{chemical_id}")
def delete_chemical(chemical_id: int, db: Session = Depends(get_db)):
    """Xoá hóa chất theo ID.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_chemical = db.query(Chemical).filter(Chemical.id == chemical_id).first()
    if db_chemical is None:
        return not_found(message="Chemical not found")
    db.delete(db_chemical)
    db.commit()
    return ok(None, "Deleted successfully") 



# # app/api/chemicals.py
# @router.get("/{cas_no}/notes", response_model=ChemicalNotesOut, response_model_exclude_none=True)
# def get_chemical_notes(cas_no: str, db: Session = Depends(get_db)):
#     chem = db.query(Chemical).filter(Chemical.cas_no == cas_no.strip()).first()
#     if not chem:
#         return not_found(message="CAS not found")
#     # return ChemicalNotesOut(
#     #     cas_no=chem.cas_no,
#     #     chemical_name=chem.chemical_name,          # THÊM DÒNG NÀY
#     #     note=(chem.note or None),
#     #     regulatory_info=(chem.regulatory_info or None),
#     # )
#     return ok(
#         ChemicalNotesOut(
#             cas_no=chem.cas_no,
#             chemical_name=chem.chemical_name,          # THÊM DÒNG NÀY
#             note=(chem.note or None),
#             regulatory_info=(chem.regulatory_info or None),
#         ),
#         "Fetched successfully",
#         status.HTTP_200_OK
#     )

@router.get("/notes-by-cas/{cas_no}", response_model=ResponseEnvelope[NotesByCASResponse])
def get_notes_by_cas(cas_no: str, db: Session = Depends(get_db)):
    """Lấy ghi chú và thông tin pháp lý liên quan đến hóa chất theo CAS No.
    - Trả về danh sách các phụ lục (appendix) liên quan đến hóa chất.
    - Nếu không tìm thấy hóa chất hoặc không có phụ lục liên quan, trả 404.
    """
    q = sql_text("""
      SELECT c.cas_no, c.chemical_name, c.hs_code,
             r.code, a.title, a.note, a.regulation, a.law_text, a.content
      FROM chemicals c
      LEFT JOIN chemical_mappings m
             ON m.chemical_id = c.id AND (m.status = 1 OR m.status IS NULL)
      LEFT JOIN appendix a
             ON a.id = m.appendix_id AND (a.status = 1 OR a.status IS NULL)
      LEFT JOIN regulation r
             ON r.id = a.regulation_id
      WHERE c.cas_no = :cas
      ORDER BY a.title, r.code
    """)
    rows = db.execute(q, {"cas": cas_no}).all()

    if not rows:
        return not_found(message="No data")

    cas, chem_name, hs = rows[0][0], rows[0][1], rows[0][2]
    items: List[NoteItem] = []
    for r in rows:
        code, title = r[3], r[4]
        if code is None and title is None:
            continue
        items.append(NoteItem(
            code=code or "",
            title=title or "",
            note=r[5],
            regulation=r[6],   # từ cột a.regulation
            law_text=r[7],
            content=r[8],
        ))

    resp = NotesByCASResponse(
        cas_no=cas,
        chemical_name=chem_name,
        hs_code=hs,
        total_notes=len(items),
        notes=items
    )
    return ok(resp, message="OK")


@router.get("/notes-by-cas/{cas_no}/summary", response_model=ResponseEnvelope[NotesByCASSummary])
def get_notes_summary_by_cas(cas_no: str = Path(...), db: Session = Depends(get_db)):
    """Lấy tóm tắt ghi chú và thông tin pháp lý liên quan đến hóa chất theo CAS No.
    - Gộp các trường note/regulation/law_text/content từ appendix.
    """
    q = sql_text("""
        SELECT c.cas_no, c.chemical_name, c.hs_code,
               a.note, a.regulation, a.law_text, a.content
        FROM chemicals c
        LEFT JOIN chemical_mappings m
               ON m.chemical_id = c.id AND (m.status = 1 OR m.status IS NULL)
        LEFT JOIN appendix a
               ON a.id = m.appendix_id AND (a.status = 1 OR a.status IS NULL)
        LEFT JOIN regulation r
               ON r.id = a.regulation_id
        WHERE c.cas_no = :cas
        ORDER BY a.title, r.code
    """)
    rows = db.execute(q, {"cas": cas_no}).all()
    if not rows:
        return not_found(message="No data")

    cas, chem_name, hs = rows[0][0], rows[0][1], rows[0][2]

    parts: List[str] = []
    for _, _, _, note, reg, law, content in rows:
        chunk = "\n".join(x for x in [note, reg, law, content] if x and x.strip())
        if chunk:
            parts.append(chunk.strip())

    notes_summary = "\n\n".join(parts)
    return ok(NotesByCASSummary(
        cas_no=cas, chemical_name=chem_name, hs_code=hs, notes_summary=notes_summary
    ))

