# api/element.py - only routers and service calls

from fastapi import APIRouter, Depends, HTTPException, Query, Path
from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from typing import Optional, List

from app.db.session import get_db
from app.models.models import OutputElement
from app.utils.response import not_found, ok
from app.schemas.schemas import OutputElementIn, OutputElementUpdate, OutputElementOut
from app.schemas.common import ResponseEnvelope, Paginated, PageMeta
from app.services.outputAll import (list_output_elements_service, get_output_element_service, create_output_element_service, update_output_element_service, update_output_element_partial_service, delete_output_element_service)

router = APIRouter(prefix="/output-elements", tags=["Output Elements"])

@router.get("/", response_model=ResponseEnvelope[Paginated[OutputElementOut]])
def list_output_elements(
    db: Session = Depends(get_db),
    output_id: Optional[int] = Query(None),
    cas_no: Optional[str] = Query(None),
    status: Optional[bool] = Query(None),
    q: Optional[str] = Query(None, description="search in cas_no or chemical_name"),
    page: int = 1,
    size: int = 50,
):
    return list_output_elements_service(db, output_id, cas_no, status, q, page, size)

@router.get("/{element_id}", response_model=ResponseEnvelope[OutputElementOut])
def get_output_element(element_id: int, db: Session = Depends(get_db)):
    return get_output_element_service(element_id, db)

@router.post("/", response_model=ResponseEnvelope[OutputElementOut])
def create_output_element(body: OutputElementIn, db: Session = Depends(get_db)):
    return create_output_element_service(body, db)
    
@router.put("/{element_id}", response_model=dict)
def update_output_element(element_id: int, payload: OutputElementUpdate, db: Session = Depends(get_db)):
    return update_output_element_service(element_id, payload, db)

@router.patch("/{element_id}", response_model=ResponseEnvelope[OutputElementOut])
def update_output_element_partial(element_id: int, body: OutputElementUpdate, db: Session = Depends(get_db)):
    return update_output_element_partial_service(element_id, body, db)

@router.delete("/{element_id}", response_model=ResponseEnvelope[dict])
def delete_output_element(element_id: int, db: Session = Depends(get_db)):
    return delete_output_element_service(element_id, db)