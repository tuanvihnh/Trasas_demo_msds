# file: app/api/chemical_extract.py
import json
import os
import re
from typing import Any, Dict, List, Optional
import time
from datetime import datetime

from dotenv import load_dotenv
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from fastapi.responses import StreamingResponse
from fastapi import APIRouter, Depends, HTTPException, Path, status
from openai import OpenAI
from pydantic import BaseModel
import asyncio
import json
from typing import Dict, Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.msds import intake_msds
from app.db.session import get_db

from app.models.models import MSDS, MSDSChemical, Project
from app.schemas.common import ResponseEnvelope
from app.schemas.schemas import ChemicalIn, ChemicalNote, MsdsCreateResult, MsdsIn, ProductNotes, ProjectBatchCasIn, ProjectBatchCasOut, SecondExtractBatchIn, SecondExtractIn, SecondExtractSavedOut

from app.services.extracts_service import _collect_notes_for_cas_list, handle_project_batch_notes_by_cas, preview_project_batch_notes_by_cas, project_id_cas_notes_preview, save_second_extract, save_second_extract_batch
from app.services.outputAll import create_batch_outputs_service
from app.utils.response import fail, not_found, ok         # chuẩn Session dependency của bạn
    
from app.schemas.schemas import CasExtractResp
from app.services.chemical_extract import extract_cas_from_merged_pdf_service, extract_cas_from_merged_pdf_service_mock, extract_msds_output_service         # chuẩn Session dependency của bạn


# ============================== ROUTER ==============================
router = APIRouter()

# ============================== SSE STATE MANAGEMENT ==============================
# In-memory storage cho demo (production nên dùng Redis)
project_states: Dict[str, Dict[str, Any]] = {}

def get_project_state(project_id: str) -> Dict[str, Any]:
    return project_states.get(project_id, {
        "status": "idle", 
        "message": "", 
        "data": None, 
        "started_at": None, 
        "completed_at": None, 
        "elapsed_ms": None
    })

def set_project_state(project_id: str, state: Dict[str, Any]):
    project_states[project_id] = state

# ============================== ROUTE ==============================
@router.post("/projects/{project_id}/extract-cas")
async def extract_cas(project_id: str, db: Session = Depends(get_db)):
    """
    Triển khai trích xuất CAS từ merged PDF của project.
    Kết quả trả về là list các object {ProductName, CasNoList}.
    Đồng thời tự động import các CAS này vào bảng MSDS (nếu chưa có).

    Nhập projectId --> gọi openAi để trích xuất productName, casNo , wt--> Dữ liệu được trích xuất sẽ được lưu xuống db.
    """
    results = await extract_cas_from_merged_pdf_service(project_id, db)

    if not results or all(
        (not item.get("ProductName") and not item.get("CasNoList"))
        for item in results
    ):
        # Trả về status error
        return {
            "status": "error",
            "message": "Dữ liệu không phù hợp",
            "data": []
        }

    # Có dữ liệu -> trả về success
    return {
        "status": "success",
        "message": "Extract cas no thành công",
        "data": results
    }


@router.post("/projects/{project_id}/msds-output")
async def extract_msds_output(project_id: str, db: Session = Depends(get_db)):
    """
    Triển khai trích xuất MSDS Output từ merged PDF của project.
    Chưa extract các trường liên quan đến vận chuyển.

    Nhập projectId --> Lấy dữ các thông tin phụ lục liên quan-->gọi openAi để trích xuất các dữ liệu liên quan.
    """
    results = await extract_msds_output_service(project_id, db)
    create_batch_outputs_service(project_id=project_id, payload=results, db=db)
    return {
        "status": "success",
        "message": "Extract thành công",
        "data": results
    }



@router.post("/project-cas-check-and-add-msds", response_model=ProjectBatchCasOut)
def project_batch_notes_by_cas(payload: ProjectBatchCasIn, db: Session = Depends(get_db)):
    """
    Kiểm tra và thêm MSDS theo danh sách CAS cho project.
    Nếu CAS đã tồn tại trong project thì bỏ qua.
    Nếu CAS chưa tồn tại thì tạo MSDS mới.
    Trả về danh sách MSDS đã có và mới tạo.
    """
    return handle_project_batch_notes_by_cas(db, payload)





@router.post("/project-cas-check-notes-preview", response_model=ProjectBatchCasOut)
def project_cas_notes_preview(payload: ProjectBatchCasIn, db: Session = Depends(get_db)):
    """
    Preview ghi chú/quy định theo danh sách CAS cho project.
    Không tạo/sửa MSDS hay MSDSChemical. Không commit DB.
    """
    return preview_project_batch_notes_by_cas(db, payload)


# ============================== SSE ENDPOINTS ==============================
@router.post("/projects/{project_id}/start")
async def start_project_processing(project_id: str, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    """
    Bắt đầu quá trình xử lý project với 3 phases: extract -> lookup -> refine
    Trả về ngay lập tức và chạy background task
    """
    # Kiểm tra project tồn tại
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Get current timestamp for timer
    started_timestamp = time.time()
    
    # Set initial state with timer
    set_project_state(project_id, {
        "status": "running", 
        "message": "Đang bắt đầu quá trình xử lý...",
        "phase": "p1",
        "data": None,
        "started_at": started_timestamp,
        "completed_at": None,
        "elapsed_ms": None
    })
    
    # Add background task
    background_tasks.add_task(process_project_phases, project_id, db)
    
    return {"message": "Project processing started", "status": "running"}


@router.get("/sse/projects/{project_id}")
async def sse_project_status(project_id: str):
    """
    SSE endpoint để lắng nghe trạng thái real-time của project
    """
    async def event_generator():
        # Gửi header SSE
        yield f"retry: 3000\n\n"
        
        while True:
            current_state = get_project_state(project_id)
            
            # Gửi event hiện tại
            event_data = json.dumps(current_state, ensure_ascii=False)
            yield f"data: {event_data}\n\n"
            
            # Nếu đã hoàn thành (success hoặc error), đóng connection
            if current_state["status"] in ["success", "error"]:
                break
                
            # Đợi 1 giây trước khi check lại
            await asyncio.sleep(1)
    
    return StreamingResponse(
        event_generator(), 
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive"
        }
    )


# ============================== BACKGROUND PROCESSING ==============================
async def process_project_phases(project_id: str, db: Session):
    """
    Background task xử lý 3 phases cho project
    """
    try:
        # Get current state to preserve timer info
        current_state = get_project_state(project_id)
        started_at = current_state.get("started_at")
        
        # Phase 1: Extract
        set_project_state(project_id, {
            "status": "running", 
            "message": "Đang thực hiện giai đoạn 1: Extract...",
            "phase": "p1",
            "data": None,
            "started_at": started_at,
            "completed_at": None,
            "elapsed_ms": None
        })
        
        # Simulate processing time
        await asyncio.sleep(3)
        extract_result = await simulate_extract_phase(project_id)
        
        # Phase 2: Lookup  
        set_project_state(project_id, {
            "status": "running", 
            "message": "Đang thực hiện giai đoạn 2: Lookup...",
            "phase": "p2", 
            "data": {"extract_result": extract_result},
            "started_at": started_at,
            "completed_at": None,
            "elapsed_ms": None
        })
        
        await asyncio.sleep(3)
        lookup_result = await simulate_lookup_phase(project_id)
        
        # Phase 3: Refine
        set_project_state(project_id, {
            "status": "running", 
            "message": "Đang thực hiện giai đoạn 3: Refine...",
            "phase": "p3",
            "data": {"extract_result": extract_result, "lookup_result": lookup_result},
            "started_at": started_at,
            "completed_at": None,
            "elapsed_ms": None
        })
        
        await asyncio.sleep(3)
        refine_result = await simulate_refine_phase(project_id)
        
        # Calculate completion time and elapsed duration
        completed_timestamp = time.time()
        elapsed_ms = int((completed_timestamp - started_at) * 1000) if started_at else None
        
        # Hoàn thành
        set_project_state(project_id, {
            "status": "success",
            "message": "Hoàn thành tất cả giai đoạn!",
            "phase": "completed",
            "data": {
                "extract_result": extract_result,
                "lookup_result": lookup_result, 
                "refine_result": refine_result
            },
            "started_at": started_at,
            "completed_at": completed_timestamp,
            "elapsed_ms": elapsed_ms
        })
        
    except Exception as e:
        # Calculate elapsed time even for error cases
        current_state = get_project_state(project_id)
        started_at = current_state.get("started_at")
        error_timestamp = time.time()
        elapsed_ms = int((error_timestamp - started_at) * 1000) if started_at else None
        
        set_project_state(project_id, {
            "status": "error",
            "message": f"Lỗi trong quá trình xử lý: {str(e)}",
            "phase": "error",
            "data": None,
            "started_at": started_at,
            "completed_at": error_timestamp,
            "elapsed_ms": elapsed_ms
        })


async def simulate_extract_phase(project_id: str):
    """Mock extract phase - thay thế bằng logic thực tế"""
    return [
        {"chemical_name": "Ethanol", "cas_number": "64-17-5", "percentage": 65.5},
        {"chemical_name": "Water", "cas_number": "7732-18-5", "percentage": 34.5}
    ]

async def simulate_lookup_phase(project_id: str):
    """Mock lookup phase - thay thế bằng logic thực tế"""
    return [
        {"cas_number": "64-17-5", "related_appendix": ["PL1", "PL2"], "notes": "Chất dễ cháy"},
        {"cas_number": "7732-18-5", "related_appendix": [], "notes": "An toàn"}
    ]

async def simulate_refine_phase(project_id: str):
    """Mock refine phase - thay thế bằng logic thực tế"""
    return {"final_preview_ready": True, "output_generated": True}



@router.get("/projects/{project_id}/msds-cas-notes", response_model=ResponseEnvelope[ProjectBatchCasOut])
def get_msds_cas_notes_for_project(
    project_id: int = Path(..., ge=1),
    db: Session = Depends(get_db),
):
    """
    Lấy danh sách MSDS và ghi chú/quy định theo CAS cho project.
    Không tạo/sửa MSDS hay MSDSChemical. Không commit DB.
    Dùng để hiển thị preview trước khi người dùng quyết định lưu.
    """

    # 1) Kiểm tra project tồn tại
    proj = db.execute(select(Project.id).where(Project.id == project_id)).scalar()
    if not proj:
        return not_found(f"Project {project_id} không tồn tại")

    # 2) Chọn cột Wt ưu tiên: wtf -> pct_wt -> wt (nếu không có thì bỏ)
    wt_expr = None
    if hasattr(MSDSChemical, "wtf"):
        wt_expr = MSDSChemical.wtf.label("wt")
    elif hasattr(MSDSChemical, "pct_wt"):
        wt_expr = MSDSChemical.pct_wt.label("wt")
    elif hasattr(MSDSChemical, "wt"):
        wt_expr = MSDSChemical.wt.label("wt")

    cols = [
        MSDS.id.label("msds_id"),
        MSDS.product_name.label("product_name"),
        MSDSChemical.cas_no.label("cas_no"),
        MSDSChemical.chemical_name.label("cas_name"),
    ]
    if wt_expr is not None:
        cols.append(wt_expr)

    # 3) Lấy toàn bộ MSDS + dòng CAS (LEFT JOIN để vẫn có MSDS không có CAS)
    rows = db.execute(
        select(*cols)
        .join(MSDSChemical, MSDSChemical.msds_id == MSDS.id, isouter=True)
        .where(MSDS.project_id == project_id)
        .order_by(MSDS.id.asc())
    ).all()

    # Không có MSDS nào → trả rỗng vẫn đúng model
    if not rows:
        return ok(ProjectBatchCasOut(project_id=project_id, items=[]), "Không có MSDS cho project này")

    # 4) Gom theo MSDS & thu tất cả CAS
    items_map: Dict[int, ProductNotes] = {}
    all_cas: set[str] = set()
    for r in rows:
        m = r._mapping
        msds_id = m["msds_id"]
        if msds_id not in items_map:
            items_map[msds_id] = ProductNotes(
                product_name=m["product_name"],
                msds_id=msds_id,
                notes_summary=[]
            )
        if m.get("cas_no"):
            all_cas.add(m["cas_no"])

    # 5) Lấy notes pháp lý cho toàn bộ CAS 1 lượt
    notes_map = _collect_notes_for_cas_list(db, list(all_cas))  # <- phải là phiên bản trả Dict[str, ChemicalNote]

    # 6) Lắp notes vào từng MSDS, điền thêm tên hóa chất & wt từ dòng MSDSChemical
    for r in rows:
        m = r._mapping
        cas_no = m.get("cas_no")
        if not cas_no:
            continue
        msds_id = m["msds_id"]

        note = notes_map.get(cas_no)
        # “Phao an toàn” nếu đâu đó còn bản cũ trả list
        if isinstance(note, list):
            note = ChemicalNote(cas_no=cas_no, hs_code=None, regulations=note)
        if note is None:
            note = ChemicalNote(cas_no=cas_no, hs_code=None, regulations=[])

        note.chemical_name = m.get("cas_name")
        note.wt = m.get("wt")

        items_map[msds_id].notes_summary.append(note)

    # 7) Trả về đúng model trong envelope
    result = ProjectBatchCasOut(project_id=project_id, items=list(items_map.values()))
    return ok(result, "Fetched successfully")