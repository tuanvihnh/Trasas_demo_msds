from fastapi import APIRouter, FastAPI, File, HTTPException, Depends, UploadFile, status, Query, Header
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, DECIMAL, ForeignKey, Boolean
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.sql import func
import base64, hashlib, secrets
from datetime import datetime, timedelta
import json
from typing import Optional, List
from sqlalchemy import UniqueConstraint, text, bindparam
from sqlalchemy.exc import IntegrityError
from app.models.models import *
from app.schemas.schemas import *
import pdfplumber, os, io, re
from fastapi.middleware.cors import CORSMiddleware
from app.utils.paginate_query import paginate_query
from fastapi.openapi.utils import get_openapi
from fastapi import APIRouter
from app.db.session import get_db
from app.core.security import (
    hash_password,
    verify_password,
    
    get_current_user,
)
from app.db.session import SessionLocal, get_db
from app.core.config import Settings
from app.utils.response import not_found, ok


router = APIRouter()


@router.post("/", response_model=GHSClassificationResponse)
def create_ghs_classification(ghs_classification: GHSClassificationCreate, db: Session = Depends(get_db)):
    """Tạo phân loại GHS mới.
    - Trả về thông tin phân loại GHS mới.
    - Nếu đã tồn tại, trả về lỗi 409.
    """
    db_ghs_classification = GHSClassification(**ghs_classification.model_dump())
    db.add(db_ghs_classification)
    db.commit()
    db.refresh(db_ghs_classification)
    return ok(db_ghs_classification, "Created successfully")

@router.get("/", response_model=List[GHSClassificationResponse])
def read_ghs_classifications(page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    """Lấy danh sách phân loại GHS với phân trang.
    - Mặc định page=1, size=10.
    - Kích thước trang tối đa là 100.
    - Trả về danh sách phân loại GHS.
    """
    ghs_classifications = paginate_query(db.query(GHSClassification), page, size).all()
    return ok(ghs_classifications, "Fetched successfully", status.HTTP_200_OK)

@router.get("/{ghs_id}", response_model=GHSClassificationResponse)
def read_ghs_classification(ghs_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin phân loại GHS theo ID.
    - Trả về thông tin phân loại GHS.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    ghs_classification = db.query(GHSClassification).filter(GHSClassification.id == ghs_id).first()
    if ghs_classification is None:
        return not_found(message="GHS Classification not found")
    return ok(ghs_classification, "Fetched successfully", status.HTTP_200_OK)


@router.put("/{ghs_id}", response_model=GHSClassificationResponse)
def update_ghs_classification(ghs_id: int, ghs_classification: GHSClassificationCreate, db: Session = Depends(get_db)):
    """Cập nhật thông tin phân loại GHS theo ID.
    - Trả về thông tin phân loại GHS đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_ghs_classification = db.query(GHSClassification).filter(GHSClassification.id == ghs_id).first()
    if db_ghs_classification is None:
        return not_found(message="GHS Classification not found")
    for key, value in ghs_classification.model_dump(exclude_unset=True).items():
        setattr(db_ghs_classification, key, value)
    db.commit()
    db.refresh(db_ghs_classification)
    return ok(db_ghs_classification, "Updated successfully", status.HTTP_200_OK)

@router.delete("/{ghs_id}")
def delete_ghs_classification(ghs_id: int, db: Session = Depends(get_db)):
    """Xoá phân loại GHS theo ID.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_ghs_classification = db.query(GHSClassification).filter(GHSClassification.id == ghs_id).first()
    if db_ghs_classification is None:
        return not_found(message="GHS Classification not found")
    db.delete(db_ghs_classification)
    db.commit()
    return ok(None, "Deleted successfully")
