# app/api/license.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import asc, desc, or_
from typing import Optional, Literal
from app.db.session import get_db
from app.models.models import License
from app.schemas.schemas import (
    LicenseCreate, LicenseUpdate, LicenseOut
)
from app.utils.response import ok, not_found, conflict

router = APIRouter()

# ===== LIST =====
@router.get("/", summary="List licenses")
def list_licenses(
    db: Session = Depends(get_db),
    q: Optional[str] = None,
    status: Optional[int] = None,
    created_by: Optional[int] = None,
    updated_by: Optional[int] = None,
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1),
    sort_field: Literal["id","title","status","created_at","updated_at"] = "updated_at",
    sort_order: Literal["asc","desc"] = "desc",
):
    """Lấy danh sách license với phân trang.
    - Có thể lọc theo q (tìm trong title, content, description), status, created_by, updated_by.
    - Mặc định page=1, size=50.
    - Mặc định sort_field=updated_at, sort_order=desc.
    - Trả về danh sách license.
    """
    qry = db.query(License)

    if q:
        like = f"%{q}%"
        qry = qry.filter(or_(License.title.ilike(like),
                             License.content.ilike(like),
                             License.description.ilike(like)))
    if status is not None:
        qry = qry.filter(License.status == status)
    if created_by is not None:
        qry = qry.filter(License.created_by == created_by)
    if updated_by is not None:
        qry = qry.filter(License.updated_by == updated_by)

    ORDER_MAP = {
        "id": License.id,
        "title": License.title,
        "status": License.status,
        "created_at": License.created_at,
        "updated_at": License.updated_at,
    }
    col = ORDER_MAP[sort_field]
    qry = qry.order_by(asc(col) if sort_order == "asc" else desc(col))

    total = qry.count()
    rows = qry.offset((page - 1) * size).limit(size).all()
    items = [LicenseOut.model_validate(x) for x in rows]
    return ok({"page": page, "size": size, "total": total, "items": items}, "Fetched successfully")

# ===== GET BY ID =====
@router.get("/{license_id}", summary="Get license by id")
def get_license(license_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin license theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông tin license.
    """
    obj = db.get(License, license_id)
    if not obj:
        return not_found("license not found")
    return ok(LicenseOut.model_validate(obj), "Fetched successfully")

# ===== CREATE =====
@router.post("/", summary="Create license")
def create_license(payload: LicenseCreate, db: Session = Depends(get_db)):
    """Tạo license mới.
    - Trả về thông tin license mới.
    - Nếu đã tồn tại, trả về lỗi 409.
    
    """
    # chống trùng title nếu bạn muốn
    if db.query(License).filter(License.title == payload.title).first():
        return conflict("title đã tồn tại")
    obj = License(**payload.model_dump(exclude={"created_at","updated_at","updated_by"}))
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return ok(LicenseOut.model_validate(obj), "Created successfully")

# ===== UPDATE =====
@router.put("/{license_id}", summary="Update license")
def update_license(license_id: int, payload: LicenseUpdate, db: Session = Depends(get_db)):
    """Cập nhật license theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông tin license đã cập nhật.
    """
    obj = db.get(License, license_id)
    if not obj:
        raise HTTPException(status_code=404, detail="license not found")

    if payload.title and payload.title != obj.title:
        if db.query(License).filter(License.title == payload.title).first():
            return conflict("title đã tồn tại")

    for f, v in payload.model_dump(exclude_unset=True).items():
        setattr(obj, f, v)

    db.commit()
    db.refresh(obj)
    return ok(LicenseOut.model_validate(obj), "Updated")

# ===== DELETE =====
@router.delete("/{license_id}", summary="Delete license")
def delete_license(license_id: int, db: Session = Depends(get_db)):
    """Xoá license theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông báo xoá thành công.
    
    """
    obj = db.get(License, license_id)
    if not obj:
        raise HTTPException(status_code=404, detail="license not found")
    db.delete(obj)
    db.commit()
    return ok({"deleted": 1}, "Deleted")
