from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Query, Response, status, Path
from typing import List, Optional
from sqlalchemy import or_
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.models.models import *
from app.schemas.schemas import *
from app.utils.links import _resolve_chem_id, _resolve_chemical_id, _resolve_regapp_id, _sa_to_dict
from app.utils.paginate_query import paginate_query
from app.db.session import get_db
from app.services import chemical_mapping as svc
from app.utils.response import conflict, not_found, ok, fail
from app.schemas.common import ResponseEnvelope, Paginated, PageMeta
from sqlalchemy import text as sql_text
from app.utils.links import *

router = APIRouter()


@router.post("/msds_chemicals/")
def create_msds_chemical(link: MSDSChemicalBase, db: Session = Depends(get_db)):
    """Tạo liên kết giữa MSDS và hóa chất.
    - Yêu cầu `msds_id` và ít nhất một trong hai trường `cas_no` hoặc `chemical_name`.
    - Trả về thông tin liên kết.
    - Nếu liên kết đã tồn tại, trả về lỗi 409.
    """
    if not (link.cas_no or link.chemical_name):
        return fail(message="Either cas_no or chemical_name is required")

    q = db.query(MSDSChemical).filter(MSDSChemical.msds_id == link.msds_id)
    if link.cas_no:
        q = q.filter(MSDSChemical.cas_no == link.cas_no)
    else:
        q = q.filter(MSDSChemical.chemical_name == link.chemical_name)
    if db.query(q.exists()).scalar():
        return conflict(message="Link already exists")


    obj = MSDSChemical(**link.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)

    return ok(data=obj, message="Created successfully")



@router.get("/msds_chemicals/", response_model=List[MSDSChemicalBase])
def read_msds_chemicals(page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    """Lấy danh sách liên kết MSDS - Hóa chất với phân trang.
    - Mặc định page=1, size=10.
    - Kích thước trang tối đa là 100.
    - Trả về danh sách liên kết MSDS - Hóa chất.
    """
    links = paginate_query(db.query(MSDSChemical), page, size).all()
    return ok(links, "Fetched successfully", status.HTTP_200_OK)

@router.delete("/msds_chemicals/{id}")
def delete_msds_chemical(id: int, db: Session = Depends(get_db)) -> Response:
    """Xoá liên kết MSDS - Hóa chất theo ID.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    obj = db.get(MSDSChemical, id)
    if not obj:
        return not_found(message="MSDSChemical not found")
    db.delete(obj)
    db.commit()
    return ok(None, "Deleted successfully")

@router.delete("/msds_chemicals/{msds_id}/{cas_no}")
def delete_msds_chemical(msds_id: int, cas_no: str = Path(..., description="CAS No of the chemical"), db: Session = Depends(get_db)):
    """Xoá liên kết MSDS - Hóa chất theo MSDS ID và CAS No.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_link = db.query(MSDSChemical).filter(
        MSDSChemical.msds_id == msds_id,
        MSDSChemical.cas_no == cas_no
    ).first()
    if db_link is None:
        return not_found(message="MSDS-Chemical link not found")
    db.delete(db_link)
    db.commit()
    return ok(None, "Deleted successfully")



# @router.get("/", response_model=ResponseEnvelope[Paginated[ChemicalMapping]])
# def list_chemical_mappings(
#     chemical_id: int | None = Query(default=None),
#     regulation_id: int | None = Query(default=None),
#     article_id: int | None = Query(default=None),
#     appendix_id: int | None = Query(default=None),
#     status_: int | None = Query(default=None, alias="status"),
#     offset: int = Query(0, ge=0),
#     limit: int = Query(50, ge=1, le=200),
#     db: Session = Depends(get_db),
# ):
#     total, items = svc.list_mappings(
#         db,
#         chemical_id=chemical_id,
#         regulation_id=regulation_id,
#         article_id=article_id,
#         appendix_id=appendix_id,
#         status=status_,
#         offset=offset,
#         limit=limit,
#     )
#     payload = {
#         "meta": PageMeta(total=total, offset=offset, limit=limit).model_dump(),
#         "items": [i for i in items],
#     }
#     return ok(payload, message="Fetched chemical mappings")

# @router.get("/{mapping_id}", response_model=ResponseEnvelope[ChemicalMapping])
# def get_chemical_mapping(mapping_id: int, db: Session = Depends(get_db)):
#     obj = svc.get(db, mapping_id)
#     if not obj:
#         return fail("Chemical mapping not found", http_status=status.HTTP_404_NOT_FOUND)
#     return ok(obj, message="Fetched chemical mapping")

# @router.post("/", response_model=ResponseEnvelope[ChemicalMapping])
# def create_chemical_mapping(payload: ChemicalMappingCreate, db: Session = Depends(get_db)):
#     obj = svc.create(db, payload)
#     return ok(obj, message="Created chemical mapping", http_status=status.HTTP_201_CREATED)

# @router.put("/{mapping_id}", response_model=ResponseEnvelope[ChemicalMapping])
# def update_chemical_mapping(mapping_id: int, payload: ChemicalMappingUpdate, db: Session = Depends(get_db)):
#     obj = svc.update_one(db, mapping_id, payload)
#     if not obj:
#         return fail("Chemical mapping not found", http_status=status.HTTP_404_NOT_FOUND)
#     return ok(obj, message="Updated chemical mapping")

# @router.delete("/{mapping_id}", response_model=ResponseEnvelope[None], status_code=status.HTTP_200_OK)
# def delete_chemical_mapping(mapping_id: int, db: Session = Depends(get_db)):
#     ok_ = svc.delete_one(db, mapping_id)
#     if not ok_:
#         return fail("Chemical mapping not found", http_status=status.HTTP_404_NOT_FOUND)
#     return ok(None, message="Deleted chemical mapping")

@router.post("/chemical_mappings", response_model=ResponseEnvelope[ChemicalMappingOut])
def create_mapping(body: ChemicalMappingIn, db: Session = Depends(get_db)):
    """Tạo bản ghi ChemicalMapping mới.
    - Yêu cầu `chemical_id` hoặc `cas_no`, và `appendix_id` hoặc `code`.
    - Trả về thông tin bản ghi đã tạo.
    - Nếu bản ghi đã tồn tại (cùng chemical_id và appendix_id), trả về lỗi 409.
    """
    chem_id = _resolve_chem_id(db, body.chemical_id, body.cas_no)
    reg_id  = _resolve_regapp_id(db, body.appendix_id, body.code)
    obj = ChemicalMapping(chemical_id=chem_id, appendix_id=reg_id, status=body.status or 1)
    db.add(obj); db.commit(); db.refresh(obj)
    return ok(obj)

@router.get("/chemical_mappings", response_model=ResponseEnvelope[list[ChemicalMappingOut]])
def list_mappings(db: Session = Depends(get_db), cas_no: str | None = None, chemical_id: int | None = None, reg_code: str | None = None, page: int = 1, size: int = 50):
    """Lấy danh sách bản ghi ChemicalMapping kèm thông tin hoá chất và Appendix liên quan.
    - Có thể lọc theo cas_no (Chemical.cas_no), chemical_id (Chemical.id), reg_code (Regulation.code).
    - Mặc định page=1, size=50.
    - Trả về danh sách bản ghi ChemicalMapping với phân trang.
    """
    q = db.query(ChemicalMapping)
    if chemical_id: q = q.filter(ChemicalMapping.chemical_id == chemical_id)
    if cas_no: q = q.join(Chemical).filter(Chemical.cas_no == cas_no)
    if reg_code: q = q.join(RegulationAppendix).filter(RegulationAppendix.code == reg_code)
    
    total = q.order_by(None).count()
    items = q.order_by(ChemicalMapping.id.desc()).offset((page-1)*size).limit(size).all()
    return ok({"meta": {"total": total, "page": page, "page_size": size}, "items": items})


@router.patch("/chemical_mappings/{mapping_id}", response_model=ResponseEnvelope[ChemicalMappingOut])
def update_mapping(mapping_id: int, body: ChemicalMappingUpdateIn, db: Session = Depends(get_db)):
    """Cập nhật bản ghi ChemicalMapping theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông tin bản ghi đã cập nhật.
    """
    obj = db.query(ChemicalMapping).get(mapping_id)
    if not obj:
        return not_found(message="Not found")

    if body.cas_no or body.chemical_id:
        obj.chemical_id = _resolve_chemical_id(db, body.chemical_id, body.cas_no)

    for f in ["status"]:
        v = getattr(body, f)
        if v is not None:
            setattr(obj, f, v)

    db.commit(); db.refresh(obj)
    return ok(ChemicalMappingOut(**obj.__dict__))

@router.delete("/chemical_mappings/{mapping_id}", response_model=ResponseEnvelope[dict])
def delete_mapping(mapping_id: int, db: Session = Depends(get_db)):
    """Xoá bản ghi ChemicalMapping theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông báo xoá thành công.
    
    """
    obj = db.query(ChemicalMapping).get(mapping_id)
    if not obj:
        return not_found(message="Not found")
    db.delete(obj); db.commit()
    return ok({"id": mapping_id})

# ------------------------------------------------------------------------------------------------







