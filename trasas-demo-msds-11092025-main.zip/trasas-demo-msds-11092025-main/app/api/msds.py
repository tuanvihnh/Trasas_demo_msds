from fastapi import APIRouter, HTTPException, Depends, status, Query
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.core.security import get_current_user
from app.models.models import MSDS, MSDSChemical, Project, User
from app.schemas.schemas import (
    MSDSCreate, MSDSResponse, MsdsCasNoResponse, MsdsIn, MsdsCreateResult, MsdsUpdateIn
)
from app.utils.paginate_query import paginate_query
from app.utils.response import not_found, ok

router = APIRouter()

# --- helpers ---------------------------------------------------------------

def _map_msds_payload_to_columns(data: Dict[str, Any]) -> Dict[str, Any]:
    # exposure_controls (schema) -> exposure_control (DB)
    mapped = dict(data)
    if "exposure_controls" in mapped:
        mapped["exposure_control"] = mapped.pop("exposure_controls")
    # Field không có trong DB
    mapped.pop("personal_protection", None)
    return mapped

# --- CRUD ------------------------------------------------------------------


@router.post("/", response_model=MSDSResponse)
def create_msds(msds: MSDSCreate, db: Session = Depends(get_db)):
    """Tạo mới một MSDS.
    - Trả về thông tin MSDS vừa tạo.
    - Nếu có lỗi, trả về lỗi 400.
    """
    payload = _map_msds_payload_to_columns(msds.model_dump(exclude_unset=True))
    row = MSDS(**payload)
    db.add(row)
    db.commit()
    db.refresh(row)
    return ok(row, "Created successfully")

@router.get("/", response_model=List[MSDSResponse])
def read_all_msds(
    page: int = Query(1, ge=1),
    size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
):
    """Lấy danh sách MSDS với phân trang.
    - Mặc định page=1, size=10.
    - Kích thước trang tối đa là 100.
    - Trả về danh sách MSDS.
    """
    # return paginate_query(db.query(MSDS), page, size).all()
    return ok(paginate_query(db.query(MSDS), page, size).all(), "Fetched successfully", status.HTTP_200_OK)

@router.get("/{msds_id}", response_model=MSDSResponse)
def read_msds(msds_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin MSDS theo ID.
    - Trả về thông tin MSDS.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    row = db.get(MSDS, msds_id)
    if not row:
        return not_found(message="MSDS not found")
    return ok(row, "Fetched successfully", status.HTTP_200_OK)

@router.put("/{msds_id}", response_model=MSDSResponse)
def update_msds(msds_id: int, msds: MSDSCreate, db: Session = Depends(get_db)):
    """Cập nhật thông tin MSDS theo ID.
    - Trả về thông tin MSDS đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    row = db.get(MSDS, msds_id)
    if not row:
        return not_found(message="MSDS not found")
    payload = _map_msds_payload_to_columns(msds.model_dump(exclude_unset=True))
    for k, v in payload.items():
        setattr(row, k, v)
    db.commit()
    db.refresh(row)
    return ok(row, "Updated successfully", status.HTTP_200_OK)

@router.delete("/{msds_id}")
def delete_msds(msds_id: int, db: Session = Depends(get_db)):
    """Xoá MSDS theo ID.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    row = db.get(MSDS, msds_id)
    if not row:
        return not_found(message="MSDS not found")
    db.delete(row)
    db.commit()
    return ok(None, "Deleted successfully")

class AssignProjectIn(MsdsUpdateIn):
    project_id: Optional[int] = None

@router.patch("/{msds_id}/project")
def assign_project(
    msds_id: int,
    body: AssignProjectIn,
    db: Session = Depends(get_db),
    current: User = Depends(get_current_user),
):
    """Gán hoặc bỏ gán MSDS vào Project.
    - Nếu `project_id` là null, bỏ gán MSDS khỏi Project.
    - Trả về thông tin MSDS đã cập nhật.
    - Nếu MSDS hoặc Project không tồn tại, trả về lỗi 404.
    """
    row = db.get(MSDS, msds_id)
    if not row:
        return not_found(message="MSDS not found")
    if body.project_id is not None and not db.get(Project, body.project_id):
        return not_found(message="Project not found")
    row.project_id = body.project_id
    db.commit()
    return ok(row, "Updated successfully", status.HTTP_200_OK)

# --- Intake từ OpenAI (schema mới msds_chemicals không còn chemical_id) ----

@router.post("/openai/intake", response_model=MsdsCreateResult)
def intake_msds(payload: MsdsIn, db: Session = Depends(get_db)):
    """Tiếp nhận MSDS từ OpenAI.
    - Tạo mới MSDS và các liên kết MSDSChemical.
    - Trả về thông tin mới tạo.
    - Nếu có lỗi, trả về lỗi 400.
    """
    msds_data = _map_msds_payload_to_columns(
        payload.model_dump(exclude={"chemical"}, exclude_unset=True)
    )
    row = MSDS(**msds_data)
    db.add(row)
    db.flush()  # có row.id

    linked = 0
    for c in payload.chemical or []:
        db.add(MSDSChemical(
            msds_id=row.id,
            chemical_name=(c.chemical_name or "").strip() or None,
            cas_no=c.cas_number or None,
            percentage=c.percentage,
            wtf=c.wtf,
            role=c.role or "Active",
            status=True
        ))
        linked += 1


    db.commit()
    # return MsdsCreateResult(msds_id=row.id, project_id=row.project_id, linked_chemicals=linked)
    return ok(MsdsCreateResult(msds_id=row.id, project_id=row.project_id, linked_chemicals=linked), "Created successfully")

# --- Deep view -------------------------------------------------------------

@router.get("/{msds_id}/deep")
def get_msds_deep(msds_id: int, db: Session = Depends(get_db)):
    """
    Lây thông tin chi tiết của MSDS cùng với danh sách các hóa chất liên quan.
    - Trả về thông tin MSDS và danh sách các hóa chất liên quan.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    row = db.get(MSDS, msds_id)
    if not row:
        return not_found(message="MSDS không tồn tại")

    comps = (
        db.query(MSDSChemical)
        .filter(MSDSChemical.msds_id == msds_id)
        .order_by(MSDSChemical.id.asc())
        .all()
    )
    chemicals = [
        {
            "chemical_name": c.chemical_name,
            "cas_no": c.cas_no,
            "percentage": float(c.percentage) if c.percentage is not None else None,
            "wtf": c.wtf,
            "role": c.role,
            "status": c.status,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        } for c in comps
    ]

    data = {
        "msds": {
            "id": row.id,
            "project_id": row.project_id,
            "product_name": row.product_name,
            "msds_no": row.msds_no,
            "manufacturer_name": row.manufacturer_name,
            "manufacturer_address": row.manufacturer_address,
            "manufacturer_phone": row.manufacturer_phone,
            "signal_word": row.signal_word,
            "hazard_statements": row.hazard_statements,
            "precautionary_statements_text": row.precautionary_statements_text,
            "ghs_symbols_text": row.ghs_symbols_text,
            "composition_info": row.composition_info,
            "ingredient_percentage": row.ingredient_percentage,
            "first_aid_measures": row.first_aid_measures,
            "fire_fighting_measures": row.fire_fighting_measures,
            "accidental_release_measures": row.accidental_release_measures,
            "handling_storage": row.handling_storage,
            "exposure_control": row.exposure_control,
            "physical_chemical_properties": row.physical_chemical_properties,
            "stability_reactivity": row.stability_reactivity,
            "toxicological_info": row.toxicological_info,
            "ecological_info": row.ecological_info,
            "disposal_considerations": row.disposal_considerations,
            "transport_info": row.transport_info,
            "regulatory_info": row.regulatory_info,
            "other_info": row.other_info,
            "status": row.status,
            "created_at": row.created_at,
            "updated_at": row.updated_at,
        },
        "chemicals": chemicals,
    }
    return ok(data, "Fetched successfully", status.HTTP_200_OK)


@router.get("/{msds_id}", response_model=MsdsCasNoResponse)
def get_msds_casnos(msds_id: int, db: Session = Depends(get_db)):
    """
    Lấy danh sách CAS No của các hóa chất liên quan đến MSDS theo MSDS ID.
    - Trả về danh sách CAS No.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    casnos = db.query(MSDSChemical.cas_no).filter(MSDSChemical.msds_id == msds_id).distinct().all()
    cas_list = [cas[0] for cas in casnos if cas[0] is not None]
    return ok(cas_list, "Fetched successfully", status.HTTP_200_OK)