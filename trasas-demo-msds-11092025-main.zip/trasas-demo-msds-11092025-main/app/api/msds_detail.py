from fastapi import APIRouter, Depends, HTTPException, Path, Query
from sqlalchemy.orm import Session
from sqlalchemy import select, join
from typing import List, Optional

from app.db.session import get_db
from app.models.models import MSDS, MSDSChemical, Project, ChemicalMapping, RegulationAppendix, Chemical
from app.schemas.msds_api import MsdsChemicalsResponse, MsdsChemicalItem, MsdsNotesResponse, MsdsNoteItem
from app.schemas.common import ResponseEnvelope
from app.utils.response import ok, not_found, fail

router = APIRouter()

@router.get("/projects/{project_id}/msds/{msds_id}/chemicals", response_model=ResponseEnvelope[MsdsChemicalsResponse])
async def get_msds_chemicals(
    project_id: int = Path(..., ge=1),
    msds_id: int = Path(..., ge=1),
    search: Optional[str] = Query(None),
    sort_by: Optional[str] = Query(None, regex="^(chemical_name|cas_no|percentage|created_at)$"),
    sort_dir: Optional[str] = Query("asc", regex="^(asc|desc)$"),
    db: Session = Depends(get_db)
):
    """
    Lấy danh sách thành phần hóa chất của một MSDS thuộc project
    - Không phân trang
    - Có thể search theo chemical_name hoặc cas_no
    - Có thể sắp xếp theo chemical_name, cas_no, percentage, created_at
    """
    # Kiểm tra project tồn tại
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        return not_found("Project không tồn tại")
    
    # Kiểm tra msds thuộc project
    msds = db.query(MSDS).filter(MSDS.id == msds_id, MSDS.project_id == project_id).first()
    if not msds:
        return not_found("MSDS không tồn tại hoặc không thuộc project này")
    
    # Query MSDSChemical
    query = db.query(MSDSChemical).filter(MSDSChemical.msds_id == msds_id)
    
    # Áp dụng search nếu có
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            (MSDSChemical.chemical_name.ilike(search_term)) |
            (MSDSChemical.cas_no.ilike(search_term))
        )
    
    # Áp dụng sort
    if sort_by:
        column = getattr(MSDSChemical, sort_by if sort_by != "cas_number" else "cas_no")
        if sort_dir == "desc":
            query = query.order_by(column.desc())
        else:
            query = query.order_by(column.asc())
    else:
        # Mặc định sắp xếp theo chemical_name
        query = query.order_by(MSDSChemical.chemical_name.asc())
    
    # Thực thi query
    chemicals = query.all()
    
    # Map sang response schema
    items = [
        MsdsChemicalItem(
            chemical_name=chem.chemical_name,
            cas_number=chem.cas_no,
            percentage=chem.percentage,
            wtf=chem.wtf
        ) for chem in chemicals
    ]
    
    return ok(
        MsdsChemicalsResponse(
            project_id=project_id,
            msds_id=msds_id,
            items=items
        )
    )

@router.get("/projects/{project_id}/msds/{msds_id}/notes", response_model=ResponseEnvelope[MsdsNotesResponse])
async def get_msds_notes(
    project_id: int = Path(..., ge=1),
    msds_id: int = Path(..., ge=1),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Lấy danh sách ghi chú theo CAS của một MSDS thuộc project
    - Không phân trang
    - Có thể search theo cas_no
    - related_appendix là danh sách title từ bảng regulation_appendix
    """
    # Kiểm tra project tồn tại
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        return not_found("Project không tồn tại")
    
    # Kiểm tra msds thuộc project
    msds = db.query(MSDS).filter(MSDS.id == msds_id, MSDS.project_id == project_id).first()
    if not msds:
        return not_found("MSDS không tồn tại hoặc không thuộc project này")
    
    # Lấy danh sách CAS từ MSDSChemical
    query = db.query(MSDSChemical).filter(MSDSChemical.msds_id == msds_id)
    
    # Áp dụng search nếu có
    if search:
        search_term = f"%{search}%"
        query = query.filter(MSDSChemical.cas_no.ilike(search_term))
    
    chemicals = query.all()
    
    # Tạo danh sách notes
    result_items = []
    for chem in chemicals:
        if not chem.cas_no:
            continue
            
        # Tìm các regulation_appendix liên quan đến cas_no này
        # Thông qua ChemicalMapping
        related_appendix_titles = []
        notes_text = ""
        
        # Tìm chemical_id từ cas_no
        stmt = select(ChemicalMapping.appendix_id).join(
            RegulationAppendix, 
            RegulationAppendix.id == ChemicalMapping.appendix_id
        ).where(
            ChemicalMapping.chemical_id.in_(
                select(Chemical.id).where(Chemical.cas_no == chem.cas_no)
            )
        )
        
        appendix_ids = [row[0] for row in db.execute(stmt).fetchall()]
        
        if appendix_ids:
            # Lấy title của các regulation_appendix
            appendix_records = db.query(RegulationAppendix).filter(
                RegulationAppendix.id.in_(appendix_ids)
            ).all()
            
            related_appendix_titles = [app.title for app in appendix_records if app.title]
            
            # Tổng hợp notes
            notes_parts = []
            for app in appendix_records:
                if app.note:
                    notes_parts.append(app.note)
            
            notes_text = " | ".join(notes_parts) if notes_parts else "Không có ghi chú"
        else:
            notes_text = "Không có thông tin phụ lục liên quan"
        
        # Thêm vào kết quả
        result_items.append(
            MsdsNoteItem(
                cas_number=chem.cas_no,
                related_appendix=related_appendix_titles,
                notes=notes_text
            )
        )
    
    return ok(
        MsdsNotesResponse(
            project_id=project_id,
            msds_id=msds_id,
            items=result_items
        )
    )
