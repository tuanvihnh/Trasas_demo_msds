# api/output.py - only routers and service calls

from fastapi import APIRouter, Depends, HTTPException, Query, status
from typing import List, Optional, Dict, Any , Set, Tuple
from sqlalchemy import delete, select
from sqlalchemy.orm import Session
from app.models.models import *
from app.schemas.schemas import *
from app.schemas.schemas import OutputFromAI  # Add this import if OutputFromAI is defined in schemas
from app.db.session import get_db
from app.core.security import get_current_user
from app.utils.response import not_found, ok
from sqlalchemy.orm import Session, joinedload, selectinload
from app.models.models import Project
from datetime import datetime
from app.data.project import  mock_projects_with_msds
from app.services.outputAll import (get_mock_outputs_service, create_output_from_ai_service, list_outputs_service, get_output_service, update_output_service, delete_output_service, delete_outputs_by_project_service, create_batch_outputs_service, get_full_outputs_service)

router = APIRouter()

@router.get("/list-outputs", response_model=dict)
def get_list_outputs(db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    return get_mock_outputs_service(db, current)

@router.get("/{project_id}/outputIdProject", response_model=dict)
def get_full_outputs(project_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    return get_full_outputs_service(project_id, db, current)

@router.post("/", response_model=OutputResponse)
def create_output_from_ai(payload: OutputFromAI, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    return create_output_from_ai_service(payload, db, current)

@router.get("/", response_model=dict)
def list_outputs(db: Session = Depends(get_db)):
    return list_outputs_service(db)

@router.get("/{output_id}", response_model=dict)
def get_output(output_id: int, db: Session = Depends(get_db)):
    return get_output_service(output_id, db)

@router.put("/{output_id}", response_model=OutputResponse)
def update_output(output_id: int, payload: OutputUpdate, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    return update_output_service(output_id, payload, db, current)

@router.delete("/{output_id}", response_model=dict)
def delete_output(output_id: int, db: Session = Depends(get_db)):
    return delete_output_service(output_id, db)

@router.delete("/{project_id}/outputs", response_model=dict)
def delete_outputs_by_project(project_id: int, db: Session = Depends(get_db)):
    return delete_outputs_by_project_service(project_id, db)

@router.post("/{project_id}/batch", response_model=dict)
def create_batch_outputs(
    project_id: int, 
    payload: List[BatchOutputItemIn], 
    db: Session = Depends(get_db), 
    
):
    return create_batch_outputs_service(project_id, payload, db)

@router.get("/{project_id}/full-outputs", response_model=dict)
def get_full_outputs(project_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    return get_full_outputs_service(project_id, db, current)

