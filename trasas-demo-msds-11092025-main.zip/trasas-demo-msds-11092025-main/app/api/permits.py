# api/permits.py - only routers and service calls

from fastapi import APIRouter, Depends, HTTPException, Query, Path
from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from typing import Optional, List

from app.db.session import get_db
from app.models.models import OutputPermit
from app.utils.response import ok, not_found
from app.schemas.common import ResponseEnvelope, Paginated
from app.schemas.schemas import OutputPermitIn, OutputPermitUpdate, OutputPermitOut
from app.services.outputAll import (list_output_permits_service, get_output_permit_service, create_output_permit_service, update_output_permit_service, update_output_permit_partial_service, delete_output_permit_service)

router = APIRouter()

@router.get("/", response_model=ResponseEnvelope[Paginated[OutputPermitOut]])
def list_output_permits(
    db: Session = Depends(get_db),
    output_id: Optional[int] = Query(None),
    un_number: Optional[str] = Query(None),
    match_chemical_name_core_component: Optional[bool] = Query(None),
    match_un_number: Optional[bool] = Query(None),
    license_number: Optional[str] = Query(None),
    license_plate_number: Optional[str] = Query(None),
    route_allowed: Optional[str] = Query(None),
    status: Optional[bool] = Query(None),
    q: Optional[str] = Query(None, description="search in un_number"),
    page: int = 1,
    size: int = 50,
):
    return list_output_permits_service(db, output_id, un_number, match_chemical_name_core_component, match_un_number, license_number, license_plate_number, route_allowed, status, q, page, size)

@router.get("/{permit_id}", response_model=ResponseEnvelope[OutputPermitOut])
def get_output_permit(permit_id: int, db: Session = Depends(get_db)):
    return get_output_permit_service(permit_id, db)

@router.post("/", response_model=ResponseEnvelope[OutputPermitOut])
def create_output_permit(body: OutputPermitIn, db: Session = Depends(get_db)):
    return create_output_permit_service(body, db)

@router.put("/{permit_id}", response_model=dict)
def update_output_permit(permit_id: int, payload: OutputPermitUpdate, db: Session = Depends(get_db)):
    return update_output_permit_service(permit_id, payload, db)

@router.patch("/{permit_id}", response_model=ResponseEnvelope[OutputPermitOut])
def update_output_permit_partial(permit_id: int, body: OutputPermitUpdate, db: Session = Depends(get_db)):
    return update_output_permit_partial_service(permit_id, body, db)

@router.delete("/{permit_id}")
def delete_output_permit(permit_id: int, db: Session = Depends(get_db)):
    return delete_output_permit_service(permit_id, db)