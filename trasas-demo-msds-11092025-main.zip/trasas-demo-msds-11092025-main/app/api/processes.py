from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict
from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from app.models.models import *
from app.utils.paginate_query import paginate_query
from app.db.session import get_db
from app.utils.response import not_found, ok


router = APIRouter()


@router.post("/", response_model=ProcessResponse)
def create_process(process: ProcessCreate, db: Session = Depends(get_db)):
    """Tạo quy trình mới.
    - Trả về thông tin quy trình mới.
    - Nếu đã tồn tại, trả về lỗi 409.
    """
    db_process = Process(**process.model_dump())
    db.add(db_process)
    db.commit()
    db.refresh(db_process)
    # return db_process
    return ok(db_process, "Created successfully")

@router.get("/", response_model=List[ProcessResponse])
def read_processes(page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    """Lấy danh sách quy trình với phân trang.
    - Mặc định page=1, size=10.
    - Kích thước trang tối đa là 100.
    - Trả về danh sách quy trình.
    """
    processes = paginate_query(db.query(Process), page, size).all()
    # return processes
    return ok(processes, "Fetched successfully", status.HTTP_200_OK)

@router.get("/{process_id}", response_model=ProcessResponse)
def read_process(process_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin quy trình theo ID.
    - Trả về thông tin quy trình.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    process = db.query(Process).filter(Process.id == process_id).first()
    if process is None:
        return not_found(message="Process not found")
    # return process
    return ok(process, "Fetched successfully", status.HTTP_200_OK)

@router.put("/{process_id}", response_model=ProcessResponse)
def update_process(process_id: int, process: ProcessCreate, db: Session = Depends(get_db)):
    """Cập nhật thông tin quy trình theo ID.
    - Trả về thông tin quy trình đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_process = db.query(Process).filter(Process.id == process_id).first()
    if db_process is None:
        return not_found(message="Process not found")
    for key, value in process.model_dump(exclude_unset=True).items():
        setattr(db_process, key, value)
    db.commit()
    db.refresh(db_process)
    # return db_process
    return ok(db_process, "Updated successfully", status.HTTP_200_OK)

@router.delete("/{process_id}")
def delete_process(process_id: int, db: Session = Depends(get_db)):
    """Xoá quy trình theo ID.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_process = db.query(Process).filter(Process.id == process_id).first()
    if db_process is None:
        return not_found(message="Process not found")
    db.delete(db_process)
    db.commit()
    return ok(None, "Deleted successfully")