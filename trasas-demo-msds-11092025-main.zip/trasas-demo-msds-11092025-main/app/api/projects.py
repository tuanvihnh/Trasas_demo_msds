from fastapi import APIRouter, BackgroundTasks, FastAPI, File, HTTPException, Depends, UploadFile, status, Query, Header
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime
from sqlalchemy.orm import Session, selectinload
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, DECIMAL, ForeignKey, Boolean, delete, select
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.sql import func
import base64, hashlib, secrets
from datetime import datetime, timedelta
import json
from typing import Optional, List
from sqlalchemy import UniqueConstraint, text, bindparam
from sqlalchemy.exc import IntegrityError
from app.models.models import *
from app.schemas.common import ResponseEnvelope
from app.schemas.schemas import *
import pdfplumber, os, io, re
from fastapi.middleware.cors import CORSMiddleware

from app.services.chemical_extract import upload_pdf_to_vector_store_and_log
from app.services.project_services import upload_files_to_project_service
from app.utils.chemical_extract_utils import merge_project_pdfs
from app.services.extracts_service import handle_project_batch_notes_by_cas, save_second_extract, save_second_extract_batch
from app.utils.links import _sa_to_dict

from app.utils.paginate_query import paginate_query
from fastapi.openapi.utils import get_openapi
from fastapi import APIRouter
from app.db.session import get_db
from app.core.security import (
    hash_password,
    verify_password,
    get_current_user,
)
from app.db.session import SessionLocal, get_db
from app.core.config import Settings
from app.data.project import mock_chemical_products, mock_projects_with_msds
from app.utils.response import not_found, ok
from sqlalchemy import text as sql_text
from sqlalchemy.orm import joinedload

router = APIRouter()




@router.post("/", response_model=ProjectOut)
def create_project(
    payload: ProjectCreate,
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    """Tạo project mới.
    - Trả về thông tin project mới.
    - Nếu có lỗi, trả về lỗi 400.
    """
    data = payload.dict()
    if data.get("user_id") is None:
        data["user_id"] = current.id

    # if db.query(Project).filter(Project.project_name == data["project_name"]).first():
    #     return fail(message="project_name already exists")

    row = Project(**data)
    db.add(row); db.commit(); db.refresh(row)
    # return row
    return ok(row, "Created successfully")

@router.get("/", response_model=List[ProjectOut])
def list_projects(db: Session = Depends(get_db), q: str | None = None, user_id: int | None = None):
    """Lấy danh sách project.
    - Trả về danh sách project.
    - Có thể lọc theo từ khoá `q` (tìm trong tên project) và `user_id`.
    """
    qry = db.query(Project)
    if q:
        like = f"%{q}%"
        qry = qry.filter((Project.project_name.ilike(like)))
    if user_id is not None:
        qry = qry.filter(Project.user_id == user_id)
    # return qry.order_by(Project.id.desc()).all()
    return ok(qry.order_by(Project.id.desc()).all(), "Fetched successfully", status.HTTP_200_OK)

@router.get("/{project_id}", response_model=ProjectOut)
def get_project(project_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin một project theo ID.
    - Trả về thông tin project.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    row = db.query(Project).filter(Project.id == project_id).first()
    if not row:
        return not_found(message="Project not found")
    # return row
    return ok(row, "Fetched successfully", status.HTTP_200_OK)

@router.patch("/{project_id}", response_model=ProjectOut)
def update_project(
    project_id: int,
    payload: ProjectUpdate,
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    """Cập nhật thông tin một project theo ID.
    - Trả về thông tin project đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    row = db.query(Project).filter(Project.id == project_id).first()
    if not row:
        return not_found(message="Project not found")
    for k, v in payload.dict(exclude_unset=True).items():
        setattr(row, k, v)
    db.commit(); db.refresh(row)
    # return row
    return ok(row, "Updated successfully", status.HTTP_200_OK)

@router.get("/by-user/{user_id}", response_model=list[ProjectOut])
def list_projects_by_user(user_id: int, db: Session = Depends(get_db)):
    """Lấy danh sách project của một user theo user_id.
    - Trả về danh sách project.
    """
    # return db.query(Project).filter(Project.user_id == user_id).order_by(Project.id.desc()).all()
    return ok(db.query(Project).filter(Project.user_id == user_id).order_by(Project.id.desc()).all(), "Fetched successfully", status.HTTP_200_OK)

@router.get("/my-projects", response_model=list[ProjectOut])
def my_projects(db: Session = Depends(get_db), current=Depends(get_current_user)):
    """Lấy danh sách project của user hiện tại.
    - Trả về danh sách project.
    """
    # return db.query(Project).filter(Project.user_id == current.id).order_by(Project.id.desc()).all()
    return ok(db.query(Project).filter(Project.user_id == current.id).order_by(Project.id.desc()).all(), "Fetched successfully", status.HTTP_200_OK)

@router.patch("/{project_id}/owner", response_model=ProjectOut)
def change_owner(project_id: int, new_user_id: int, db: Session = Depends(get_db), current=Depends(get_current_user)):
    """Chuyển quyền sở hữu một project sang user khác.
    - Trả về thông tin project đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    row = db.query(Project).filter(Project.id == project_id).first()
    if not row:
        return not_found(message="Project not found")
    row.user_id = new_user_id
    db.commit(); db.refresh(row)
    # return row
    return ok(row, "Owner changed successfully", status.HTTP_200_OK)

# @router.post("/{project_id}/export", response_model=OutputOut)
# def export_project(project_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
#     snapshot = _fetch_all_for_project(db, project_id)

#     last = db.query(Output).filter(Output.project_id == project_id).order_by(Output.version.desc()).first()
#     next_ver = 1 if not last else (last.version + 1)

#     title = f"Export Project #{project_id} v{next_ver}"
#     row = Output(
#         project_id=project_id,
#         output_type="json",
#         output_title=title,
#         output_data=json.dumps(snapshot, ensure_ascii=False),
#         version=next_ver,
#         status=1,
#     )
#     db.add(row)
#     db.commit()
#     db.refresh(row)
#     return row

# @router.get("/{project_id}/outputs", response_model=List[OutputFullOut])
# def list_outputs(project_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
#     """Lấy danh sách Outputs của một project theo project_id.
#     - Trả về danh sách Outputs.
#     """
#     # return db.query(Output).filter(Output.project_id == project_id).all()
#     return ok(db.query(Output).filter(Output.project_id == project_id).all(), "Fetched successfully", status.HTTP_200_OK)
@router.get("/{project_id}/outputs", response_model=dict)
def list_outputs_by_project(project_id: int, db: Session = Depends(get_db)):
    """Lấy danh sách Outputs theo project_id, bao gồm các Permits liên quan.
    - Trả về danh sách Outputs.
    - Nếu không có Output nào, trả về danh sách rỗng.
    """
    q = (
        select(Output)
        .options(selectinload(Output.permits))
        .where(Output.project_id == project_id)
        .order_by(Output.id.desc())
    )
    rows = db.execute(q).scalars().all()
    payload = [OutputFullOut.model_validate(r).model_dump() for r in rows]
    return ok(payload, "Get outputs successfully")

@router.post("/{project_id}/upload")
async def upload_files_to_project(
    project_id: str, files: List[UploadFile] = File(...), db: Session = Depends(get_db), background_tasks: BackgroundTasks = None,
):
    """Upload nhiều file vào một project.
    - Trả về thông tin project đã cập nhật.
    - Nếu project không tồn tại, trả về lỗi 404.
    """
     # gọi service upload và merge PDF
    result = upload_files_to_project_service(db, project_id, files)

    # chạy background upload vào OpenAI vector store
    project = db.query(Project).filter(Project.id == project_id).first()
    if project:
        merged_path = merge_project_pdfs(project_id)
        background_tasks.add_task(upload_pdf_to_vector_store_and_log, project, merged_path, db)
    return result



# ------------mock-----------------------
@router.get("/mock/with-msds", response_model=List[ProjectWithMSDS], tags=["Projects"])
def get_projects_with_msds_mock(
    current: User = Depends(get_current_user)
):
    """
    API Mock: Lấy danh sách project với MSDS tương ứng
    """
    return mock_projects_with_msds

@router.get("/mock/{project_id}/msds", response_model=List[ChemicalProduct], tags=["Projects"])
def get_project_msds_mock(
    project_id: str,
    current: User = Depends(get_current_user)
):
    """
    API Mock: Lấy danh sách MSDS của một project cụ thể
    """
    project = next((p for p in mock_projects_with_msds if p["id"] == project_id), None)
    if not project:
        return not_found(message="Project not found")
    
    return project["msds"]

@router.get("/mock/{project_id}/msds/count", tags=["Projects"])
def get_project_msds_count_mock(
    project_id: str,
    current: User = Depends(get_current_user)
):
    """
    API Mock: Đếm số lượng MSDS trong project
    """
    project = next((p for p in mock_projects_with_msds if p["id"] == project_id), None)
    if not project:
        return not_found(message="Project not found")
    
    return {
        "project_id": project_id,
        "project_name": project["name"],
        "msds_count": len(project["msds"])
    }
    # return upload_files_to_project_service(db, project_id, files)
    # return ok(upload_files_to_project_service(db, project_id, files), "Uploaded successfully")

# @router.post("/projects/{project_id}/extract-cas", response_model=List[CasExtractResp])
# async def extract_cas(project_id: str, db: Session = Depends(get_db)):
#     # return await extract_cas_from_merged_pdf_service(project_id, db)
#     return ok(await extract_cas_from_merged_pdf_service(project_id, db), "Extracted successfully", status.HTTP_200_OK)


# @router.post("/projects/{project_id}/msds-output", response_model=List[CasExtractResp])
# async def extract_msds_output(project_id: str, db: Session = Depends(get_db)):
#     return await extract_msds_output_service(project_id, db)




@router.post("/project-extract-output/save", response_model=SecondExtractSavedOut)
def save_second_extract_endpoint(payload: SecondExtractIn, db: Session = Depends(get_db)):
    """Lưu thông tin trích lọc lần 2 cho một MSDS trong project.
    - Trả về thông tin trích lọc đã lưu.
    """
    # return save_second_extract(db, payload)
    return ok(save_second_extract(db, payload), "Saved successfully", status.HTTP_200_OK)

@router.post("/project-extract-output/save-batch")
def save_second_extract_batch_endpoint(payload: SecondExtractBatchIn, db: Session = Depends(get_db)):
    """Lưu thông tin trích lọc lần 2 cho nhiều MSDS trong project.
    - Trả về thông tin trích lọc đã lưu.
    """
    res = save_second_extract_batch(db, payload)  # List[SecondExtractSavedOut]
    # return {"status": "success", "data": [r.model_dump() for r in res]}
    return ok([r.model_dump() for r in res], "Saved batch successfully", status.HTTP_200_OK)


# @router.get("/{project_id}/msds/legal-map")
# def get_msds_legal_map(
#     project_id: str,
#     db: Session = Depends(get_db),
#     page: int = Query(1, ge=1),
#     size: int = Query(50, ge=1, le=200)
# ):
#     """Lấy bản đồ pháp lý (Regulation -> Article -> Appendix) của tất cả MSDS trong project.
#     - Trả về cấu trúc phân cấp Regulation -> Article -> Appendix cho mỗi MSDS
#     - Có phân trang (mặc định page=1, size=50, tối đa size=200)
#     """
#     q = (
#         db.query(
#             MSDS, MSDSChemical, Chemical, 
#                 #  Appendix, Regulation, 
#         )
#         .join(MSDSChemical, MSDSChemical.msds_id == MSDS.id)
#         .join(Chemical, Chemical.cas_no == MSDSChemical.cas_no)
#         # .join(AppendixChemical, AppendixChemical.chemical_id == Chemical.id)
#         # .join(Appendix, Appendix.id == AppendixChemical.appendix_id)
#         # .join(Regulation, Regulation.id == Appendix.regulation_id)
#         # # chỉ gắn Article chủ quản của phụ lục
#         # .outerjoin(Article, Article.id == Appendix.article_id)
#         .filter(MSDS.project_id == project_id)
#         .offset((page-1)*size).limit(size)
#     )

#     rows = q.all()
#     if not rows:
#         return not_found(message="No data")

#     out = {"project_id": project_id, "items": []}
#     by_msds: Dict[Any, Dict[str, Any]] = {}

#     for msds, mchem, chem in rows:
#         bucket = by_msds.get(msds.id)
#         if not bucket:
#             bucket = {
#                 "msds": _sa_to_dict(msds),
#                 "msds_chemicals": {},   # giữ nguyên nếu UI đang dùng
#                 "regulations": {},      # gom Regulation -> Article -> Appendix
#             }
#             by_msds[msds.id] = bucket

#         # ---- giữ danh sách msds_chemicals đầy đủ (nếu cần) ----
#         key = getattr(mchem, "id", None) or f"{mchem.cas_no}"
#         mc = bucket["msds_chemicals"].get(key)
#         if not mc:
#             mc = {
#                 "msds_chemical": _sa_to_dict(mchem),
#                 "chemical": _sa_to_dict(chem),
#                 "appendices": {},
#                 "regulations": {},
#                 "articles": {},
#             }
#             bucket["msds_chemicals"][key] = mc
        

        

#     # finalize: dict -> list
#     for _, bucket in by_msds.items():
#         # finalize msds_chemicals
#         chems = []
#         for _, mc in bucket["msds_chemicals"].items():
#             mc["appendices"] = list(mc["appendices"].values())
#             mc["regulations"] = list(mc["regulations"].values())
#             mc["articles"] = list(mc["articles"].values())
#             chems.append(mc)
#         bucket["msds_chemicals"] = chems

#         # finalize regulations tree
#         regs = []
#         for _, reg_node in bucket["regulations"].items():
#             # articles -> list
#             arts = []
#             for _, art_node in reg_node["articles"].items():
#                 art_node["appendices"] = list(art_node["appendices"].values())
#                 arts.append(art_node)
#             reg_node["articles"] = arts
#             reg_node["appendices"] = list(reg_node["appendices"].values())
#             regs.append(reg_node)
#         bucket["regulations"] = regs

#         out["items"].append(bucket)

#     return ok(out, "Fetched successfully", status.HTTP_200_OK)
@router.get("/{project_id}/msds/legal-map")  # giữ nguyên URL theo yêu cầu
def get_msds_legal_map(  # giờ chỉ trả msds + msds_chemicals
    project_id: int,
    db: Session = Depends(get_db),
    page: int = Query(1, ge=1),
    size: int = Query(50, ge=1, le=200),
):
    """
    Lấy danh sách MSDS trong project cùng các hóa chất liên quan.
    - Trả về danh sách MSDS.
    - Có phân trang (mặc định page=1, size=50, tối đa size=200).
    """

    # Tổng để client paginated
    total = db.scalar(
        select(func.count(MSDS.id)).where(MSDS.project_id == project_id)
    ) or 0

    if total == 0:
        return not_found("No data")

    stmt = (
        select(MSDS)
        .options(selectinload(MSDS.msds_chemicals_link))
        .where(MSDS.project_id == project_id)
        .order_by(MSDS.id.desc())
        .offset((page - 1) * size)
        .limit(size)
    )

    # Với eager load, dùng .unique() để loại bản ghi trùng (SQLAlchemy 1.4/2.0)
    rows = db.scalars(stmt).unique().all()
    if not rows:
        return not_found("No data")

    data_items = []
    for m in rows:
        # Sắp theo tên rồi CAS để output ổn định (tùy chọn)
        chems = sorted(
            (m.msds_chemicals_link or []),
            key=lambda c: ((c.chemical_name or "").lower(), (c.cas_no or "")),
        )
        data_items.append({
            # chỉ giữ msds + msds_chemicals
            "id": m.id,
            "project_id": m.project_id,
            "product_name": getattr(m, "product_name", None),
            "status": getattr(m, "status", None),
            "create_by": getattr(m, "create_by", None),
            "update_by": getattr(m, "update_by", None),
            "created_at": getattr(m, "created_at", None),
            "updated_at": getattr(m, "updated_at", None),
            # ... thêm field msds khác nếu cần
            "msds_chemicals": [
                {
                    "id": c.id,
                    "msds_id": c.msds_id,
                    "cas_no": c.cas_no,
                    "chemical_name": c.chemical_name,
                    "percentage": c.percentage,
                    "wtf": c.wtf,          # NEW
                    "role": c.role,
                    "status": c.status,
                    "create_by": c.create_by,
                    "update_by": c.update_by,
                    "created_at": c.created_at,
                    "updated_at": c.updated_at,
                    # ... thêm field chemical nếu cần
                }
                for c in chems
            ],
        })

    payload = {
        "project_id": project_id,
        "page": page,
        "size": size,
        "total": total,
        "items": data_items,
    }
    return ok(payload, "Fetched successfully")



@router.post(
    "/project-cas-no-check-notes",
    response_model=ResponseEnvelope[List[ProductCASResponse]]
)
def batch_notes_by_cas(payload: List[ProductCASRequest], db: Session = Depends(get_db)):
    """Lấy ghi chú pháp lý (notes) cho từng CAS No trong danh sách sản phẩm.
    - Trả về danh sách sản phẩm với ghi chú pháp lý tương ứng cho từng CAS No.
    """
    # 1) Thu tất cả CAS cần tra
    cas_list_ordered: List[str] = []
    for prod in payload:
        for item in prod.CasNoList:
            s = item.strip()
            if s and s not in cas_list_ordered:
                cas_list_ordered.append(s)
    if not cas_list_ordered:
        return ok([])

    # 2) Truy vấn 1 lần cho tất cả CAS, không dùng GROUP_CONCAT để tránh cắt nội dung
    params = {f"c{i}": v for i, v in enumerate(cas_list_ordered)}
    in_clause = ", ".join(f":c{i}" for i in range(len(cas_list_ordered)))

    q = sql_text(f"""
        SELECT
          c.cas_no,
          c.chemical_name,
          c.chemical_name_vn,
          c.hs_code,
          ra.note, ra.regulation, ra.law_text, ra.content
        FROM chemicals c
        LEFT JOIN chemical_mappings m
               ON m.chemical_id = c.id AND (m.status = 1 OR m.status IS NULL)
        LEFT JOIN regulation_appendix ra
               ON ra.id = m.appendix_id AND (ra.status = 1 OR ra.status IS NULL)
        WHERE c.cas_no IN ({in_clause})
        ORDER BY c.cas_no, ra.title, ra.code
    """)
    rows = db.execute(q, params).all()

    # 3) Gom notes theo CAS
    agg: Dict[str, Dict[str, Optional[str]]] = {}
    for cas_no in cas_list_ordered:
        agg[cas_no] = {
            "chemical_name": None,
            "chemical_name_vn": None,
            "hs_code": None,
            "notes": []
        }

    for r in rows:
        cas_no, chem_name, chem_name_vn, hs, note, reg, law, content = r
        slot = agg.get(cas_no)
        if slot is None:
            continue
        if slot["chemical_name"] is None:
            slot["chemical_name"] = chem_name
        if slot["chemical_name_vn"] is None:
            slot["chemical_name_vn"] = chem_name_vn
        if slot["hs_code"] is None:
            slot["hs_code"] = hs

        chunk_parts = [x for x in [note, reg, law, content] if x and str(x).strip()]
        if chunk_parts:
            slot["notes"].append("\n".join(chunk_parts).strip())

    # 4) Lắp kết quả về từng sản phẩm theo thứ tự đầu vào
    result: List[ProductCASResponse] = []
    for prod in payload:
        items: List[BatchNotesItem] = []
        for item in prod.CasNoList:
            cas_no = item.strip()
            slot = agg.get(cas_no, {"chemical_name": None, "chemical_name_vn": None, "hs_code": None, "notes": []})
            notes_summary = "\n\n".join(slot["notes"]) if slot["notes"] else ""
            items.append(BatchNotesItem(
                cas_no=cas_no,
                chemical_name=slot["chemical_name"],
                chemical_name_vn=slot["chemical_name_vn"],
                hs_code=slot["hs_code"],
                notes_summary=notes_summary
            ))
        result.append(ProductCASResponse(ProductName=prod.ProductName, items=items))

    return ok(result)





@router.put("/{project_id}", response_model=dict)
def update_project(project_id: int, payload: ProjectUpdate, db: Session = Depends(get_db)):
    """Cập nhật thông tin một project theo ID.
    - Trả về thông tin project đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    proj = db.get(Project, project_id)
    if not proj:
        return not_found(message="Project not found")
    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(proj, k, v)
    db.add(proj)
    db.commit()
    db.refresh(proj)
    return ok(ProjectOut.model_validate(proj), "Updated successfully", status.HTTP_200_OK)

@router.delete("/{project_id}", response_model=dict)
def delete_project(project_id: int, db: Session = Depends(get_db)):
    """Xoá một project theo ID.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    proj = db.get(Project, project_id)
    if not proj:
        return not_found(message="Project not found")

    # Nếu DB đã có ON DELETE CASCADE, chỉ cần delete project.
    db.delete(proj)
    db.commit()
    return ok(None, "Deleted successfully", status.HTTP_200_OK)


@router.delete("/{project_id}/outputs", response_model=dict)
def delete_outputs_by_project(project_id: int, db: Session = Depends(get_db)):
    """Xoá tất cả Outputs theo project_id.
    - Trả về thông báo thành công.
    - Nếu không có Output nào, vẫn trả về thành công với số lượng xoá là 0.
    """
    # Kiểm tra tồn tại project nếu cần:
    # exists = db.execute(select(Projects.id).where(Projects.id==project_id)).first()
    # if not exists: return ok({"deleted": 0}, "Project not found")  # hoặc 404

    proj = db.execute(
        select(Project.id).where(Project.id == project_id).limit(1)
    ).first()
    if not proj:
        # dùng helper nếu có
        return not_found({"deleted": 0}, "Project not found")
        # hoặc:
        # raise HTTPException(status_code=404, detail="Project not found")

    # 2) Đếm outputs trước
    total_outputs = db.execute(
        select(func.count(Output.id)).where(Output.project_id == project_id)
    ).scalar_one()

    if total_outputs == 0:
        return not_found({"deleted": 0}, "No outputs found for this project")
        # hoặc:
        # raise HTTPException(status_code=404, detail="No outputs found for this project")

    # 3) Xoá
    res = db.execute(delete(Output).where(Output.project_id == project_id))
    db.commit()
    deleted = res.rowcount or 0
    return ok({"deleted": deleted}, "Delete outputs successfully")

@router.get("/{project_id}/full-outputs", response_model=dict)
def get_full_outputs(project_id: int, db: Session = Depends(get_db), current: User = Depends(get_current_user)):
    """
    Lấy danh sách Outputs theo project_id, bao gồm các Permits và Elements liên quan.
    - Trả về danh sách Outputs đầy đủ.
    - Nếu không có Output nào, trả về danh sách rỗng.
    """
    outputs = (
        db.query(Output)
        .options(joinedload(Output.permits), joinedload(Output.elements))
        .filter(Output.project_id == project_id)
        .order_by(Output.id.desc())
        .all()
    )
    data = []
    for o in outputs:
        output_dict = {
            "id": o.id,
            "project_id": o.project_id,
            "product_name": o.product_name,
            "ghs_signal_word": o.ghs_signal_word,
            "ghs_hazard_statements": o.ghs_hazard_statements,
            "msds_id": o.msds_id,
            "total_pct": o.total_pct,
            "temperature_storage_at": o.temperature_storage_at,
            "warehouse_type": o.warehouse_type,
            "product_class": o.product_class,
            "is_msds_vn_16_field": o.is_msds_vn_16_field,
            "special_warnings_transportation": o.special_warnings_transportation,
            "match_class_of_products": o.match_class_of_products,
            "status": o.status,
            "create_by": o.create_by,
            "update_by": o.update_by,
            "created_at": o.created_at,
            "updated_at": o.updated_at
        }
        permits_list = [OutputPermitOut.model_validate(p).model_dump() for p in o.permits]
        elements_list = [OutputElementOut.model_validate(e).model_dump() for e in o.elements]
        data.append({
            "output": output_dict,
            "output_permits": permits_list,
            "output_elements": elements_list
        })
    return ok(data, "OK")