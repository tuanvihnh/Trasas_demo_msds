from fastapi import APIRouter, Depends, HTTPException, Query, Path, status
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import or_, func, desc, asc
from typing import List, Optional, Literal, Dict, Any
from app.db.session import get_db
from app.models.models import Appendix, Regulation, Chemical, ChemicalMapping  # ⬅️ đổi import
from app.schemas.common import ResponseEnvelope, Paginated, PageMeta
from app.utils.response import conflict, not_found, ok
from app.schemas.schemas import RegAppUpdate, RegulationAppendixIn, RegulationAppendixOut, RegAppendixWithChemicalsOut, ChemicalInfo, RegappChemicalItem
from sqlalchemy.exc import IntegrityError

router = APIRouter()

# -------- Helpers --------
def _appendix_to_out_dict(a: Appendix, code: Optional[str]) -> dict:
    """Ghép dữ liệu Appendix + Regulation.code thành shape RegulationAppendixOut cũ."""
    return {
        "id": a.id,
        "code": code,
        "title": a.title,
        "content": a.content,
        "regulation": a.regulation_text,   # <— STRING legacy
        "note": a.note,
        "law_text": a.law_text,
        "status": a.status,
        "created_at": a.created_at,
        "updated_at": a.updated_at,
        "create_by": a.create_by,
        "update_by": a.update_by,
    }

def _resolve_regulation_id_by_code(db: Session, code: str) -> int:
    r = db.query(Regulation).filter(func.lower(func.trim(Regulation.code)) == func.lower(func.trim(code))).first()
    if not r:
        raise HTTPException(status_code=404, detail=f"regulation code '{code}' not found")
    return r.id

# ========== LIST ==========
@router.get("/", response_model=ResponseEnvelope[Paginated[RegulationAppendixOut]])
def list_regapps(db: Session = Depends(get_db), q: str | None = None, page: int = 1, size: int = 50):
    """Lấy danh sách bản ghi Appendix.
    - Mặc định lọc status=1 (hoặc NULL).
    - Có thể lọc theo q (tìm trong code, title, law_text, note).
    - Mặc định page=1, size=50.
    - Trả về danh sách bản ghi Appendix với phân trang.
    """
    # JOIN Appendix ← Regulation (để có 'code')
    base = (
        db.query(Appendix, Regulation.code.label("reg_code"))
          .select_from(Appendix)
          .join(Regulation, Regulation.id == Appendix.regulation_id, isouter=True)
    )
    if q:
        like = f"%{q}%"
        base = base.filter(or_(
            Regulation.code.ilike(like),
            Appendix.title.ilike(like),
            Appendix.law_text.ilike(like),
            Appendix.note.ilike(like),
            Appendix.content.ilike(like),
        ))

    total = db.query(func.count(Appendix.id)).select_from(Appendix).scalar() if not q else \
            db.query(func.count(func.distinct(Appendix.id))).select_from(base.subquery()).scalar()

    rows = (
        base.order_by(Appendix.id.desc())
            .offset((page-1)*size).limit(size)
            .all()
    )
    items = [_appendix_to_out_dict(a, code) for (a, code) in rows]
    return ok({"meta": {"total": total or 0, "page": page, "size": size}, "items": items})

# ========== LIST ALL ==========
@router.get("/all", response_model=ResponseEnvelope[list[RegulationAppendixOut]])
def list_all_regapps(db: Session = Depends(get_db), q: str | None = None, code: str | None = None, title: str | None = None):
    """Lấy danh sách tất cả bản ghi Appendix.
    - Mặc định lọc status=1 (hoặc NULL).
    - Có thể lọc theo q (tìm trong code, title, law_text, note).
    - Có thể lọc theo title (Appendix.title), code (Regulation.code).
    - Không phân trang, trả về tất cả.
    """
    base = (
        db.query(Appendix, Regulation.code.label("reg_code"))
          .join(Regulation, Regulation.id == Appendix.regulation_id, isouter=True)
          .filter((Appendix.status == 1) | (Appendix.status.is_(None)))
    )
    if q:
        like = f"%{q}%"
        base = base.filter(or_(Regulation.code.ilike(like), Appendix.title.ilike(like), Appendix.law_text.ilike(like)))
    if code:
        base = base.filter(func.lower(func.trim(Regulation.code)) == func.lower(func.trim(code)))
    if title:
        base = base.filter(Appendix.title.ilike(f"%{title}%"))

    rows = base.order_by(asc(Regulation.code.nulls_last())).all()
    items = [_appendix_to_out_dict(a, reg_code) for (a, reg_code) in rows]
    return ok(items)

# ========== LIST + CHEMICALS ==========
@router.get("/list/chemicals", response_model=ResponseEnvelope[Paginated[RegappChemicalItem]])
def list_regapps_with_chemicals(
    db: Session = Depends(get_db),
    q: Optional[str] = None,
    title: Optional[str] = None,
    code: Optional[str] = None,
    cas_no: Optional[str] = None,
    hs_code: Optional[str] = None,
    page: int = Query(1, ge=1),
    size: Optional[int] = Query(10, ge=1),
    sort_field: Literal["code","title","chemical_name","cas_no","molecular_formula","chemical_class","hs_code","created_at","updated_at", "updated_at"] = "code",
    sort_order: Literal["asc","desc"] = "asc",
):
    """Lấy danh sách bản ghi Appendix kèm thông tin hoá chất liên quan.
    - Mặc định lọc status=1 (hoặc NULL).
    - Có thể lọc theo q (tìm trong code, title, law_text, note, tên hoá chất, cas_no, molecular_formula, hs_code, chemical_class).
    - Có thể lọc theo title (Appendix.title), code (Regulation.code), cas_no (Chemical.cas_no), hs_code (Chemical.hs_code).
    - Mặc định page=1, size=10.
    - Nếu không truyền size thì không phân trang (trả về tất cả).
    - Mặc định sort_field=code, sort_order=asc.
    - Trả về danh sách bản ghi Appendix kèm thông tin hoá chất liên quan.
    """
    def apply_filters(qry):
        qry = qry.filter((Appendix.status == 1) | (Appendix.status.is_(None)))
        if q:
            like = f"%{q}%"
            qry = qry.filter(or_(
                Regulation.code.ilike(like),
                Appendix.title.ilike(like),
                Appendix.law_text.ilike(like),
                Appendix.note.ilike(like),
                Chemical.chemical_name.ilike(like),
                Chemical.chemical_name_vn.ilike(like),
                Chemical.cas_no.ilike(like),
                Chemical.molecular_formula.ilike(like),
                Chemical.hs_code.ilike(like),
                Chemical.chemical_class.ilike(like),
            ))
        if title:
            qry = qry.filter(Appendix.title.ilike(f"%{title}%"))
        if code:
            qry = qry.filter(func.lower(func.trim(Regulation.code)) == func.lower(func.trim(code)))
        if cas_no:
            qry = qry.filter(Chemical.cas_no == cas_no)
        if hs_code:
            qry = qry.filter(Chemical.hs_code == hs_code)
        return qry

    # RA↔CM↔Chemical JOIN với Regulation
    base_q = (
        db.query(Appendix.id.label("a_id"))
          .select_from(Appendix)
          .join(Regulation, Regulation.id == Appendix.regulation_id, isouter=True)
          .join(ChemicalMapping, ChemicalMapping.appendix_id == Appendix.id)
          .join(Chemical, Chemical.id == ChemicalMapping.chemical_id)
    )
    base_q = apply_filters(base_q)

    # TOTAL = số dòng mapping sau filter
    total_ids_subq = base_q.subquery()
    total = db.query(func.count()).select_from(total_ids_subq).scalar() or 0

    # ROWS (lấy trường cần hiển thị)
    rows_q = (
        db.query(
            Chemical.chemical_name,
            Chemical.chemical_name_vn,
            Chemical.cas_no,
            Chemical.hs_code,
            Chemical.molecular_formula,
            Appendix.note,
            Appendix.law_text,
            Regulation.code.label("reg_code"),
            Appendix.title,
            Appendix.created_at,
            ChemicalMapping.id
        )
        .select_from(Appendix)
        .join(Regulation, Regulation.id == Appendix.regulation_id, isouter=True)
        .join(ChemicalMapping, ChemicalMapping.appendix_id == Appendix.id)
        .join(Chemical, Chemical.id == ChemicalMapping.chemical_id)
    )
    rows_q = apply_filters(rows_q)

    # Sort
    if sort_field in ["code", "title", "created_at"]:
        sort_col = {"code": Regulation.code, "title": Appendix.title, "created_at": Appendix.created_at}[sort_field]
    else:
        sort_col = getattr(Chemical, sort_field)
    rows_q = rows_q.order_by(desc(sort_col) if sort_order == "desc" else asc(sort_col))

    # Paginate
    if size is None:
        rows = rows_q.all()
        page_out, size_out = 1, total
    else:
        rows = rows_q.offset((page - 1) * size).limit(size).all()
        page_out, size_out = page, size

    items = [{
        "chemical_name": r[0],
        "chemical_name_vn": r[1],
        "cas_no": r[2],
        "hs_code": r[3],
        "molecular_formula": r[4],
        "note": r[5],
        "law_text": r[6],
        "id": r[10]
        # có thể thêm code/title nếu schema RegappChemicalItem hỗ trợ
        # "code": r[7], "title": r[8],
    } for r in rows]

    return ok({"total": total, "page": page_out, "size": size_out, "items": items})

# ========== CREATE ==========
@router.post("/", response_model=ResponseEnvelope[RegulationAppendixOut])
def create_regapp(body: RegulationAppendixIn, db: Session = Depends(get_db)):
    """
    Giữ input cũ (RegulationAppendixIn) có thể chứa 'code' và 'title':
    - 'code' giờ là mã Regulation → resolve regulation_id
    - Tạo bản ghi Appendix (không còn trường code)
    """
    reg_id = None
    if getattr(body, "code", None):
        reg_id = _resolve_regulation_id_by_code(db, body.code)

    obj = Appendix(
        title=body.title,
        content=getattr(body, "content", None),
        regulation_text=getattr(body, "regulation_text", None),
        note=getattr(body, "note", None),
        law_text=getattr(body, "law_text", None),
        status=getattr(body, "status", None),
        created_at=getattr(body, "created_at", None),
        updated_at=getattr(body, "updated_at", None),
        create_by=getattr(body, "create_by", None),
        update_by=getattr(body, "update_by", None),
        regulation_id=reg_id,
    )
    db.add(obj); db.commit(); db.refresh(obj)

    # trả shape cũ (kèm code từ regulation)
    code = db.query(Regulation.code).filter(Regulation.id == obj.regulation_id).scalar()
    return ok(_appendix_to_out_dict(obj, code))

@router.put("/{id}", response_model=ResponseEnvelope[RegulationAppendixOut])
def update_regapp(
    id: int,
    body: RegAppUpdate,
    db: Session = Depends(get_db),
):
    """Cập nhật bản ghi Appendix theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông tin bản ghi đã cập nhật.
    """
    obj: Appendix | None = db.get(Appendix, id)
    if not obj:
        return not_found(message="Not found")

    # cập nhật regulation_id từ code nếu client gửi
    if hasattr(body, "code") and body.code is not None:
        code_str = body.code.strip() if isinstance(body.code, str) else body.code
        if code_str == "" or code_str is None:
            obj.regulation_id = None
        else:
            obj.regulation_id = _resolve_regulation_id_by_code(db, code_str)

    # partial update các trường hợp lệ
    updatable_fields = [
        "title",
        "content",
        "regulation_text",
        "note",
        "law_text",
        "status",
        "update_by",
        "updated_at",
    ]
    for f in updatable_fields:
        if hasattr(body, f):
            val = getattr(body, f)
            if val is not None:
                setattr(obj, f, val)

    db.add(obj)
    db.commit()
    db.refresh(obj)

    code = db.query(Regulation.code).filter(Regulation.id == obj.regulation_id).scalar()
    return ok(_appendix_to_out_dict(obj, code))


# ========== DELETE ==========
@router.delete("/{id}", response_model=ResponseEnvelope[dict])
def delete_regapp(id: int, db: Session = Depends(get_db)):
    """Xoá bản ghi Appendix theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Nếu đang được tham chiếu trong ChemicalMapping, trả về lỗi 409.
    - Trả về thông báo xoá thành công.
    """
    obj: Appendix | None = db.get(Appendix, id)
    if not obj:
        return not_found(message="Not found")

    # chặn xóa nếu đang được tham chiếu
    in_use = db.query(func.count(ChemicalMapping.id)).filter(ChemicalMapping.appendix_id == id).scalar() or 0
    if in_use > 0:
        return conflict(f"Cannot delete: appendix {id} is referenced by {in_use} chemical_mappings")

    db.delete(obj); db.commit()
    return ok({"id": id})
