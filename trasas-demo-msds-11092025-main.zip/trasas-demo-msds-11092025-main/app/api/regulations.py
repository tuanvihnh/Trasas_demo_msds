from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import or_, asc, desc
from typing import Optional, Literal

from app.db.session import get_db
from app.models.models import Regulation
from app.schemas.schemas import RegulationIn
from app.utils.response import ok, not_found, conflict

# Nếu bạn đã có schema riêng cho Regulation trong app.schemas.schemas
# thì import và dùng thay cho 2 class nội bộ bên dưới.
# Ở đây khai báo tối thiểu để tự chạy được.
from pydantic import BaseModel



router = APIRouter(tags=["Regulations"])

@router.get("/", summary="List regulations")
def list_regulations(
    db: Session = Depends(get_db),
    q: Optional[str] = None,
    page: Optional[int] = Query(None, ge=1),
    size: Optional[int] = Query(None, ge=1),
    sort_field: Literal["id", "code", "title"] = "code",
    sort_order: Literal["asc", "desc"] = "asc",
):
    """Lấy danh sách văn bản quy phạm pháp luật với phân trang tùy chọn.
    - Nếu không truyền page/size thì không phân trang.
    - Mặc định sort_field=code, sort_order=asc.
    - Trả về danh sách văn bản quy phạm pháp luật.
    """
    qry = db.query(Regulation)
    if q:
        like = f"%{q}%"
        qry = qry.filter(or_(
            Regulation.code.ilike(like),
            Regulation.title.ilike(like),
        ))

    order_col = {
        "id": Regulation.id,
        "code": Regulation.code,
        "title": Regulation.title,
    }[sort_field]
    qry = qry.order_by(asc(order_col) if sort_order == "asc" else desc(order_col))

    # không phân trang nếu không truyền page/size
    if page is None or size is None:
        items = [
            {"id": r.id, "code": r.code, "title": r.title, "note": r.note, "law_text": r.law_text}
            for r in qry.all()
        ]
        return ok(items, "Fetched successfully", status.HTTP_200_OK)

    total = qry.count()
    rows = qry.offset((page - 1) * size).limit(size).all()
    items = [
        {"id": r.id, "code": r.code, "title": r.title, "note": r.note, "law_text": r.law_text}
        for r in rows
    ]
    payload = {"page": page, "size": size, "total": total, "items": items}
    return ok(payload, "Fetched successfully", status.HTTP_200_OK)

@router.get("/{regulation_id}", summary="Get regulation by id")
def get_regulation(regulation_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin văn bản quy phạm pháp luật theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông tin văn bản quy phạm pháp luật.
    """
    r = db.query(Regulation).get(regulation_id)
    if not r:
        return not_found(f"Regulation {regulation_id} not found")
    data = {"id": r.id, "code": r.code, "title": r.title, "note": r.note, "law_text": r.law_text}
    return ok(data, "Fetched successfully", status.HTTP_200_OK)

@router.post("/", status_code=status.HTTP_201_CREATED, summary="Create regulation")
def create_regulation(body: RegulationIn, db: Session = Depends(get_db)):
    """Tạo văn bản quy phạm pháp luật mới.
    - Trả về thông tin văn bản quy phạm pháp luật mới.
    - Nếu trùng code hoặc title, trả về lỗi 409.
    """
    # tránh trùng code hoặc title
    exists = db.query(Regulation).filter(
        or_(Regulation.code == body.code, Regulation.title == body.title)
    ).first()
    if exists:
        return conflict("Code or title already exists")

    r = Regulation(code=body.code, title=body.title, note=body.note, law_text=body.law_text)
    db.add(r)
    db.commit()
    db.refresh(r)
    data = {"id": r.id, "code": r.code, "title": r.title, "note": r.note, "law_text": r.law_text}
    return ok(data, "Created", status.HTTP_201_CREATED)

@router.put("/{regulation_id}", summary="Update regulation")
def update_regulation(regulation_id: int, body: RegulationIn, db: Session = Depends(get_db)):
    """Cập nhật thông tin văn bản quy phạm pháp luật theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Nếu trùng code hoặc title với bản ghi khác, trả về lỗi 409.
    - Trả về thông tin văn bản quy phạm pháp luật đã cập nhật.
    """
    r = db.query(Regulation).get(regulation_id)
    if not r:
        return not_found(f"Regulation {regulation_id} not found")

    # kiểm tra trùng code/title với bản ghi khác
    dup = db.query(Regulation).filter(
        or_(Regulation.code == body.code, Regulation.title == body.title),
        Regulation.id != regulation_id
    ).first()
    if dup:
        return conflict("Code or title already exists")

    r.code = body.code
    r.title = body.title
    r.note = body.note
    r.law_text = body.law_text
    db.commit()
    db.refresh(r)
    data = {"id": r.id, "code": r.code, "title": r.title, "note": r.note, "law_text": r.law_text}
    return ok(data, "Updated", status.HTTP_200_OK)

@router.delete("/{regulation_id}", summary="Delete regulation")
def delete_regulation(regulation_id: int, db: Session = Depends(get_db)):
    """Xoá văn bản quy phạm pháp luật theo ID.
    - Nếu không tìm thấy, trả về lỗi 404.
    - Trả về thông báo xoá thành công.
    """
    r = db.query(Regulation).get(regulation_id)
    if not r:
        return not_found(f"Regulation {regulation_id} not found")

    db.delete(r)
    db.commit()
    return ok({"deleted": 1}, "Deleted", status.HTTP_200_OK)


# from fastapi import APIRouter, FastAPI, File, HTTPException, Depends, UploadFile, status, Query, Header
# from pydantic import BaseModel, Field
# from typing import Any, Dict, List, Optional
# from datetime import datetime
# from sqlalchemy.orm import Session
# from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, DECIMAL, ForeignKey, Boolean
# from sqlalchemy.orm import sessionmaker, relationship, declarative_base
# from sqlalchemy.ext.declarative import declared_attr
# from sqlalchemy.sql import func
# import base64, hashlib, secrets
# from datetime import datetime, timedelta
# import json
# from typing import Optional, List
# from sqlalchemy import UniqueConstraint, text, bindparam
# from sqlalchemy.exc import IntegrityError
# from app.models.models import *
# from app.schemas.schemas import *
# import pdfplumber, os, io, re
# from fastapi.middleware.cors import CORSMiddleware
# from app.utils.paginate_query import paginate_query
# from fastapi.openapi.utils import get_openapi
# from fastapi import APIRouter
# from app.db.session import get_db
# from app.core.security import (
#     hash_password,
#     verify_password,
    
#     get_current_user,
# )
# from app.db.session import SessionLocal, get_db
# from app.core.config import Settings
# from app.utils.response import ok


# router = APIRouter()




# @router.post("/", response_model=RegulationResponse)
# def create_regulation(regulation: RegulationCreate, db: Session = Depends(get_db)):
#     db_regulation = Regulation(**regulation.model_dump())
#     db.add(db_regulation)
#     db.commit()
#     db.refresh(db_regulation)
#     return ok(db_regulation, "Created successfully")

# @router.get("/", response_model=List[RegulationResponse])
# def read_regulations(page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
#     regulations = paginate_query(db.query(Regulation), page, size).all()
#     return ok(regulations, "Fetched successfully", status.HTTP_200_OK)

# @router.get("/{regulation_id}", response_model=RegulationResponse)
# def read_regulation(regulation_id: int, db: Session = Depends(get_db)):
#     regulation = db.query(Regulation).filter(Regulation.id == regulation_id).first()
#     if regulation is None:
#         return not_found(message="Regulation not found")
#     return ok(regulation, "Fetched successfully", status.HTTP_200_OK)

# @router.put("/{regulation_id}", response_model=RegulationResponse)
# def update_regulation(regulation_id: int, regulation: RegulationCreate, db: Session = Depends(get_db)):
#     db_regulation = db.query(Regulation).filter(Regulation.id == regulation_id).first()
#     if db_regulation is None:
#         return not_found(message="Regulation not found")
#     for key, value in regulation.model_dump(exclude_unset=True).items():
#         setattr(db_regulation, key, value)
#     db.commit()
#     db.refresh(db_regulation)
#     return ok(db_regulation, "Updated successfully", status.HTTP_200_OK)

# @router.delete("/{regulation_id}")
# def delete_regulation(regulation_id: int, db: Session = Depends(get_db)):
#     db_regulation = db.query(Regulation).filter(Regulation.id == regulation_id).first()
#     if db_regulation is None:
#         return not_found(message="Regulation not found")
#     db.delete(db_regulation)
#     db.commit()
#     return ok(None, "Deleted successfully")