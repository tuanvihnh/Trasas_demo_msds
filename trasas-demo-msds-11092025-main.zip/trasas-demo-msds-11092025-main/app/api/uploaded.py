from pathlib import Path
from fastapi import APIRouter, FastAPI, File, HTTPException, Depends, Request, UploadFile, status, Query, Header
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, DECIMAL, ForeignKey, Boolean, desc
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.sql import func
import base64, hashlib, secrets
from datetime import datetime, timedelta
import json
from typing import Optional, List
from sqlalchemy import UniqueConstraint, text, bindparam
from sqlalchemy.exc import IntegrityError
from app.models.models import *
from app.schemas.schemas import *
import pdfplumber, os, io, re
from fastapi.middleware.cors import CORSMiddleware
from app.utils.download import resolve_file
import mimetypes
from app.utils.paginate_query import paginate_query
from fastapi.openapi.utils import get_openapi
from fastapi import APIRouter
from app.db.session import get_db
from urllib.parse import quote, unquote
from app.core.security import (
    hash_password,
    verify_password,
    
    get_current_user,
)
from app.db.session import SessionLocal, get_db
from app.core.config import Settings
from app.utils.response import not_found, ok


router = APIRouter()



@router.post("/", response_model=UploadedFileResponse)
def create_uploaded_file(uploaded_file: UploadedFileCreate, db: Session = Depends(get_db)):
    """Tạo file đã upload mới.
    - Trả về thông tin file đã upload mới.
    - Nếu có lỗi, trả về lỗi 400.
    """
    db_uploaded_file = UploadedFile(**uploaded_file.model_dump())
    db.add(db_uploaded_file)
    db.commit()
    db.refresh(db_uploaded_file)
    return ok(db_uploaded_file, "Created successfully")

@router.get("/", response_model=List[UploadedFileResponse])
def read_uploaded_files(page: int = Query(1, ge=1), size: int = Query(10, ge=1, le=100), db: Session = Depends(get_db)):
    """Lấy danh sách file đã upload với phân trang.
    - Mặc định page=1, size=10.
    - Kích thước trang tối đa là 100.
    - Trả về danh sách file đã upload.
    """
    uploaded_files = paginate_query(db.query(UploadedFile), page, size).all()
    return ok(uploaded_files, "Fetched successfully", status.HTTP_200_OK)

@router.get("/{file_id}", response_model=UploadedFileResponse)
def read_uploaded_file(file_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin file đã upload theo ID.
    - Trả về thông tin file đã upload.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    uploaded_file = db.query(UploadedFile).filter(UploadedFile.id == file_id).first()
    if uploaded_file is None:
        return not_found(message="Uploaded File not found")
    return ok(uploaded_file, "Fetched successfully", status.HTTP_200_OK)

@router.put("/{file_id}", response_model=UploadedFileResponse)
def update_uploaded_file(file_id: int, uploaded_file: UploadedFileCreate, db: Session = Depends(get_db)):
    """Cập nhật thông tin file đã upload theo ID.
    - Trả về thông tin file đã upload đã cập nhật.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_uploaded_file = db.query(UploadedFile).filter(UploadedFile.id == file_id).first()
    if db_uploaded_file is None:
        return not_found(message="Uploaded File not found")
    for key, value in uploaded_file.model_dump(exclude_unset=True).items():
        setattr(db_uploaded_file, key, value)
    db.commit()
    db.refresh(db_uploaded_file)
    return ok(db_uploaded_file, "Updated successfully", status.HTTP_200_OK)

@router.delete("/{file_id}")
def delete_uploaded_file(file_id: int, db: Session = Depends(get_db)):
    """Xoá file đã upload theo ID.
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_uploaded_file = db.query(UploadedFile).filter(UploadedFile.id == file_id).first()
    if db_uploaded_file is None:
        return not_found(message="Uploaded File not found")
    db.delete(db_uploaded_file)
    db.commit()
    return ok(None, "Deleted successfully")

BASE = Path("static/project_files")  # sửa cho khớp nơi bạn lưu file

@router.get("/projects/{project_id}/files")
def list_project_files(project_id: int, db: Session = Depends(get_db)):
    """Lấy danh sách file đã upload cho project_id, trả về thông tin file và URL tải file.
    - Nếu không có file, trả về mảng rỗng.
    
    """
    rows = (db.query(UploadedFile)
              .filter(UploadedFile.project_id == project_id)
              .order_by(UploadedFile.id.asc()).all())
    items = []
    for r in rows:
        rel = f"{project_id}/{r.file_name}"
        fp = (BASE / rel).resolve()
        exists = fp.is_file()
        # url API download, đã encode khoảng trắng
        url = f"/download/{project_id}/{quote(r.file_name)}"
        items.append({"id": r.id, "file_name": r.file_name, "url": url, "exists": exists, "size": fp.stat().st_size if exists else None})
    return ok(items, "Fetched files")

# @router.get("/download/{project_id}/{filename}")
# def download_file(project_id: int, filename: str):
#     fp = (BASE / str(project_id) / filename).resolve()
#     # chặn path traversal
#     if BASE.resolve() not in fp.parents:
#         raise HTTPException(404, "file not found")
#     if not fp.is_file():
#         raise HTTPException(404, "file not found")
#     return FileResponse(fp, filename=fp.name, media_type="application/octet-stream")

@router.get("/download/{project_id}/{filename:path}")
def download(project_id: int, filename: str):
    """Tải file đã upload theo project_id và filename.
    - filename đã được encode đúng (space -> %20).
    - Nếu không tìm thấy file, trả về lỗi 404.
    - Trả về file với content-type phù hợp.
    """
    fname = unquote(filename)                  # chuyển %20 -> space
    fp = resolve_file(project_id, fname)       # tự hàm join đường dẫn an toàn
    if not fp.exists():
        raise HTTPException(404, f"file not found: {fp}")

    # Xác định content-type theo phần mở rộng tệp
    content_type, _ = mimetypes.guess_type(str(fp))
    if content_type is None:
        content_type = "application/octet-stream"

    # Trả về dưới dạng inline để trình duyệt hiển thị (ví dụ PDF) thay vì tải xuống
    resp = FileResponse(str(fp), media_type=content_type)
    resp.headers["Content-Disposition"] = f"inline; filename=\"{fp.name}\""
    return resp


@router.get("/projects/{project_id}/files-path")
def list_project_files_path(project_id: int, request: Request, db: Session = Depends(get_db)):
    """Lấy danh sách file đã upload cho project_id, trả về thông tin file và URL tải file.
    - URL tải file tuyệt đối, đã encode đúng (space -> %20).
    - Nếu không có file, trả về mảng rỗng.
    
    """
    rows = (db.query(UploadedFile)
              .filter(UploadedFile.project_id == project_id)
              .order_by(UploadedFile.id.asc())
              .all())

    items = []
    for r in rows:
        rel = f"{project_id}/{r.file_name}"
        fp = (BASE / rel).resolve()
        exists = fp.is_file()

        # URL tải file tuyệt đối, đã encode đúng (space -> %20)
        url = str(request.url_for("download", project_id=str(project_id), filename=r.file_name))


        items.append({
            "id": r.id,
            "file_name": r.file_name,
            "url": url,               # ví dụ: http://127.0.0.1:8000/api/uploaded/download/15/Output%20-%20Sheet1.pdf
            "exists": exists,
            "size": fp.stat().st_size if exists else None,
        })
    return ok(items, "Fetched files")