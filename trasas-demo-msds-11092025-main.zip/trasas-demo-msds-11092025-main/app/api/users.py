# Updated file: api/user.py
# Removed redundant manual validations for length/emptiness since Pydantic now handles them with custom messages.
# Kept duplicate checks and other business logic.
# For update, password validation is handled by Pydantic if provided.

from fastapi import APIRouter, Depends, Query, status, Response, HTTPException
from sqlalchemy.orm import Session
from app.models.models import User
from app.schemas.schemas import *
from app.utils.paginate_query import paginate_query
from app.db.session import get_db
from app.core.security import hash_password
from app.utils.response import not_found, ok

router = APIRouter()


@router.post("/", response_model=ResponseBase[UserResponse])
def create_user(user: UserCreate, db: Session = Depends(get_db), response: Response = None):
    """Tạo người dùng mới.
    - Nếu email đã tồn tại, trả về lỗi 409.
    - Trả về thông tin người dùng đã tạo (không bao gồm mật khẩu).
    """
    # Check duplicates (Pydantic handles format validations upstream)
    if db.query(User).filter(User.email == user.email).first():
        raise HTTPException(status_code=409, detail="Email đã được đăng ký")
    # if db.query(User).filter(User.username == user.username).first():
    #     raise HTTPException(status_code=409, detail="Username đã tồn tại")

    hashed_password = hash_password(user.password)  # Use real hash instead of fake
    user_role = user.role if user.role else "User"  # Default role

    db_user = User(
        username=user.username,
        email=user.email,
        password_hash=hashed_password,
        role=user_role,
        status=user.status if hasattr(user, 'status') else 1  # Default status 1 if not provided
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)

    # return ResponseBase(
    #     status="success",
    #     message="Tạo user thành công",
    #     data=db_user
    # )
    return ok(db_user, "Tạo user thành công")


@router.get("/", response_model=ResponseBase[List[UserResponse]], tags=["Users"])
def read_users(db: Session = Depends(get_db)):
    """Lấy danh sách người dùng.
    - Trả về danh sách người dùng (không bao gồm mật khẩu).
    """
    users = db.query(User).filter(User.status == 1).all()

    # return ResponseBase(
    #     status="success",
    #     message="Lấy danh sách users thành công",
    #     data=users
    # )
    return ok(users, "Lấy danh sách users thành công", status.HTTP_200_OK)



@router.get("/{user_id}", response_model=ResponseBase[UserResponse])
def read_user(user_id: int, db: Session = Depends(get_db)):
    """Lấy thông tin người dùng theo ID.
    - Trả về thông tin người dùng (không bao gồm mật khẩu).
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    user = db.query(User).filter(User.id == user_id, User.status == 1).first()
    if user is None:
        return not_found(message="User không tồn tại")

    # return ResponseBase(
    #     status="success",
    #     message="Lấy thông tin user thành công",
    #     data=user
    # )
    return ok(user, "Lấy thông tin user thành công", status.HTTP_200_OK)



@router.put("/{user_id}", response_model=ResponseBase[UserResponse])
def update_user(user_id: int, user: UserUpdate, db: Session = Depends(get_db)):
    """Cập nhật thông tin người dùng theo ID.
    - Trả về thông tin người dùng đã cập nhật (không bao gồm mật khẩu).
    - Nếu không tìm thấy, trả về lỗi 404.
    - Nếu email đã tồn tại, trả về lỗi 409.
    """
    db_user = db.query(User).filter(User.id == user_id).first()
    if db_user is None:
        return not_found(message="User không tồn tại")

    # Check duplicates for updated fields (Pydantic handles format if provided)
    if user.email and db.query(User).filter(User.email == user.email, User.id != user_id).first():
        raise HTTPException(status_code=409, detail="Email đã được đăng ký")
    # if user.username and db.query(User).filter(User.username == user.username, User.id != user_id).first():
    #     raise HTTPException(status_code=409, detail="Username đã tồn tại")

    for key, value in user.model_dump(exclude_unset=True).items():
        if key == "password":
            setattr(db_user, "password_hash", hash_password(value))
        elif key not in {"id", "created_at", "updated_at"}:
            setattr(db_user, key, value)

    db.commit()
    db.refresh(db_user)

    # return ResponseBase(
    #     status="success",
    #     message="Cập nhật user thành công",
    #     data=db_user
    # )
    return ok(db_user, "Cập nhật user thành công", status.HTTP_200_OK)



@router.delete("/{user_id}", status_code=status.HTTP_200_OK, response_model=DeleteResponse)
def delete_user(user_id: int, db: Session = Depends(get_db)):
    """Xoá (deactivate) người dùng theo ID.
    - Thay vì xoá hẳn, chỉ đặt `status` của user về 0 (deactivate).
    - Trả về thông báo thành công.
    - Nếu không tìm thấy, trả về lỗi 404.
    """
    db_user = db.query(User).filter(User.id == user_id).first()
    if db_user is None:
        return not_found(message="User không tồn tại")

    db_user.status = 0   # Soft delete
    db.commit()
    db.refresh(db_user)

    # return DeleteResponse(
    #     status="success",
    #     message="User đã bị deactivate thành công"
    # )
    return ok(None, "User đã bị deactivate thành công", status.HTTP_200_OK)