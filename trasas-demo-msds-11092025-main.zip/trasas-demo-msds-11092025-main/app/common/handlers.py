# app/common/handlers.py
from functools import wraps
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from app.utils.response import ok, fail

def db_guard(fn):
    @wraps(fn)
    def _inner(*args, **kwargs):
        from sqlalchemy.orm import Session
        db: Session = kwargs.get("db") or args[-1]  # tuỳ chữ ký
        try:
            return fn(*args, **kwargs)
        except IntegrityError as e:
            db.rollback()
            return fail("Dữ liệu trùng hoặc vi phạm ràng buộc", 409, str(e.orig))
        except SQLAlchemyError as e:
            db.rollback()
            return fail("DB error", 500, str(e))
    return _inner
