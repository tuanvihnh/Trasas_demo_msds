from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, model_validator
from urllib.parse import quote_plus

class Settings(BaseSettings):
    DATABASE_URL: str | None = None
    DATABASE_USER: str | None = None
    DATABASE_PASSWORD: str | None = None
    DATABASE_HOST: str = "localhost"
    DATABASE_PORT: int = 3306
    DATABASE_NAME: str = "trasas_msds_v8"
    PBKDF2_ITER: int = 100_000
    CORS_ORIGINS: list[str] = ["*"]
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")
    JWT_SECRET: str | None = None

    
    openai_api_key: str | None = Field(default=None, alias="OPENAI_API_KEY")
    openai_msds_assistant_id: str | None = Field(default=None, alias="OPENAI_MSDS_ASSISTANT_ID")
    openai_model: str = Field(default="gpt-4o-mini", alias="OPENAI_MODEL")
    api_base_url: str = Field(default="http://localhost:8000", alias="API_BASE_URL")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,   # chấp nhận openai_api_key hoặc OPENAI_API_KEY
        extra="ignore",         # bỏ qua biến lạ trong .env thay vì raise lỗi
    )
    
    @model_validator(mode="after")
    def build_dsn(self):
        if not self.DATABASE_URL:
            pwd = quote_plus(self.DATABASE_PASSWORD or "")
            self.DATABASE_URL = (
                f"mysql+pymysql://{self.DATABASE_USER}:{pwd}@{self.DATABASE_HOST}:"
                f"{self.DATABASE_PORT}/{self.DATABASE_NAME}?charset=utf8mb4"
            )
        return self

settings = Settings()
