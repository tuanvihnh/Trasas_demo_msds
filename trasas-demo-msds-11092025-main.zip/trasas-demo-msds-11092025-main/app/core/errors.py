from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from fastapi.exception_handlers import http_exception_handler
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from app.utils.response import conflict, server_error, validation_error


def _safe_errors(errs):
    out = []
    for e in errs:
        e = dict(e)
        if "ctx" in e and e["ctx"] is not None:
            try:
                jsonable_encoder(e["ctx"])  # thử encode
            except Exception:
                # ép ctx thành chuỗi ngắn gọn
                e["ctx"] = {k: str(v) for k, v in dict(e["ctx"]).items()} if isinstance(e["ctx"], dict) else str(e["ctx"])
        out.append(e)
    return out

def attach_envelope_error_handlers(app: FastAPI):
    @app.exception_handler(StarletteHTTPException)
    async def http_err(request: Request, exc: StarletteHTTPException):
        resp = await http_exception_handler(request, exc)
        return JSONResponse(status_code=resp.status_code,
                            content={"status": "error", "message": exc.detail, "data": None})

    @app.exception_handler(RequestValidationError)
    async def pyd_err(request: Request, exc: RequestValidationError):
        # payload = {
        #     "success": False,
        #     "message": "Validation error",
        #     "data": _safe_errors(exc.errors()),
        # }
        return validation_error(message="Validation error", data=_safe_errors(exc.errors()))
    @app.exception_handler(IntegrityError)
    async def sa_integrity_err(request: Request, exc: IntegrityError):
        msg = "Vi phạm ràng buộc dữ liệu"
        if "1062" in str(exc.orig):  # duplicate key MySQL
            msg = "Dữ liệu đã tồn tại"
        return conflict(message=msg, data=str(exc.orig) if hasattr(exc, "orig") else str(exc))

    @app.exception_handler(SQLAlchemyError)
    async def sa_err(request: Request, exc: SQLAlchemyError):
        return server_error(message="DB error", data= str(exc.orig) if hasattr(exc, "orig") else str(exc))
