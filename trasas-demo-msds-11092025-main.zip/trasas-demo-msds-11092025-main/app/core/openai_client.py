from dotenv import load_dotenv
from openai import OpenAI
import os
# Đảm bảo có API Key
os.environ["OPENAI_API_KEY"]="sk-..." # Hoặc export qua biến môi trường


client = OpenAI()
