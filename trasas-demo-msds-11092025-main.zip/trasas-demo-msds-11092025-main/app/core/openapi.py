# app/core/openapi.py
from fastapi.openapi.utils import get_openapi
from fastapi import FastAPI

OK_EXAMPLE = {
    "status": "success",
    "message": "OK",
    "data": {}
}
UNAUTHORIZED_EXAMPLE = {
    "status": "error",
    "message": "Thiếu token",
    "data": None
}
VALIDATION_EXAMPLE = {
    "status": "error",
    "message": "Validation error",
    "data": [{"loc": ["body","field"], "msg": "field required", "type": "value_error.missing"}]
}

def _wrap_schema(old_schema):
    # Nếu không có schema cũ thì để data = null
    data_schema = old_schema or {"nullable": True}
    return {
        "type": "object",
        "required": ["status", "message"],
        "properties": {
            "status": {"type": "string", "enum": ["success", "error"]},
            "message": {"type": "string"},
            "data":    data_schema
        }
    }

def build_openapi(app: FastAPI):
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=app.title or "API",
        version="1.0.0",
        description=app.description or "",
        routes=app.routes,
    )

    # Duyệt toàn bộ path/method
    for path, methods in (openapi_schema.get("paths") or {}).items():
        for method, op in methods.items():
            if not isinstance(op, dict):
                continue
            responses = op.setdefault("responses", {})

            # Chuẩn hoá 200
            if "200" in responses:
                content = responses["200"].setdefault("content", {})
                if "application/json" in content:
                    old_schema = content["application/json"].get("schema")
                    content["application/json"]["schema"] = _wrap_schema(old_schema)
                    # ví dụ mẫu
                    content["application/json"]["example"] = OK_EXAMPLE

            # Thêm 401 mẫu nếu có security/bảo vệ
            has_security = bool(op.get("security") or openapi_schema.get("security"))
            if has_security and "401" not in responses:
                responses["401"] = {
                    "description": "Unauthorized",
                    "content": {
                        "application/json": {
                            "schema": _wrap_schema({"nullable": True}),
                            "example": UNAUTHORIZED_EXAMPLE
                        }
                    }
                }

            # Thêm 422 mẫu (validation)
            if "422" in responses:
                content = responses["422"].setdefault("content", {})
                content["application/json"] = {
                    "schema": _wrap_schema({
                        "type": "array",
                        "items": {"type": "object"}
                    }),
                    "example": VALIDATION_EXAMPLE
                }

    app.openapi_schema = openapi_schema
    return app.openapi_schema
