# app/core/security.py
from datetime import datetime, timedelta
from typing import Optional
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from sqlalchemy.orm import Session
from app.models.models import User
from app.db.session import get_db
from passlib.hash import bcrypt
from app.core.config import settings
SECRET = settings.JWT_SECRET or "change-me"
ALG = "HS256"
ACCESS_MIN = 60 * 24 # 1 day
bearer = HTTPBearer(auto_error=False)

# --- password helpers ---
def hash_password(plain: str) -> str:
    return bcrypt.hash(plain)

def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.verify(plain, hashed)
    except Exception:
        return False

# --- jwt helpers ---
def create_access_token(user_id: int, minutes: int = ACCESS_MIN) -> str:
    exp = datetime.utcnow() + timedelta(minutes=minutes)
    payload = {"sub": str(user_id), "exp": exp}
    return jwt.encode(payload, SECRET, algorithm=ALG)

def decode_token(token: str) -> Optional[int]:
    try:
        payload = jwt.decode(token, SECRET, algorithms=[ALG])
        sub = payload.get("sub")
        return int(sub) if sub is not None else None
    except JWTError:
        return None

def get_current_user(
    db: Session = Depends(get_db),
    cred: HTTPAuthorizationCredentials | None = Depends(bearer),
) -> User:
    if not cred or cred.scheme.lower() != "bearer":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Thiếu token")
    user_id = decode_token(cred.credentials)
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token không hợp lệ")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Không tìm thấy user")
    return user

# Tuỳ chọn: cho endpoint không bắt buộc đăng nhập
def get_current_user_optional(
    db: Session = Depends(get_db),
    cred: HTTPAuthorizationCredentials | None = Depends(bearer),
) -> User | None:
    if not cred:
        return None
    user_id = decode_token(cred.credentials)
    return db.get(User, user_id) if user_id else None
