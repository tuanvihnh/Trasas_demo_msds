# Mock data cho API
mock_chemical_products = [
    {
        "id": "1",
        "productName": "Acetone",
        "group": "Solvents",
        "storage": "Room Temperature",
        "storageType": "Dry",
        "temperature": "15-25°C",
        "note": "Highly flammable",
        "substances": [
            {
                "id": "s1",
                "casNumber": "67-64-1",
                "composition": ">= 99.5%",
                "ghs": "H225, H319, H336",
                "dangerousChemicalInfo": "Flammable Liquid, Category 2",
                "appendix01": True,
                "appendix02": False,
                "appendix03": False,
                "appendix04": True,
                "appendix05": True,
                "isIndustrialPrecursor": True,
                "noLicense": False,
                "hasConditionalLicense": True,
                "hasRestrictedLicense": False,
                "hasTableChemical": True
            }
        ]
    },
    {
        "id": "2",
        "productName": "Sodium Hydroxide",
        "group": "Bases",
        "storage": "Cool, Dry Place",
        "storageType": "Corrosive Cabinet",
        "temperature": "Below 30°C",
        "note": "Corrosive",
        "substances": [
            {
                "id": "s2",
                "casNumber": "1310-73-2",
                "composition": "50% in water",
                "ghs": "H314, H290",
                "dangerousChemicalInfo": "Corrosive to metals, Category 1",
                "appendix01": True,
                "appendix02": False,
                "appendix03": False,
                "appendix04": True,
                "appendix05": True,
                "isIndustrialPrecursor": False,
                "noLicense": False,
                "hasConditionalLicense": False,
                "hasRestrictedLicense": True,
                "hasTableChemical": False
            }
        ]
    },
    {
        "id": "3",
        "productName": "Hydrochloric Acid",
        "group": "Acids",
        "storage": "Cool, Dry Place",
        "storageType": "Acid Cabinet",
        "temperature": "Below 25°C",
        "note": "Highly corrosive",
        "substances": [
            {
                "id": "s3",
                "casNumber": "7647-01-0",
                "composition": "37% in water",
                "ghs": "H314, H335",
                "dangerousChemicalInfo": "Corrosive to metals, Category 1",
                "appendix01": True,
                "appendix02": False,
                "appendix03": False,
                "appendix04": True,
                "appendix05": True,
                "isIndustrialPrecursor": False,
                "noLicense": False,
                "hasConditionalLicense": True,
                "hasRestrictedLicense": False,
                "hasTableChemical": True
            },
            {
                "id": "s3",
                "casNumber": "7647-01-0",
                "composition": "37% in water",
                "ghs": "H314, H335",
                "dangerousChemicalInfo": "Corrosive to metals, Category 1",
                "appendix01": True,
                "appendix02": False,
                "appendix03": False,
                "appendix04": True,
                "appendix05": True,
                "isIndustrialPrecursor": False,
                "noLicense": False,
                "hasConditionalLicense": True,
                "hasRestrictedLicense": False,
                "hasTableChemical": True
            }
        ]
    },
    {
        "id": "4",
        "productName": "Ethanol",
        "group": "Solvents",
        "storage": "Room Temperature",
        "storageType": "Flammable Cabinet",
        "temperature": "15-25°C",
        "note": "Flammable",
        "substances": [
            {
                "id": "s4",
                "casNumber": "64-17-5",
                "composition": "95%",
                "ghs": "H225, H319",
                "dangerousChemicalInfo": "Flammable Liquid, Category 2",
                "appendix01": True,
                "appendix02": False,
                "appendix03": False,
                "appendix04": True,
                "appendix05": True,
                "isIndustrialPrecursor": True,
                "noLicense": False,
                "hasConditionalLicense": True,
                "hasRestrictedLicense": False,
                "hasTableChemical": False
            }
        ]
    },
    {
        "id": "5",
        "productName": "Methanol",
        "group": "Solvents",
        "storage": "Room Temperature",
        "storageType": "Flammable Cabinet",
        "temperature": "15-25°C",
        "note": "Toxic and flammable",
        "substances": [
            {
                "id": "s5",
                "casNumber": "67-56-1",
                "composition": "99.8%",
                "ghs": "H225, H301, H311, H331",
                "dangerousChemicalInfo": "Flammable Liquid, Category 2; Toxic, Category 3",
                "appendix01": True,
                "appendix02": False,
                "appendix03": False,
                "appendix04": True,
                "appendix05": True,
                "isIndustrialPrecursor": True,
                "noLicense": False,
                "hasConditionalLicense": False,
                "hasRestrictedLicense": True,
                "hasTableChemical": True
            }
        ]
    }
]

mock_projects_with_msds = [
    {
        "id": "proj-1",
        "name": "Dự án A - Hóa chất công nghiệp",
        "creator": "Nguyễn Văn A",
        "createdAt": "20/10/2023",
        "msds": mock_chemical_products[:3]
    },
    {
        "id": "proj-2",
        "name": "Dự án B - Hóa chất nông nghiệp",
        "creator": "Trần Thị B",
        "createdAt": "15/11/2023",
        "msds": mock_chemical_products[3:5]
    },
    {
        "id": "proj-3",
        "name": "Dự án C - Hóa chất phòng thí nghiệm",
        "creator": "Lê Văn C",
        "createdAt": "01/12/2023",
        "msds": []  # Project không có MSDS để test
    },
    {
        "id": "proj-4",
        "name": "Dự án D - Hóa chất tiêu dùng",
        "creator": "Phạm Thị D",
        "createdAt": "25/12/2023",
        "msds": mock_chemical_products[2:4]
    }
]