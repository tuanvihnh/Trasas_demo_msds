from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from app.core.config import *
from app.core.config import Settings
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.config import Settings

settings = Settings()

engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=False,
    future=True,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def get_db():
    db = SessionLocal()
    db.execute(text("SET SESSION innodb_lock_wait_timeout=5"))
    try:
        yield db
    finally:
        db.close()
