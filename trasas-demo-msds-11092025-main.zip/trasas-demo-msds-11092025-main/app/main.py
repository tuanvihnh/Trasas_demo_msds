from fastapi import FastAPI, HTTPException, Request, status

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.core.config import Settings
from app.core.errors import attach_envelope_error_handlers
from app.db.session import get_db
from app.exceptions import http_exception_handler
from app.utils.download import STATIC_ROOT
from app.utils.response import ok
from app.core.config import Settings

from app.api import appendix, license, assistant, auth, elements, extracts, outputs, permits, regulations, users, projects, msds, chemicals ,ghs, links, processes, uploaded, regapp, msds_detail

from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
# from app.middleware.audit import AuditUserContextMiddleware
from app.core.openapi import build_openapi
from fastapi.staticfiles import StaticFiles
from app.core.errors import attach_envelope_error_handlers
import os
from starlette.staticfiles import StaticFiles

from app.middleware.envelope import install_envelope
settings = Settings()
app = FastAPI(title="MSDS Management API", version="1.0.0")

app.add_middleware(CORSMiddleware,
                   allow_origins=settings.CORS_ORIGINS,
                   allow_credentials=True,
                   allow_methods=["*"],
                   allow_headers=["*"])

# app.add_middleware(AuditUserContextMiddleware)
install_envelope(app)
attach_envelope_error_handlers(app)
app.openapi = lambda: build_openapi(app)

app.add_exception_handler(HTTPException, http_exception_handler)

app.include_router(msds_detail.router, prefix="/api",                  tags=["MSDS Detail"])

app.include_router(appendix.router,     prefix="/api/appendices",      tags=["Appendices"])
app.include_router(auth.router,         prefix="/api/auth",            tags=["Authentication"])
app.include_router(chemicals.router,    prefix="/api/chemicals",       tags=["Chemicals"])
app.include_router(extracts.router,     prefix="/api/extracts",        tags=["Extract"])
app.include_router(ghs.router,          prefix="/api/ghs",             tags=["GHS"])
app.include_router(license.router,      prefix="/api/license",         tags=["License Management"])
app.include_router(links.router,        prefix="/api/links",           tags=["Links"])
app.include_router(msds.router,         prefix="/api/msds",            tags=["MSDS"])
app.include_router(assistant.router,    prefix="/api/openai",          tags=["Assistant"])
app.include_router(elements.router,     prefix="/api/output-elements", tags=["Output Elements"])
app.include_router(permits.router,      prefix="/api/output-permits",  tags=["Output Permits"])
app.include_router(outputs.router,      prefix="/api/outputs",         tags=["Outputs"])
app.include_router(processes.router,    prefix="/api/processes",       tags=["Processes"])
app.include_router(projects.router,     prefix="/api/projects",        tags=["Projects"])
app.include_router(regapp.router,       prefix="/api/regapp",          tags=["Regulation Appendices"])
app.include_router(regulations.router,  prefix="/api/regulations",     tags=["Regulations"])
app.include_router(uploaded.router,     prefix="/api/uploaded",        tags=["Uploaded Files"])
app.include_router(users.router,        prefix="/api/users",           tags=["Users"])




app.mount("/static", StaticFiles(directory=str(STATIC_ROOT)), name="static")

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# STATIC_DIR = os.path.join(BASE_DIR, "static")

# app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/", status_code=status.HTTP_200_OK, tags=["Root"])
async def root():
    return ok(message="Welcome to the MSDS Management API!", data=None)
