# app/middleware/audit.py
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from jose import jwt, JWTError

SECRET = "change-me"   # dùng đúng secret của bạn
ALG = "HS256"

# class AuditUserContextMiddleware(BaseHTTPMiddleware):
#     async def dispatch(self, request: Request, call_next):
#         user_id = None
#         username = None

#         # 1) Ưu tiên Bearer JWT
#         auth = request.headers.get("Authorization") or ""
#         if auth.lower().startswith("bearer "):
#             token = auth.split(" ", 1)[1].strip()
#             try:
#                 payload = jwt.decode(token, SECRET, algorithms=[ALG])
#                 sub = payload.get("sub")
#                 if sub:
#                     user_id = int(sub)
#             except JWTError:
#                 # token lỗi -> cứ để user_id = None
#                 pass

#         # 2) Dự phòng qua header thủ công
#         if user_id is None:
#             hdr_uid = request.headers.get("X-User-Id")
#             if hdr_uid and hdr_uid.isdigit():
#                 user_id = int(hdr_uid)
#         username = request.headers.get("X-Username")

#         # gán vào state cho downstream dùng
#         request.state.user_id = user_id
#         request.state.username = username

#         return await call_next(request)
