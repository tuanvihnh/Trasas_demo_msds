# app/middleware/envelope.py
import json
from fastapi import Response
from fastapi.responses import JSONResponse

def install_envelope(app):
    @app.middleware("http")
    async def envelope(request, call_next):
        # bỏ qua docs/openapi
        p = request.url.path
        if p == "/openapi.json" or p.startswith("/docs") or p.startswith("/redoc"):
            return await call_next(request)

        resp: Response = await call_next(request)

        # Chỉ bọc JSON 2xx đã render sẵn
        if not (200 <= resp.status_code < 300):
            return resp
        if not isinstance(resp, JSONResponse):
            return resp

        # Lấy payload từ resp.body (KHÔNG đọc iterator)
        try:
            raw = resp.body  # bytes
            payload = json.loads(raw.decode("utf-8") or "null")
        except Exception:
            return resp  # không phải JSON hợp lệ thì để nguyên

        if isinstance(payload, dict) and "status" in payload:
            return resp

        # Bọc lại
        wrapped = {"status": "success", "message": "OK", "data": payload}
        new_resp = JSONResponse(status_code=resp.status_code, content=wrapped)

        # copy headers quan trọng
        for k, v in resp.headers.items():
            if k.lower() not in {"content-length", "transfer-encoding"}:
                new_resp.headers[k] = v
        return new_resp
