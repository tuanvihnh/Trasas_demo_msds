from contextvars import ContextVar

_current_user_id = ContextVar("current_user_id", default=None)

def set_current_user_id(uid: int | None) -> None:
    _current_user_id.set(uid)

def get_current_user_id() -> int | None:
    return _current_user_id.get()
