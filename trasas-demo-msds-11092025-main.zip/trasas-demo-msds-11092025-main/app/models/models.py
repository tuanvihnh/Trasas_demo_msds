
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Depends, status, Query
from datetime import datetime
from sqlalchemy import Date, create_engine, Column, Integer, String, Text, DateTime, DECIMAL, ForeignKey, Boolean, BigInteger
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.sql import func
import base64, hashlib, secrets
from datetime import datetime, timedelta
import json
from sqlalchemy import UniqueConstraint, text, bindparam
from sqlalchemy import Column
from sqlalchemy.orm import Session
from app.schemas.schemas import *
from sqlalchemy import event
from sqlalchemy.orm import Session as _Session
import contextvars
from app.core.config import settings
from sqlalchemy import Text as MEDIUMTEXT
from sqlalchemy import Column, BigInteger, Integer, String, Text, ForeignKey, DateTime, Numeric

# engine = create_engine(DATABASE_URL)
engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True, pool_recycle=3600, echo=False)

Base = declarative_base()

class TimestampMixin:
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

class BaseTable(Base, TimestampMixin):
    __abstract__ = True
    status = Column(Integer, default=1, nullable=False)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(255), unique=True, index=True, nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(255), nullable=True)
    status = Column(Integer, default=1, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    create_by = Column(Integer, nullable=True, comment='user id created')
    update_by = Column(Integer, nullable=True, comment='user id updated')

    projects = relationship("Project", back_populates="owner", cascade="save-update, merge", passive_deletes=True)

class Chemical(BaseTable):
    __tablename__ = 'chemicals'
    id = Column(Integer, primary_key=True, index=True)
    chemical_name = Column(String(255), nullable=False)
    chemical_name_vn = Column(String(255), nullable=True)
    cas_no = Column(String(50), unique=True, nullable=False)
    molecular_formula = Column(String(255), nullable=True)
    molecular_weight = Column(DECIMAL(10, 2), nullable=True)
    chemical_class = Column(String(255), nullable=True)
    hs_code = Column(String(50), nullable=True)
    hazard_classification = Column(Text, nullable=True)
    safety_precautions = Column(Text, nullable=True)
    storage_conditions = Column(Text, nullable=True)
    disposal_instructions = Column(Text, nullable=True)
    regulatory_info = Column(Text, nullable=True)
    create_by = Column(Integer, nullable=True, comment='user id created')
    update_by = Column(Integer, nullable=True, comment='user id updated')
    status = Column(Integer, default=1, nullable=False)
    # appendix_chemicals = relationship("AppendixChemical", back_populates="chemical")
    # regulatory_notes = relationship("ChemicalMapping", back_populates="chemical")  # Added
    mappings = relationship(
        "ChemicalMapping",
        back_populates="chemical",
        cascade="all, delete-orphan",
        lazy="selectin",
    )


class GHSClassification(BaseTable):
    __tablename__ = 'ghs_classifications'
    id = Column(Integer, primary_key=True, index=True)
    hazard_class = Column(String(255), nullable=False)
    code = Column(String(64), nullable=True)
    image_url = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    status = Column(Integer, default=1, nullable=False)
    create_by = Column(Integer, nullable=True, comment='user id created')
    update_by = Column(Integer, nullable=True, comment='user id updated')

# class Regulation(BaseTable):
#     __tablename__ = 'regulations'
#     id = Column(Integer, primary_key=True, index=True)
#     regulation_title = Column(String(255), nullable=False)
#     regulation_description = Column(Text, nullable=True)
#     legal_reference = Column(String(255), nullable=True)
#     applicable_laws = Column(Text, nullable=True)
#     create_by = Column(Integer, nullable=True, comment='user id created')
#     update_by = Column(Integer, nullable=True, comment='user id updated')

#     appendices = relationship("Appendix", back_populates="regulation")
#     regulatory_notes = relationship("ChemicalMapping", back_populates="regulation")  # Added
#     status = Column(Integer, default=1, nullable=False)

# class Article(BaseTable):
#     __tablename__ = 'articles'
#     id = Column(Integer, primary_key=True, index=True)
#     regulation_id = Column(Integer, ForeignKey('regulations.id'), nullable=False)
#     article_number = Column(Integer, nullable=True)
#     article_title = Column(String(255), nullable=True)
#     article_content = Column(Text, nullable=True)
#     create_by = Column(Integer, nullable=True, comment='user id created')
#     update_by = Column(Integer, nullable=True, comment='user id updated')
#     status = Column(Integer, default=1, nullable=False)
#     appendices = relationship("Appendix", back_populates="article")
#     regulatory_notes = relationship("ChemicalMapping", back_populates="article")  # Added

class MSDS(BaseTable):
    __tablename__ = 'msds'
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False, index=True)
    product_name = Column(String(255), nullable=True)
    msds_no = Column(String(100), nullable=True)
    manufacturer_name = Column(String(255), nullable=True)
    manufacturer_address = Column(String(500), nullable=True)
    manufacturer_phone = Column(String(100), nullable=True)
    signal_word = Column(String(100), nullable=True)
    hazard_statements = Column(Text, nullable=True)
    precautionary_statements_text = Column(Text, nullable=True)
    ghs_symbols_text = Column(Text, nullable=True)
    composition_info = Column(Text, nullable=True)
    ingredient_percentage = Column(String(255), nullable=True)
    first_aid_measures = Column(Text, nullable=True)
    fire_fighting_measures = Column(Text, nullable=True)
    accidental_release_measures = Column(Text, nullable=True)
    handling_storage = Column(Text, nullable=True)
    exposure_control = Column(Text, nullable=True)
    physical_chemical_properties = Column(Text, nullable=True)
    stability_reactivity = Column(Text, nullable=True)
    toxicological_info = Column(Text, nullable=True)
    ecological_info = Column(Text, nullable=True)
    disposal_considerations = Column(Text, nullable=True)
    transport_info = Column(Text, nullable=True)
    regulatory_info = Column(Text, nullable=True)
    other_info = Column(Text, nullable=True)
    create_by = Column(Integer, nullable=True, comment='user id created')
    update_by = Column(Integer, nullable=True, comment='user id updated')
    status = Column(Integer, default=1, nullable=False)
    project = relationship("Project", back_populates="msds", foreign_keys=[project_id], passive_deletes=True)
    process_entries = relationship("Process", back_populates="msds")
    msds_chemicals_link = relationship("MSDSChemical", back_populates="msds", cascade="all, delete-orphan", passive_deletes=True, lazy="selectin")

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    project_name = Column(String(255), unique=True, index=True, nullable=False)
    description = Column(Text)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), index=True, nullable=True)
    vector_store_id = Column(String(255))
    status = Column(Integer, default=1, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    vector_store_id = Column(String(255), nullable=True)  # NEW
    owner = relationship("User", back_populates="projects")
    msds = relationship(
        "MSDS", 
        back_populates="project", 
        cascade="all, delete-orphan", 
        passive_deletes=True, 
        foreign_keys="MSDS.project_id")
    uploaded_files = relationship("UploadedFile", back_populates="project", cascade="all, delete-orphan", passive_deletes=True)
    outputs = relationship(
        "Output",
        back_populates="project",
        cascade="all, delete-orphan",
        foreign_keys="Output.project_id",
        passive_deletes=True,
    )

class Output(Base):
    __tablename__ = "output"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    product_name = Column(String(255), nullable=True)
    ghs_signal_word = Column(String(64), nullable=True)
    ghs_hazard_statements = Column(Text, nullable=True)
    msds_id = Column(Integer, ForeignKey("msds.id", ondelete="SET NULL", onupdate="CASCADE"), nullable=True)
    total_pct = Column(DECIMAL(6,2), nullable=True)
    temperature_storage_at = Column(String(255), nullable=True)
    warehouse_type = Column(String(64), nullable=True)
    product_class = Column(String(128), nullable=True)
    is_msds_vn_16_field = Column(String(255), nullable=True)
    special_warnings_transportation = Column(Text, nullable=True)
    match_class_of_products = Column(Boolean, default=False, nullable=False)
    physical_state = Column(Text, nullable=True)
    physicochemical_properties = Column(Text, nullable=True)
    toxicity = Column(Text, nullable=True)
    status = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    create_by = Column(BigInteger, nullable=True)
    update_by = Column(BigInteger, nullable=True)
    dangerous_chemical = Column(Boolean, default=False, nullable=False)
    project = relationship("Project", back_populates="outputs", foreign_keys=[project_id], passive_deletes=True)
    elements = relationship("OutputElement", back_populates="output", cascade="all, delete-orphan", passive_deletes=True)
    permits = relationship("OutputPermit", back_populates="output", cascade="all, delete-orphan", passive_deletes=True)
    
class OutputElement(Base):
    __tablename__ = "output_element"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    output_id = Column(BigInteger, ForeignKey("output.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    cas_no = Column(String(64), nullable=False)
    chemical_name = Column(String(255), nullable=True)
    wtf = Column(String(64), nullable=True)
    dangerous_chemical = Column(Boolean, default=False)
    pl1 = Column(Text, nullable=True)
    pl2 = Column(Text, nullable=True)
    pl3 = Column(Text, nullable=True)
    pl4 = Column(Text, nullable=True)
    pl5 = Column(Text, nullable=True)
    no_license = Column(Boolean, default=False)
    drug_precursors = Column(Text, nullable=True)  # Đổi từ Boolean thành Text
    table_chemicals = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)
    status = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    create_by = Column(BigInteger, nullable=True)
    update_by = Column(BigInteger, nullable=True)
    conditional_license = Column(Integer, default=0, nullable=False)  # Added missing field
    restricted_chemical_license = Column(Integer, default=0, nullable=False)  # Added missing field
    output = relationship("Output", back_populates="elements")

class Process(Base):
    __tablename__ = 'process'
    id = Column(Integer, primary_key=True, index=True)
    msds_id = Column(Integer, ForeignKey('msds.id'), nullable=False)
    status = Column(Integer, default=1, nullable=False)
    message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    create_by = Column(Integer, nullable=True, comment='user id created')
    update_by = Column(Integer, nullable=True, comment='user id updated')
    msds = relationship("MSDS", back_populates="process_entries")

class UploadedFile(Base):
    __tablename__ = 'uploaded_files'
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=True, index=True)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    status = Column(Integer, default=1, nullable=False)
    project = relationship('Project', back_populates='uploaded_files')
    # @hybrid_property
    # def path(self):
    #     # Ưu tiên relative_path > file_path > fallback từ project_id/filename
    #     if self.file_path :
    #         return self.file_path 
    #     if self.file_path:
    #         return self.file_path
    #     return f"{self.project_id}/{self.file_name}"

class Appendix(Base):
    __tablename__ = "appendix"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)

    # KHÔNG dùng tên 'regulation' cho relationship
    regulation_id = Column(Integer, ForeignKey("regulation.id"), nullable=True)

    # ----- legacy text columns -----
    content = Column(Text)
    # ⚠️ map cột DB 'regulation' sang thuộc tính Python KHÁC tên:
    regulation_text = Column("regulation", Text)   # <— đây là STRING legacy
    note = Column(String(512))
    law_text = Column(Text)
    status = Column(Integer)
    created_at = Column(String(32))
    updated_at = Column(String(32))
    create_by = Column(Integer)
    update_by = Column(Integer)

    # ----- relationship -----
    regulation = relationship(               # <— object quan hệ
        "Regulation",
        back_populates="appendices",
        lazy="joined",
        foreign_keys=[regulation_id],
    )

# class Appendix(BaseTable):
#     __tablename__ = 'appendix'
#     id = Column(Integer, primary_key=True, index=True)
#     regulation_id = Column(Integer, ForeignKey('regulations.id'), nullable=True)
#     code = Column(String(32), nullable=False)
#     title = Column(String(512), nullable=True)
#     article_id = Column(Integer, ForeignKey('articles.id'), nullable=True)
#     description = Column(Text, nullable=True)

#     regulation = relationship("Regulation", back_populates="appendices")
#     article = relationship("Article", back_populates="appendices")
#     chemicals = relationship("AppendixChemical", back_populates="appendix")
#     regulatory_notes = relationship("ChemicalMapping", back_populates="appendix")  # Added
#     status = Column(Integer, default=1, nullable=False)
#     __table_args__ = (UniqueConstraint('regulation_id', 'code', name='uk_appendix'),)

# class AppendixChemical(Base):
#     __tablename__ = 'appendix_chemicals'
#     id = Column(BigInteger, primary_key=True, index=True)
#     appendix_id = Column(Integer, ForeignKey('appendix.id'), nullable=False)
#     chemical_id = Column(Integer, ForeignKey('chemicals.id'), nullable=False)
#     status = Column(Integer, default=1, nullable=False)
#     create_by = Column(Integer, nullable=True, comment='user id created')
#     update_by = Column(Integer, nullable=True, comment='user id updated')
#     created_at = Column(DateTime, default=func.now(), nullable=False)
#     updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)

#     appendix = relationship("Appendix", back_populates="chemicals")
#     chemical = relationship("Chemical", back_populates="appendix_chemicals")

#     __table_args__ = (UniqueConstraint('appendix_id', 'chemical_id', name='uk_appendix_chem'),)

class MSDSChemical(Base):
    __tablename__ = "msds_chemicals"
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    msds_id = Column(BigInteger, ForeignKey("msds.id"), nullable=False, index=True)
    chemical_name = Column(String(255), nullable=True)
    cas_no = Column(String(64), index=True, nullable=True)   # index
    percentage = Column(DECIMAL(5, 2), nullable=True)
    wtf = Column(String(32), nullable=True)                  # NEW
    role = Column(String(64), nullable=True)
    status = Column(Integer, default=1, nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    create_by = Column(Integer, nullable=True, comment='user id created')
    update_by = Column(Integer, nullable=True, comment='user id updated')
    msds = relationship("MSDS", back_populates="msds_chemicals_link")

class OutputPermit(Base):
    __tablename__ = "output_permits"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    output_id = Column(BigInteger, ForeignKey("output.id", ondelete="CASCADE", onupdate="CASCADE"), nullable=False)
    un_number = Column(String(64), nullable=True)
    match_chemical_name_core_component = Column(Boolean, default=False)
    match_un_number = Column(Boolean, default=False)
    license_number = Column(String(128), nullable=True)
    license_plate_number = Column(String(128), nullable=True)
    expiration_date = Column(Date, nullable=True)
    route_allowed = Column(String(255), nullable=True)
    status = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    create_by = Column(BigInteger, nullable=True)
    update_by = Column(BigInteger, nullable=True)
    output = relationship("Output", back_populates="permits")



class Regulation(Base):
    __tablename__ = "regulation"
    id = Column(Integer, primary_key=True)
    code = Column(String(255), unique=True, nullable=False, index=True)
    title = Column(String(255), nullable=False)
    note = Column(String(512))
    law_text = Column(Text)


    # back_populates phải trỏ tới tên QUAN HỆ thật sự dưới Appendix
    appendices = relationship("Appendix", back_populates="regulation", lazy="selectin")


class ChemicalMapping(Base):
    __tablename__ = "chemical_mappings"
    id = Column(Integer, primary_key=True, index=True)
    chemical_id = Column(Integer, ForeignKey("chemicals.id", ondelete="CASCADE"), nullable=False, index=True)
    appendix_id  = Column(Integer, ForeignKey("appendix.id",  ondelete="RESTRICT", onupdate="CASCADE"), nullable=True, index=True)

    chemical = relationship("Chemical", lazy="joined", foreign_keys=[chemical_id])
    appendix = relationship("Appendix", lazy="joined", foreign_keys=[appendix_id])



RegulationAppendix = Appendix
    


class License(Base):
    __tablename__ = "license"
    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(255), nullable=False, unique=True, index=True)
    content = Column(Text)
    description = Column(Text)
    status = Column(Integer, nullable=False, default=1, server_default="1")
    created_at = Column(DateTime, nullable=False, server_default=func.now())
    created_by = Column(BigInteger)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    updated_by = Column(BigInteger)



Base.metadata.create_all(bind=engine)

_current_user_id = contextvars.ContextVar("current_user_id", default=None)

def set_current_user_id(user_id: int | None):
    _current_user_id.set(user_id)

@event.listens_for(_Session, "before_flush")
def _fill_audit_fields(session, flush_context, instances):
    uid = _current_user_id.get()
    # For newly added objects
    for obj in session.new:
        for attr in ("create_by", "update_by"):
            if hasattr(obj, attr) and getattr(obj, attr) in (None, 0) and uid is not None:
                try:
                    setattr(obj, attr, int(uid))
                except Exception:
                    # If column is String in some tables, fallback to str
                    setattr(obj, attr, str(uid))
    # For dirty/updated objects
    for obj in session.dirty:
        if hasattr(obj, "update_by") and uid is not None:
            try:
                setattr(obj, "update_by", int(uid))
            except Exception:
                setattr(obj, "update_by", str(uid))