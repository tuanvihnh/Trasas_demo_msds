# app/schemas/common.py
from typing import Generic, Optional, TypeVar, List
from pydantic import BaseModel, ConfigDict

T = TypeVar("T")

class ResponseEnvelope(BaseModel, Generic[T]):
    status: str = "success"
    message: Optional[str] = None
    data: Optional[T] = None
    model_config = ConfigDict(from_attributes=True, arbitrary_types_allowed=True)

class PageMeta(BaseModel):
    total: int
    offset: int
    limit: int

class Paginated(BaseModel, Generic[T]):
    meta: PageMeta
    items: List[T]
