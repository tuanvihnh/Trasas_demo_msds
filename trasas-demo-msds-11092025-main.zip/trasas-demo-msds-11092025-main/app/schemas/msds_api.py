from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime

# Schema cho API GET /api/projects/{project_id}/msds/{msds_id}/chemicals
class MsdsChemicalItem(BaseModel):
    chemical_name: Optional[str] = None
    cas_number: Optional[str] = None
    percentage: Optional[float] = None
    wtf: Optional[str] = None

    class Config:
        from_attributes = True
        populate_by_name = True

class MsdsChemicalsResponse(BaseModel):
    project_id: int
    msds_id: int
    items: List[MsdsChemicalItem] = []

# Schema cho API GET /api/projects/{project_id}/msds/{msds_id}/notes
class MsdsNoteItem(BaseModel):
    cas_number: str = Field(...)
    related_appendix: List[str] = []
    notes: str = ""

    class Config:
        from_attributes = True
        populate_by_name = True

class MsdsNotesResponse(BaseModel):
    project_id: int
    msds_id: int
    items: List[MsdsNoteItem] = []
