# File: schemas/schemas.py (sửa để thêm elements vào OutputOut)
from fastapi import FastAPI, HTTPException, Depends, status, Query
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator
from typing import Any, Dict, List, Literal, Optional, Tuple, Union, TypeVar, Generic
from datetime import date, datetime
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, DECIMAL, ForeignKey, Boolean
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.sql import func
import base64, hashlib, secrets
from datetime import datetime, timedelta
import json
from sqlalchemy import UniqueConstraint, text, bindparam
from sqlalchemy import Column
from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T")

class ResponseBase(BaseModel, Generic[T]):
    status: Union[int, Literal["success","error"]]
    message: Optional[str] = None
    data: Optional[T] = None

# class AppendixBase(BaseModel):
#     regulation_id: int | None = None
#     code: str | None = None
#     title: str | None = None
#     article_id: int | None = None
#     description: str | None = None
#     status: Optional[int] = 1

# class AppendixCreate(AppendixBase): pass
# class AppendixUpdate(AppendixBase): pass

# class AppendixOut(AppendixBase):
#     id: int
#     created_at: datetime | None = None
#     updated_at: datetime | None = None
#     model_config = ConfigDict(from_attributes=True)

# class AppendixChemicalBase(BaseModel):
#     appendix_id: int
#     chemical_id: int
#     status: Optional[int] = 1

# class AppendixChemicalCreate(AppendixChemicalBase): pass
# class AppendixChemicalUpdate(AppendixChemicalBase): pass

# class AppendixChemicalOut(AppendixChemicalBase):
#     id: int
#     created_at: datetime | None = None
#     updated_at: datetime | None = None
#     model_config = ConfigDict(from_attributes=True)
    
class MSDSChemicalBase(BaseModel):
    msds_id: int
    chemical_name: Optional[str] = None
    cas_no: Optional[str] = None
    percentage: Optional[float] = Field(None, ge=0, le=100)
    wtf: Optional[str] = None          # NEW
    role: Optional[str] = None
    status: Optional[int] = 1
    create_by: Optional[int] = None
    update_by: Optional[int] = None


class MSDSChemicalCreate(MSDSChemicalBase):
    pass

class MSDSChemicalUpdate(BaseModel):
    chemical_name: Optional[str] = None
    cas_no: Optional[str] = None
    percentage: Optional[float] = Field(None, ge=0, le=100)
    wtf: Optional[str] = None          # NEW
    role: Optional[str] = None
    status: Optional[int] = 1
    create_by: Optional[int] = None
    update_by: Optional[int] = None

class MSDSChemicalOut(BaseModel):
    id: int
    msds_id: int
    chemical_name: Optional[str]
    cas_no: Optional[str]
    percentage: Optional[float]
    wtf: Optional[str]                 # NEW
    role: Optional[str]
    status: Optional[int]
    created_at: datetime | None = None
    updated_at: datetime | None = None
    create_by: Optional[int] = None
    update_by: Optional[int] = None
    model_config = ConfigDict(from_attributes=True)

    

# class RegulationArticleBase(BaseModel):
#     regulation_id: int
#     article_id: int

class UserOut(BaseModel):
    id: int
    username: str
    email: EmailStr
    role: str
    status: int
    model_config = ConfigDict(from_attributes=True)

    

class RegisterIn(BaseModel):
    username: str = Field(min_length=3)
    email: EmailStr
    password: str = Field(min_length=6)
    role: str = Field(min_length=2)

class LoginIn(BaseModel):
    email: EmailStr
    password: str
    
class ErrorOut(BaseModel):
    status: str
    message: str


class TokenOut(BaseModel):
    status: str
    message: str
    token: Optional[str] = None
    expires_at: Optional[datetime] = None
    user: Optional[UserOut] = None
    model_config = ConfigDict(from_attributes=True)

    

class UploadedFileBase(BaseModel):
    file_name: Optional[str] = Field(None, max_length=255)
    file_path: Optional[str] = Field(None, max_length=255)
    status: Optional[int] = 1
    project_id: Optional[int] = None

class ProcessBase(BaseModel):
    msds_id: Optional[int] = None
    message: Optional[str] = Field(None, max_length=255)
    status: Optional[int] = 1


class MSDSBase(BaseModel):
    product_name: Optional[str] = Field(None, max_length=255)
    msds_no: Optional[str] = Field(None, max_length=100)
    manufacturer_name: Optional[str] = Field(None, max_length=255)
    manufacturer_address: Optional[str] = Field(None, max_length=500)
    manufacturer_phone: Optional[str] = Field(None, max_length=100)
    signal_word: Optional[str] = Field(None, max_length=100)
    hazard_statements: Optional[str] = None
    precautionary_statements_text: Optional[str] = None
    ghs_symbols_text: Optional[str] = None
    composition_info: Optional[str] = None
    ingredient_percentage: Optional[str] = Field(None, max_length=255)
    first_aid_measures: Optional[str] = None
    fire_fighting_measures: Optional[str] = None
    accidental_release_measures: Optional[str] = None
    handling_storage: Optional[str] = None
    exposure_control: Optional[str] = None
    physical_chemical_properties: Optional[str] = None
    stability_reactivity: Optional[str] = None
    toxicological_info: Optional[str] = None
    ecological_info: Optional[str] = None
    disposal_considerations: Optional[str] = None
    transport_info: Optional[str] = None
    regulatory_info: Optional[str] = None
    other_info: Optional[str] = None
    status: Optional[int] = 1
    project_id: Optional[int] = None

# class ArticleBase(BaseModel):
#     regulation_id: int
#     article_number: Optional[int] = None
#     article_title: Optional[str] = Field(None, max_length=255)
#     article_content: Optional[str] = None
#     status: Optional[int] = 1


class ProjectCreate(BaseModel):
    project_name: str
    vector_store_id: Optional[str] = None  # NEW
    description: Optional[str] = None
    vector_store_id: Optional[str] = None
    user_id: Optional[int] = None
    status: Optional[int] = 1

class ProjectUpdate(BaseModel):
    project_name: Optional[str] = None
    vector_store_id: Optional[str] = None  # NEW
    description: Optional[str] = None
    vector_store_id: Optional[str] = None
    user_id: Optional[int] = None
    status: Optional[int] = None

class ProjectOut(BaseModel):
    id: int
    project_name: str
    vector_store_id: Optional[str] = None  # NEW
    description: Optional[str] = None
    vector_store_id: Optional[str] = None
    user_id: Optional[int] = None
    status: int
    created_at: datetime
    updated_at: datetime
    model_config = ConfigDict(from_attributes=True)

    



    
 

class OutputUpdate(BaseModel):
    product_name: Optional[str] = None
    ghs_signal_word: Optional[str] = None
    ghs_hazard_statements: Optional[str] = None
    msds_id: Optional[int] = None
    total_pct: Optional[float] = None
    temperature_storage_at: Optional[str] = None
    warehouse_type: Optional[str] = None
    product_class: Optional[str] = None
    is_msds_vn_16_field: Optional[str] = None
    special_warnings_transportation: Optional[str] = None
    match_class_of_products: Optional[bool] = None
    physical_state: Optional[str] = None
    physicochemical_properties: Optional[str] = None
    toxicity: Optional[str] = None
    status: Optional[bool] = None


class OutputResponse(BaseModel):
    id: int
    project_id: int
    product_name: Optional[str] = None
    ghs_signal_word: Optional[str] = None
    ghs_hazard_statements: Optional[str] = None
    msds_id: Optional[int] = None
    total_pct: Optional[float] = None
    temperature_storage_at: Optional[str] = None
    warehouse_type: Optional[str] = None
    product_class: Optional[str] = None
    is_msds_vn_16_field: Optional[str] = None
    special_warnings_transportation: Optional[str] = None
    match_class_of_products: Optional[bool] = None
    physical_state: Optional[str] = None
    physicochemical_properties: Optional[str] = None
    toxicity: Optional[str] = None
    status: bool
    created_at: datetime
    updated_at: datetime
    model_config = ConfigDict(from_attributes=True)

class BaseSchema(BaseModel):
    status: Optional[int] = 1
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)

    

class UserBase(BaseModel):
    username: str = Field(..., max_length=255)
    email: EmailStr = Field(..., max_length=255)
    role: Optional[str] = None
    status: Optional[int] = 1


class ChemicalBase(BaseModel):
    chemical_name: str = Field(..., max_length=255)
    chemical_name_vn: Optional[str] = Field(None, max_length=255)
    cas_no: str = Field(..., max_length=50)
    molecular_formula: Optional[str] = Field(None, max_length=255)
    molecular_weight: Optional[float] = None
    chemical_class: Optional[str] = Field(None, max_length=255)
    hs_code: Optional[str] = Field(None, max_length=50)
    hazard_classification: Optional[str] = None
    safety_precautions: Optional[str] = None
    storage_conditions: Optional[str] = None
    disposal_instructions: Optional[str] = None
    regulatory_info: Optional[str] = None
    status: Optional[int] = 1


class GHSClassificationBase(BaseModel):
    hazard_class: str = Field(..., max_length=255)
    code: Optional[str] = Field(None, max_length=64)
    image_url: Optional[str] = Field(None, max_length=255)
    description: Optional[str] = None


# class RegulationBase(BaseModel):
#     regulation_title: str = Field(..., max_length=255)
#     regulation_description: Optional[str] = None
#     legal_reference: Optional[str] = Field(None, max_length=255)
#     applicable_laws: Optional[str] = None
#     status: Optional[int] = 1

class ChemicalIn(BaseModel):
    chemical_name: Optional[str] = None
    cas_number: Optional[str] = None
    percentage: Optional[float] = Field(None, ge=0, le=100)
    wtf: Optional[str] = None          # NEW
    role: Optional[str] = None


class MsdsIn(BaseModel):
    product_name: Optional[str] = None
    msds_no: Optional[str] = None
    manufacturer_name: Optional[str] = None
    manufacturer_address: Optional[str] = None
    manufacturer_phone: Optional[str] = None
    signal_word: Optional[str] = None
    hazard_statements: Optional[str] = None
    precautionary_statements_text: Optional[str] = None
    ghs_symbols_text: Optional[str] = None
    composition_info: Optional[str] = None
    ingredient_percentage: Optional[str] = None
    first_aid_measures: Optional[str] = None
    fire_fighting_measures: Optional[str] = None
    accidental_release_measures: Optional[str] = None
    handling_storage: Optional[str] = None
    exposure_control: Optional[str] = None
    physical_chemical_properties: Optional[str] = None
    stability_reactivity: Optional[str] = None
    toxicological_info: Optional[str] = None
    ecological_info: Optional[str] = None
    disposal_considerations: Optional[str] = None
    transport_info: Optional[str] = None
    regulatory_info: Optional[str] = None
    other_info: Optional[str] = None
    status: Optional[int] = 1
    project_id: int
    chemical: List[ChemicalIn] = []

class MsdsCreateResult(BaseModel):
    msds_id: int
    project_id: int
    linked_chemicals: int

class ExtractedChemical(BaseModel):
    chemical_name: str = Field(..., description="Tên thành phần/hoá chất")
    cas_number: Optional[str] = Field(None, description="CAS No nếu có")
    percentage: Optional[float] = Field(None, description="Tỉ lệ phần trăm số")

class MsdsExtract(BaseModel):
    product_name: Optional[str] = None
    msds_no: Optional[str] = None
    manufacturer_name: Optional[str] = None
    manufacturer_address: Optional[str] = None
    manufacturer_phone: Optional[str] = None
    signal_word: Optional[str] = None
    hazard_statements: Optional[str] = None
    precautionary_statements_text: Optional[str] = None
    ghs_symbols_text: Optional[str] = None
    composition_info: Optional[str] = None
    ingredient_percentage: Optional[str] = None
    first_aid_measures: Optional[str] = None
    fire_fighting_measures: Optional[str] = None
    accidental_release_measures: Optional[str] = None
    handling_storage: Optional[str] = None
    exposure_control: Optional[str] = None
    physical_chemical_properties: Optional[str] = None
    stability_reactivity: Optional[str] = None
    toxicological_info: Optional[str] = None
    ecological_info: Optional[str] = None
    disposal_considerations: Optional[str] = None
    transport_info: Optional[str] = None
    regulatory_info: Optional[str] = None
    other_info: Optional[str] = None
    status: Optional[int] = 1
    project_id: Optional[int] = None
    chemical: List[ExtractedChemical] = []

class UploadedFileCreate(UploadedFileBase):
    pass

class UploadedFileResponse(UploadedFileBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)


class UserCreate(UserBase):
    password: str = Field(..., min_length=6)
    
    @field_validator('username')
    @classmethod
    def validate_username(cls, v: str) -> str:
        if len(v) < 3:
            raise ValueError("Username phải có ít nhất 3 ký tự")
        if not v[0].isalpha():
            raise ValueError("Username phải bắt đầu bằng chữ cái (a-z hoặc A-Z)")
        # if not all(c.isalnum() or c == '_' for c in v):
        #     raise ValueError("Username chỉ được chứa chữ cái, số và dấu gạch dưới (_)")
        return v

    @field_validator('password')
    @classmethod
    def validate_password(cls, v: str) -> str:
        if not any(c.isdigit() for c in v):
            raise ValueError("Mật khẩu phải chứa ít nhất một chữ số")
        return v

class UserUpdate(UserBase):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    role: Optional[str] = None
    status: Optional[int] = None
    password: Optional[str] = None
    
    @field_validator('username')
    @classmethod
    def validate_username(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            if len(v) < 3:
                raise ValueError("Username phải có ít nhất 3 ký tự")
            if not v[0].isalpha():
                raise ValueError("Username phải bắt đầu bằng chữ cái (a-z hoặc A-Z)")
            # if not all(c.isalnum() or c == '_' for c in v):
            #     raise ValueError("Username chỉ được chứa chữ cái, số và dấu gạch dưới (_)")
        return v

    @field_validator('password')
    @classmethod
    def validate_password(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            if len(v) < 6:
                raise ValueError("Mật khẩu phải có ít nhất 6 ký tự")
            if not any(c.isdigit() for c in v):
                raise ValueError("Mật khẩu phải chứa ít nhất một chữ số")
        return v

class UserResponse(UserBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    status: Union[int, Literal["success","error"]]

class DeleteResponse(BaseModel):
    status: str
    message: str

class ChemicalCreate(ChemicalBase):
    pass

class ChemicalUpdate(ChemicalBase):
    pass

class ChemicalResponse(ChemicalBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None



class GHSClassificationCreate(GHSClassificationBase):
    pass

class GHSClassificationResponse(GHSClassificationBase):
    id: int



# class RegulationCreate(RegulationBase):
#     pass

# class RegulationResponse(RegulationBase):
#     id: int
#     created_at: Optional[datetime] = None
#     updated_at: Optional[datetime] = None


# class ArticleCreate(ArticleBase):
#     pass

# class ArticleResponse(ArticleBase):
#     id: int
#     created_at: Optional[datetime] = None
#     updated_at: Optional[datetime] = None


class MSDSCreate(MSDSBase):
    pass

class MSDSUpdate(MSDSBase):
    pass

class MSDSResponse(MSDSBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)

     


class ProcessCreate(ProcessBase):
    pass

class ProcessResponse(ProcessBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


class UploadedFileCreate(UploadedFileBase):
    pass

# class UploadedFileResponse(UploadedFileBase):
#     id: int
#     uploaded_at: Optional[datetime] = None
class UploadedFileResponse(BaseModel):
    id: int
    file_name: str | None = None
    file_path: str | None = None
    status: Optional[int] = 1
    uploaded_at: datetime | None = Field(default=None, alias="created_at")  # map từ model.created_at
    updated_at: datetime | None = None
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

class MsdsUpdateIn(BaseModel):
    product_name: Optional[str] = None
    msds_no: Optional[str] = None
    manufacturer_name: Optional[str] = None
    manufacturer_address: Optional[str] = None
    manufacturer_phone: Optional[str] = None
    signal_word: Optional[str] = None
    hazard_statements: Optional[str] = None
    precautionary_statements_text: Optional[str] = None
    ghs_symbols_text: Optional[str] = None
    composition_info: Optional[str] = None
    ingredient_percentage: Optional[str] = None
    first_aid_measures: Optional[str] = None
    fire_fighting_measures: Optional[str] = None
    accidental_release_measures: Optional[str] = None
    handling_storage: Optional[str] = None
    exposure_controls: Optional[str] = None  # map sang exposure_control khi dùng
    physical_chemical_properties: Optional[str] = None
    stability_reactivity: Optional[str] = None
    toxicological_info: Optional[str] = None
    ecological_info: Optional[str] = None
    disposal_considerations: Optional[str] = None
    transport_info: Optional[str] = None
    regulatory_info: Optional[str] = None
    other_info: Optional[str] = None
    status: Optional[int] = None
    project_id: Optional[int] = None

class ArticleCreateIn(BaseModel):
    regulation_id: Optional[int] = None
    article_number: Optional[int] = None
    article_title: Optional[str] = Field(None, max_length=255)
    article_content: Optional[str] = None
    status: Optional[int] = 1


class ProcessCreate(BaseModel):
    msds_id: int
    status: Optional[int] = None
    message: Optional[str] = None


class ProcessResponse(BaseModel):
    id: int
    msds_id: int
    status: Optional[int] = None
    message: Optional[str] = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    model_config = ConfigDict(from_attributes=True)

# class OutputPermitBase(BaseModel):
#     output_id: int
#     un_number: Optional[str] = None
#     match_chemical_name_core_component: Optional[int] = None
#     match_un_number: Optional[int] = None
#     status: Optional[int] = 1

# class OutputPermitCreate(OutputPermitBase): pass

# class OutputPermitUpdate(OutputPermitBase): pass

# class OutputPermitResponse(OutputPermitBase):
#     id: int
#     created_at: Optional[datetime] = None
#     updated_at: Optional[datetime] = None
#     model_config = ConfigDict(from_attributes=True)



class MsdsCasNoResponse(BaseModel):
    MSDS: Dict[str, List[str]]

class OutputFromAI(BaseModel):
    project_id: int
    msds_id: int
    product_name: Optional[str] = None
    ghs_signal_word: Optional[str] = None
    ghs_hazard_statements: Optional[str] = None
    total_pct: Optional[float] = None
    temperature_storage_at: Optional[str] = None
    warehouse_type: Optional[str] = None
    product_class: Optional[str] = None
    is_msds_vn_16_field: Optional[str] = None
    special_warnings_transportation: Optional[str] = None
    match_class_of_products: Optional[bool] = None
    physical_state: Optional[str] = None
    physicochemical_properties: Optional[str] = None
    toxicity: Optional[str] = None
    status: Optional[bool] = True


class OutputCreate(BaseModel):
    project_id: int
    msds_id: int


# Schema cho API mock project với MSDS
class ChemicalSubstance(BaseModel):
    id: str
    casNumber: str
    composition: str
    ghs: str
    dangerousChemicalInfo: str
    appendix01: bool
    appendix02: bool
    appendix03: bool
    appendix04: bool
    appendix05: bool
    isIndustrialPrecursor: bool
    noLicense: bool
    hasConditionalLicense: bool
    hasRestrictedLicense: bool
    hasTableChemical: bool

class ChemicalProduct(BaseModel):
    id: str

    productName: str
    group: str
    storage: str
    storageType: str
    temperature: str
    note: str
    substances: List[ChemicalSubstance]

class ProjectWithMSDS(BaseModel):
    id: str
    name: str
    creator: str
    createdAt: str
    msds: List[ChemicalProduct]

class MsdsDataForAI(BaseModel):
    msds_id: int
    project_id: int
    product_name: Optional[str] = None
    msds_no: Optional[str] = None
    manufacturer_name: Optional[str] = None
    chemicals: List[Dict[str, Any]] 

class CasExtractResp(BaseModel):
    ProductName: Optional[str] = None
    CasNoList: List[str]

class ChemicalMappingBase(BaseModel):
    chemical_id: int
    code: str
    title: str
    content: Optional[str] = None
    regulation: Optional[str] = None
    note: Optional[str] = Field(default=None, max_length=512)
    law_text: Optional[str] = None
    status: Optional[int] = 1

class ChemicalMappingCreate(ChemicalMappingBase):
    chemical_id: Optional[int] = None

class ChemicalMappingUpdate(BaseModel):
    chemical_id: Optional[int] = None
    code: Optional[str] = None
    title: Optional[str] = None
    content: Optional[str] = None
    regulation: Optional[str] = None
    note: Optional[str] = Field(default=None, max_length=512)
    law_text: Optional[str] = None
    status: Optional[int] = None


class ChemicalMappingInDBBase(ChemicalMappingBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)

      # pydantic v2

class ChemicalMapping(ChemicalMappingInDBBase):
    pass

class ChemicalMappingList(BaseModel):
    total: int
    items: list[ChemicalMapping]


class NoteItem(BaseModel):
    code: str
    title: str
    note: str | None = None
    regulation: str | None = None
    law_text: str | None = None
    content: str | None = None

class NotesByCASResponse(BaseModel):
    cas_no: str
    chemical_name: str | None = None
    hs_code: str | None = None
    total_notes: int
    notes: List[NoteItem]

class NotesByCASSummary(BaseModel):
    cas_no: str
    chemical_name: Optional[str] = None
    hs_code: Optional[str] = None
    notes_summary: str | None = None


class AppendixBase(BaseModel):
    title: str = Field(...)
    content: Optional[str] = None
    regulation: Optional[str] = None
    note: Optional[str] = None
    law_text: Optional[str] = None
    status: Optional[int] = 1
    regulation_id: Optional[int] = None
    regulation_code: Optional[str] = None  # compat: allow resolving by code

class AppendixCreate(BaseModel):
    title: str
    content: Optional[str] = None
    regulation_text: Optional[str] = None   # text ghi chú ngắn nếu DB có cột này
    note: Optional[str] = None
    law_text: Optional[str] = None
    status: Optional[int] = 1
    regulation_id: int                 # FK bắt buộc hoặc dùng regulation_code


class AppendixUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    regulation_text: Optional[str] = None
    note: Optional[str] = None
    law_text: Optional[str] = None
    status: Optional[int] = None
    regulation_id: Optional[int] = None
 

class AppendixOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    content: Optional[str] = None
    regulation_text: Optional[str] = None
    note: Optional[str] = None
    law_text: Optional[str] = None
    status: Optional[int] = 1
    regulation_id: int


class ChemicalMappingIn(BaseModel):
    chemical_id: Optional[int] = None
    cas_no: Optional[str] = None
    appendix_id: Optional[int] = None
    status: Optional[int] = 1
    code: str = Field(..., max_length=255)
    title: Optional[str] = None

class ChemicalMappingUpdateIn(BaseModel):
    status: Optional[int] = None
    chemical_id: Optional[int] = None
    cas_no: Optional[str] = None
    appendix_id: Optional[int] = None
    code: str = Field(..., max_length=255)
    title: Optional[str] = None

class ChemicalMappingOut(BaseModel):
    id: int
    chemical_id: Optional[int]
    appendix_id: Optional[int]
    status: int
    code: str
    title: Optional[str]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None



class RegulationAppendixIn(BaseModel):
    code: str = Field(..., max_length=255)
    title: str = Field(..., max_length=255)
    content: Optional[str] = None
    regulation: Optional[str] = None
    note: Optional[str] = None
    law_text: Optional[str] = None
    status: Optional[int] = 1

class RegulationAppendixOut(RegulationAppendixIn):
    id: int
    model_config = ConfigDict(from_attributes=True)

class AppendixIn(BaseModel):
    code: str
    title: str
    regulation_id: int
# class CasItem(BaseModel):
#     casNo: str

class ProductCASRequest(BaseModel):
    ProductName: Optional[str] = None
    CasNoList: List[str]

class BatchNotesItem(BaseModel):
    cas_no: str
    chemical_name: Optional[str] = None
    chemical_name_vn: Optional[str] = None
    hs_code: Optional[str] = None
    notes_summary: str

class ProductCASResponse(BaseModel):
    ProductName: Optional[str] = None
    items: List[BatchNotesItem]

class ChemicalInfo(BaseModel):
    id: int
    chemical_name: str
    chemical_name_vn: Optional[str] = None
    cas_no: str
    molecular_formula: Optional[str] = None
    molecular_weight: Optional[float] = None
    chemical_class: Optional[str] = None
    hs_code: Optional[str] = None
    
    model_config = ConfigDict(from_attributes=True)

class RegAppendixWithChemicalsOut(BaseModel):
    id: int
    code: str
    title: str
    content: Optional[str] = None
    regulation: Optional[str] = None
    note: Optional[str] = None
    law_text: Optional[str] = None
    status: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    chemicals: List[ChemicalInfo] = []
    
    model_config = ConfigDict(from_attributes=True)




class ChemicalBrief(BaseModel):
    id: int
    chemical_name: Optional[str] = None
    chemical_name_vn: Optional[str] = None
    cas_no: Optional[str] = None
    hs_code: Optional[str] = None
    molecular_formula: Optional[str] = None
    note: Optional[str] = None
    law_text: Optional[str] = None
    codes: Optional[List[str]] = None  # khi không truyền code, trả danh sách code liên quan

class PaginatedChemicals(BaseModel):
    meta: dict
    items: List[ChemicalBrief]

# Item phẳng cho API /api/regapp/regapp/ theo yêu cầu
class RegappChemicalItem(BaseModel):
    chemical_name: Optional[str] = None
    chemical_name_vn: Optional[str] = None
    cas_no: Optional[str] = None
    hs_code: Optional[str] = None
    molecular_formula: Optional[str] = None
    note: Optional[str] = None
    law_text: Optional[str] = None


class CasEntry(BaseModel):
    CasNumber: str 
    CasName: str | None = None
    Wt: str | None = None
class BatchItem(BaseModel):
    ProductName: Optional[str] = None
    CasNoList: list[CasEntry]
    # CasNoList: List[str] = Field(default_factory=list)

class ProjectBatchCasIn(BaseModel):
    ProjectId: int
    Results: List[BatchItem]

class ChemicalNote(BaseModel):
    chemical_name: Optional[str] = None   # NEW
    wt: Optional[str] = None              # NEW
    cas_no: str
    hs_code: Optional[str] = None
    regulations: List[Dict[str, Any]] = Field(default_factory=list)  # [{appendix, title, note, law_text, regulation}]
    

class ProductNotes(BaseModel):
    product_name: Optional[str]
    msds_id: int
    notes_summary: List[ChemicalNote]

class ProductNotesShow(BaseModel):
    product_name: Optional[str]
    notes_summary: List[ChemicalNote]

class ProjectBatchCasOut(BaseModel):
    project_id: int
    items: List[ProductNotes]
    
class SecondExtractElementIn(BaseModel):
    cas_no: str
    chemical_name: Optional[str] = None
    wtf: Optional[str] = None
    dangerous_chemical: Optional[bool] = None
    pl1: Optional[str] = None
    pl2: Optional[str] = None
    pl3: Optional[str] = None
    pl4: Optional[str] = None
    pl5: Optional[str] = None
    no_license: Optional[bool] = None
    drug_precursors: Optional[str] = None  # Đổi từ bool thành str
    table_chemicals: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[bool] = None
    create_by: Optional[int] = None
    update_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class SecondExtractPermitIn(BaseModel):
    un_number: Optional[str] = None
    match_chemical_name_core_component: Optional[bool] = None  # Change to bool
    match_un_number: Optional[bool] = None  # Change to bool
    license_number: Optional[str] = None
    license_plate_number: Optional[str] = None
    expiration_date: Optional[date] = None
    route_allowed: Optional[str] = None
    status: Optional[int] = 1
    created_at: datetime | None = None
    updated_at: datetime | None = None
    create_by: Optional[int] = None
    update_by: Optional[int] = None

class SecondExtractIn(BaseModel):
    # bắt buộc
    project_id: int

    # tuỳ chọn - map 1:1 với table `output`
    ghs_signal_word: Optional[str] = None
    ghs_hazard_statements: Optional[str] = None
    msds_id: Optional[int] = None
    total_pct: Optional[float] = None
    temperature_storage_at: Optional[str] = None
    warehouse_type: Optional[str] = None
    pl1: Optional[int] = None
    pl2: Optional[int] = None
    pl3: Optional[int] = None
    pl4: Optional[int] = None
    pl5: Optional[int] = None
    no_license: Optional[int] = None
    conditional_license: Optional[int] = None
    restricted_license: Optional[int] = None
    dangerous_chemicals: Optional[int] = None
    drug_potential_industry: Optional[int] = None
    notes: Optional[str] = None
    product_class_number: Optional[str] = None
    is_msds_vn_16_field: Optional[str] = None
    special_warnings_transportation: Optional[str] = None
    match_class_of_products: Optional[bool] = None
    physical_state: Optional[str] = None
    physicochemical_properties: Optional[str] = None
    toxicity: Optional[str] = None
    status: Optional[bool] = True
    created_at: datetime | None = None  # ISO-8601, optional
    updated_at: datetime | None = None
    create_by: Optional[int] = None
    update_by: Optional[int] = None
    product_name: Optional[str] = None

    # danh sách permits
    permits: List[SecondExtractPermitIn] = []
    # danh sách elements
    elements: List[SecondExtractElementIn] = []  

class OutputPermitOut(BaseModel):
    id: int
    output_id: int
    un_number: Optional[str] = None
    match_chemical_name_core_component: Optional[bool] = None
    match_un_number: Optional[bool] = None
    license_number: Optional[str] = None
    license_plate_number: Optional[str] = None
    expiration_date: Optional[date] = None
    route_allowed: Optional[str] = None
    status: Optional[bool] = None
    create_by: Optional[int] = None
    update_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)

class OutputPermitUpdate(BaseModel):
    un_number: Optional[str] = None
    match_chemical_name_core_component: Optional[bool] = None
    match_un_number: Optional[bool] = None
    license_number: Optional[str] = None
    license_plate_number: Optional[str] = None
    expiration_date: Optional[date] = None
    route_allowed: Optional[str] = None
    status: Optional[bool] = None
    update_by: Optional[int] = None
    model_config = ConfigDict(extra="allow", from_attributes=True) 


class OutputPermitIn(BaseModel):
    output_id: int
    un_number: Optional[str] = None
    match_chemical_name_core_component: Optional[bool] = None
    match_un_number: Optional[bool] = None
    license_number: Optional[str] = None
    license_plate_number: Optional[str] = None
    expiration_date: Optional[date] = None
    route_allowed: Optional[str] = None
    status: Optional[bool] = True



class OutputElementOut(BaseModel):
    id: int
    output_id: int
    cas_no: str
    chemical_name: Optional[str] = None
    wtf: Optional[str] = None
    dangerous_chemical: Optional[bool] = None
    pl1: Optional[str] = None
    pl2: Optional[str] = None
    pl3: Optional[str] = None
    pl4: Optional[str] = None
    pl5: Optional[str] = None
    no_license: Optional[bool] = None
    drug_precursors: Optional[str] = None  # Đổi từ bool thành str
    table_chemicals: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[bool] = None
    create_by: Optional[int] = None
    update_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)

class OutputFullOut(BaseModel):
    id: int
    project_id: int
    product_name: Optional[str] = None
    ghs_signal_word: Optional[str] = None
    ghs_hazard_statements: Optional[str] = None
    msds_id: Optional[int] = None
    total_pct: Optional[float] = None
    temperature_storage_at: Optional[str] = None
    warehouse_type: Optional[str] = None
    product_class: Optional[str] = None
    is_msds_vn_16_field: Optional[str] = None
    special_warnings_transportation: Optional[str] = None
    match_class_of_products: Optional[bool] = None
    physical_state: Optional[str] = None
    physicochemical_properties: Optional[str] = None
    toxicity: Optional[str] = None
    status: Optional[bool] = None
    create_by: Optional[int] = None
    update_by: Optional[int] = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    
    # Sử dụng alias để mapping từ tên trường trong model (viết thường) sang response (viết hoa)
    Permits: List[OutputPermitOut] = Field(..., alias="permits")
    Elements: List[OutputElementOut] = Field(..., alias="elements")
    
    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True  # Cho phép populate bằng cả tên trường và alias
    )

class SecondExtractSavedOut(BaseModel):
    
    output: OutputFullOut             
    # permits: List[OutputPermitOut]

class SecondExtractBatchIn(BaseModel):
    items: List[SecondExtractIn]

class OutputElementIn(BaseModel):
    output_id: int
    cas_no: str = Field(..., max_length=64)
    chemical_name: Optional[str] = None
    wtf: Optional[str] = None
    dangerous_chemical: Optional[bool] = False
    pl1: Optional[str] = None
    pl2: Optional[str] = None
    pl3: Optional[str] = None
    pl4: Optional[str] = None
    pl5: Optional[str] = None
    no_license: Optional[bool] = False
    drug_precursors: Optional[str] = None  # Đổi từ bool thành str
    table_chemicals: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[bool] = True
    conditional_license: Optional[int] = 0  # Added
    restricted_chemical_license: Optional[int] = 0  # Added
    model_config = ConfigDict(from_attributes=True)

class OutputElementUpdate(BaseModel):
    output_id: Optional[int] = None
    cas_no: Optional[str] = None
    chemical_name: Optional[str] = None
    wtf: Optional[str] = None
    dangerous_chemical: Optional[bool] = None
    pl1: Optional[str] = None
    pl2: Optional[str] = None
    pl3: Optional[str] = None
    pl4: Optional[str] = None
    pl5: Optional[str] = None
    no_license: Optional[bool] = None
    drug_precursors: Optional[str] = None  # Đổi từ bool thành str
    table_chemicals: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[bool] = None
    update_by: Optional[int] = None
    conditional_license: Optional[int] = None  # Added
    restricted_chemical_license: Optional[int] = None  # Added
    model_config = ConfigDict(from_attributes=True)
    
class OutputElementOut(OutputElementIn):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True)



class OutputOut(BaseModel):
    id: int
    project_id: int
    product_name: Optional[str] = None
    ghs_signal_word: Optional[str] = None
    ghs_hazard_statements: Optional[str] = None
    msds_id: Optional[int] = None
    total_pct: Optional[float] = None
    temperature_storage_at: Optional[str] = None
    warehouse_type: Optional[str] = None
    product_class: Optional[str] = None
    is_msds_vn_16_field: Optional[str] = None
    special_warnings_transportation: Optional[str] = None
    match_class_of_products: Optional[bool] = None
    physical_state: Optional[str] = None
    physicochemical_properties: Optional[str] = None
    toxicity: Optional[str] = None
    status: int
    created_at: datetime
    updated_at: datetime
    permits: List[OutputPermitOut] = []
    elements: List[OutputElementOut] = []  # Thêm dòng này để bao gồm elements
    model_config = ConfigDict(from_attributes=True)


class RegAppUpdate(BaseModel):
    code: Optional[str] = None
    title: Optional[str] = None
    content: Optional[str] = None
    law_text: Optional[str] = None
    note: Optional[str] = None
    status: Optional[int] = None
    model_config = ConfigDict(extra="ignore")


class MSDSChemicalRead(BaseModel):
    id: int
    msds_id: int
    chemical_name: Optional[str] = None
    cas_no: Optional[str] = None
    percentage: Optional[float] = Field(None, ge=0, le=100)
    wtf: Optional[str] = None          # NEW
    role: Optional[str] = None
    status: Optional[int] = 1
    create_by: Optional[int] = None
    update_by: Optional[int] = None
    model_config = ConfigDict(from_attributes=True)


class MSDSRead(MSDSBase):
    id: int
    project_id: int
    # product_name: Optional[str] = None
    msds_chemicals: List[MSDSChemicalRead] = []
    model_config = ConfigDict(from_attributes=True)

class CasListItem(BaseModel):
    CasNo: str = Field(..., description="CAS number")
    ChemicalName: str = Field(..., description="Chemical name")
    WtPercent: str = Field(..., description="Weight percent (as string)")
    DangerousChemical: bool = Field(..., description="Is dangerous chemical")
    PL1: str = Field(..., description="PL1 details")
    PL2: str = Field(..., description="PL2 details")
    PL3: str = Field(..., description="PL3 details")
    PL4: str = Field(..., description="PL4 details")
    PL5: str = Field(..., description="PL5 details")
    NoLicense: bool = Field(..., description="No license required")
    ConditionalLicense: bool = Field(..., description="Conditional license")
    RestrictedLicense: bool = Field(..., description="Restricted license")
    IndustrialPrecursor: bool = Field(..., description="Industrial precursor")
    DrugPrecursor: str = Field(..., description="Drug precursor details")  # Đổi từ bool thành str
    ScheduledChemical: str = Field(..., description="Scheduled chemical details")
    Note: str = Field(..., description="Additional notes")
    MatchIngredientName: bool = Field(..., description="Match ingredient name")
    MatchUNNumber: bool = Field(..., description="Match UN number")
    LicenseNumber: str = Field(..., description="License number")
    VehiclePlate: str = Field(..., description="Vehicle plate number")
    ExpirationDate: str = Field(..., description="Expiration date in YYYY-MM-DD format")
    UNNumber: str = Field(..., description="UN number")

class ElementItemIn(BaseModel):
    CasNo: str
    ChemicalName: Optional[str] = None
    WtPercent: str
    PL1: Optional[str] = None
    PL2: Optional[str] = None
    PL3: Optional[str] = None
    PL4: Optional[str] = None
    PL5: Optional[str] = None
    ConditionalChemicalCertificate: bool
    RestrictedChemicalLicense: bool
    NoLicense: bool
    DrugPrecursor: Optional[str] = None  # Đổi từ bool thành str
    ScheduledChemical: Optional[str] = None
    Note: Optional[str] = None

class ElementItemOut(BaseModel):
    CasNo: str
    ChemicalName: Optional[str] = None
    WtPercent: str
    PL1: Optional[str] = None
    PL2: Optional[str] = None
    PL3: Optional[str] = None
    PL4: Optional[str] = None
    PL5: Optional[str] = None
    ConditionalChemicalCertificate: bool
    RestrictedChemicalLicense: bool
    NoLicense: bool
    DrugPrecursor: Optional[str] = None  # Đổi từ bool thành str
    ScheduledChemical: Optional[str] = None
    Note: Optional[str] = None


class PermitItemOut(BaseModel):
    MatchIngredientName: bool
    MatchUNNumber: bool
    LicenseNumber: Optional[str] = None
    VehiclePlate: Optional[str] = None
    ExpirationDate: Optional[str] = None  # String for output
    PermittedRoute: Optional[str] = None

class PermitItemIn(BaseModel):
    MatchIngredientName: bool
    MatchUNNumber: bool
    LicenseNumber: Optional[str] = None
    VehiclePlate: Optional[str] = None
    ExpirationDate: Optional[str] = None  # String as per struct, parse in API
    PermittedRoute: Optional[str] = None   

class MockOutputElement(BaseModel):
    CasNo: str
    ChemicalName: Optional[str] = None
    WtPercent: str
    PL1: Optional[str] = None
    PL2: Optional[str] = None
    PL3: Optional[str] = None
    PL4: Optional[str] = None
    PL5: Optional[str] = None
    NoLicense: bool
    DrugPrecursor: Optional[str] = None  # Đã là string
    ScheduledChemical: Optional[str] = None
    Note: Optional[str] = None

class MockOutputPermit(BaseModel):
    MatchIngredientName: bool
    MatchUNNumber: bool
    LicenseNumber: Optional[str] = None
    VehiclePlate: Optional[str] = None
    ExpirationDate: Optional[str] = None
    PermittedRoute: Optional[str] = None

class MockOutputItem(BaseModel):
    ProductName: str
    GHS: str
    DangerousChemical: bool
    Element: List[MockOutputElement]
    Permit: List[MockOutputPermit]
    TotalWtPercent: float
    StorageTemperature: str
    StorageType: str
    ClassNumber: str
    Has16Section: str
    UNNumber: str
    SpecialNoteForTransport: str
    MatchClass: bool
    PhysicalState: str
    PhysicochemicalProperties: str
    Toxicity: str

class BatchOutputItemIn(BaseModel):
    ProductName: Optional[str] = None
    GHS: Optional[str] = None
    DangerousChemical: bool = False
    Element: List[ElementItemIn] = []
    Permit: List[PermitItemIn] = []
    TotalWtPercent: Optional[float] = None
    StorageTemperature: Optional[str] = None
    StorageType: Optional[str] = None
    ClassNumber: Optional[str] = None
    Has16Section: Optional[str] = None
    UNNumber: Optional[str] = None
    SpecialNoteForTransport: Optional[str] = None
    MatchClass: bool = False
    PhysicalState: Optional[str] = None
    PhysicochemicalProperties: Optional[str] = None
    Toxicity: Optional[str] = None

class BatchOutputItemOut(BaseModel):
    ProductName: Optional[str] = None
    GHS: Optional[str] = None
    DangerousChemical: bool
    Element: List[ElementItemOut] = []
    Permit: List[PermitItemOut] = []
    TotalWtPercent: Optional[float] = None
    StorageTemperature: Optional[str] = None
    StorageType: Optional[str] = None
    ClassNumber: Optional[str] = None
    Has16Section: Optional[str] = None
    UNNumber: Optional[str] = None
    SpecialNoteForTransport: Optional[str] = None
    MatchClass: bool
    PhysicalState: Optional[str] = None
    PhysicochemicalProperties: Optional[str] = None
    Toxicity: Optional[str] = None

class BatchOutputItem(BaseModel):
    # Các trường từ bảng output
    product_name: Optional[str] = None
    ghs_signal_word: Optional[str] = None
    ghs_hazard_statements: Optional[str] = None
    msds_id: Optional[int] = None
    total_pct: Optional[float] = None
    temperature_storage_at: Optional[str] = None
    warehouse_type: Optional[str] = None
    product_class: Optional[str] = None
    is_msds_vn_16_field: Optional[str] = None
    special_warnings_transportation: Optional[str] = None
    match_class_of_products: Optional[bool] = None
    physical_state: Optional[str] = None
    physicochemical_properties: Optional[str] = None
    toxicity: Optional[str] = None
    status: Optional[bool] = True
    
    # Danh sách permits và elements (VIẾT HOA như yêu cầu)
    Permits: List[OutputPermitIn] = []
    Elements: List[OutputElementIn] = []

BatchOutputCreateNew = List[BatchOutputItemIn]

class BatchOutputCreateNew(BaseModel):
    items: List[BatchOutputItem]

class BatchOutputCreate(BaseModel):
    items: List[BatchOutputItemIn]
    
class BatchOutputResponse(BaseModel):
    status: str
    message: str
    data: List[BatchOutputItemOut]






class LicenseBase(BaseModel):
    title: str
    content: Optional[str] = None
    description: Optional[str] = None
    status: int = 1
    created_by: Optional[int] = None
    updated_by: Optional[int] = None

class LicenseCreate(LicenseBase):
    pass

class LicenseUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    description: Optional[str] = None
    status: Optional[int] = None
    updated_by: Optional[int] = None

class LicenseOut(LicenseBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    class Config:
        from_attributes = True

class RegulationIn(BaseModel):
    code: str
    title: str
    note: Optional[str] = None
    law_text: Optional[str] = None

class RegulationOut(RegulationIn):
    id: int


