from app.models.models import Appendix
from app.schemas.schemas import AppendixOut


def to_out(a: Appendix) -> AppendixOut:
    reg = getattr(a, "regulation", None)  # alias joinload bên dưới
    return AppendixOut(
        id=a.id,
        title=a.title,
        content=getattr(a, "content", None),
        regulation_text=getattr(a, "regulation", None) if isinstance(getattr(a, "regulation", None), str) else getattr(a, "regulation_text", None),

        note=getattr(a, "note", None),
        law_text=getattr(a, "law_text", None),
        status=getattr(a, "status", None),
        regulation_id=reg.id if reg else None,
    )