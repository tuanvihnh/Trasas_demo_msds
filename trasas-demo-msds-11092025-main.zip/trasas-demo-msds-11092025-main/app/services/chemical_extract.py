import os
import json
import re
from typing import Dict, List

from dotenv import load_dotenv
from fastapi import  HTTPException
from sqlalchemy.orm import Session
from pathlib import Path

from openai import OpenAI

from app.models.models import Project  # Project có cột: id (str|int), vector_store_id (str|None)
from app.schemas.schemas import BatchOutputItemIn, ChemicalIn, MsdsCreateResult, MsdsIn, ProjectBatchCasIn
from app.services.extracts_service import handle_project_batch_notes_by_cas, project_id_cas_notes_preview
from app.services.log_service import save_log
from app.services.project_services import get_project_file_id
from app.utils.chemical_extract_utils import import_msds_from_results, uniq_keep_order
from app.utils.file_utils import merge_project_pdfs
from app.utils.response import not_found         # chuẩn Session dependency của bạn

# ============================== ENV & CLIENT ==============================
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY chưa được cấu hình")
client = OpenAI(api_key=OPENAI_API_KEY)

# ============================== CONSTANTS ==============================
CAS_REGEX = r"\b\d{1,7}-\d{2}-\d\b"
VS_PREFIX = "msds_project_"

PROMPT_EXTRACT_MSDS_FIRST = """
Bạn là chuyên gia phân tích Phiếu An toàn Hóa chất (SDS/MSDS). Input là file PDF/Doc gộp nhiều SDS.

Yêu cầu:
Trả về duy nhất 1 mảng JSON. Mỗi SDS là 1 object:
{
  "ProductName": string | null,
  "CasNoList": [
    { "CasNumber": string, "CasName": string, "Wt": string }
  ]
}

Quy tắc:
1. Phân tách SDS
- Tách theo dấu hiệu cấp cao: tiêu đề lớn (“SAFETY DATA SHEET”), Section 1 mới, block nhà cung cấp lặp lại, ngắt trang rõ ràng.
- Không tách bên trong Section 3.

2. ProductName
- Lấy từ tiêu đề hoặc Section 1.
- Chấp nhận các nhãn: “Product name”, “Trade name”, “Product identifier”...
- Không lấy tên chứa CAS hoặc trùng tên hóa chất Section 3.
- Nếu không chắc chắn → null.

3. CasNoList (chỉ trong Section 3)
- CasNumber: giữ nguyên, kể cả “Trade secret”, “Proprietary”, “N/A”.
- CasName: tên hóa chất cùng dòng.
- Wt: giá trị phần trăm hoặc mô tả nồng độ, giữ nguyên (ví dụ “10-20%”, “<5%”, “trace”).
- Lấy tất cả, bỏ trùng, theo thứ tự xuất hiện.
- Bỏ qua định danh ngoài Section 3 (EC, REACH, UN).

4. Chung
- Không tự tạo dữ liệu.
- Nếu thiếu → ProductName=null, CasNoList=[].
- Output phải là mảng JSON hợp lệ duy nhất.

Ví dụ:
Input có 2 SDS → Output:
[
  {
    "ProductName": "CHEMLOK 6250",
    "CasNoList": [
      {"CasNumber":"1330-20-7","CasName":"Xylene","Wt":"25%"},
      {"CasNumber":"101-68-8","CasName":"MDI","Wt":"20%"}
    ]
  },
  {
    "ProductName": "CHEMLOK® 6254",
    "CasNoList": [
      {"CasNumber":"108-88-3","CasName":"Toluene","Wt":"15-20%"}
    ]
  }
]
"""

PROMPT_EXTRACT_MSDS_OUTPUT_V2 = """
Bạn là chuyên gia phân tích Phiếu An toàn Hóa chất (SDS/MSDS). Input là PDF/Doc có thể gộp nhiều SDS và Thông tin phụ bổ sung (EXTRA_INFO) dùng làm ngữ cảnh tham chiếu.


Mục tiêu:
Trả về DUY NHẤT một mảng JSON. Mỗi SDS là một object đúng theo schema dưới đây.

Schema kết quả:
[
  {
    "ProductName": string | null,
    "GHS": string | null,
    "DangerousChemical": boolean,
    "Element": [
      {
        "CasNo": string,
        "ChemicalName": string | null,
        "WtPercent": string,
        "PL1": string,
        "PL2": string,
        "PL3": string,
        "PL4": string,
        "PL5": string,
        "ConditionalChemicalCertificate": boolean,
        "RestrictedChemicalLicense": boolean,
        "NoLicense": boolean,
        "DrugPrecursor": string | null,
        "ScheduledChemical": string | null,
        "Note": string | null
      }
    ]
    "Permit": [
      {
        "MatchIngredientName": boolean,
        "MatchUNNumber": boolean,
        "LicenseNumber": string | null,
        "VehiclePlate": string | null,
        "ExpirationDate": string | null,  
        "PermittedRoute": string | null
      }
    ],
    "TotalWtPercent": number | null,
    "StorageTemperature": string | null,
    "StorageType": string | null,
    "ClassNumber": string | null,
    "Has16Section": string | null,
    "UNNumber": string | null,    
    "SpecialNoteForTransport": string | null,
    "MatchClass": boolean,
    "PhysicalState": string | null, 
    "PhysicochemicalProperties": string | null, 
    "Toxicity": string | null
  }
]

Quy tắc phân tách tài liệu:
1) Chia tài liệu thành các SDS bằng dấu hiệu CẤP CAO:
   - Tiêu đề lớn “SAFETY DATA SHEET”/“MATERIAL SAFETY DATA SHEET”.
   - Block “Section 1 / 1. Identification / Product identification”.
   - Khối thông tin nhà sản xuất/cung cấp lặp lại ở đầu.
   - Ngắt trang/đổi layout rõ ràng.
2) KHÔNG tách theo các mục nội bộ như “Section 3”.

Quy tắc cho từng trường:

A. ProductName
- Lấy từ tiêu đề/đầu trang hoặc Section 1 (Identification).
- Chấp nhận nhãn: “Product name”, “Trade name”, “Product identifier”, …
- Không lấy tên chứa chuỗi CAS hoặc trùng với thành phần ở Section 3.
- Không chắc chắn → null.

B. GHS
- Lấy thông tin từ Section 2 (Hazard identification).
- Ưu tiên:
  * Signal word (ví dụ: "Danger", "Warning").
  * Hazard statements (các câu H hoặc đoạn mô tả nguy hại).
- Nếu có nhiều hazard statements thì nối bằng dấu chấm phẩy.
- Nếu không tìm thấy hoặc không rõ → null.
- Không suy đoán.

C. Element (CHỈ từ Section 3: Composition/Information on Ingredients)
- Dò bảng hoặc dòng có cặp {tên thành phần, CAS, %wt/nồng độ}.
- CasNo: giữ nguyên như tài liệu. Nếu “Trade secret/Proprietary/N/A/—/Not available” thì ghi đúng chuỗi đó.
- ChemicalName: tên hóa chất trên cùng dòng CAS.
- WtPercent: trả về dưới dạng string, giữ nguyên khoảng hoặc số như SDS ghi.
  * Ví dụ: "10-20%", "<5%", "25%", "trace".
  * Không chuyển đổi sang số trong Element.
- Nếu không có dữ liệu → null.
- DangerousChemical: đánh dấu TRUE nếu Section 2 nêu rõ đây là “Hazardous mixture/substance” hoặc thành phần có phân loại nguy hiểm rõ ràng (ví dụ có H-codes) trong phần thành phần. Nếu không đủ căn cứ → FALSE.
- Thứ tự Element theo đúng thứ tự xuất hiện. Loại bỏ trùng lặp theo (CasNo, ChemicalName, WtPercent).

D. TotalWtPercent
- Tính bằng cách lấy NGƯỠNG TRÊN từ WtPercent (nếu có khoảng hoặc dấu so sánh).
  * "10-20%" → dùng 20.
  * "<5%" hoặc "≤5%" → dùng 5.
  * ">5%" → dùng 5 (coi như tối thiểu).
  * "25%" → dùng 25.
  * "trace", "N/A" hoặc không số → bỏ qua.
- Cộng tất cả giá trị số lấy được → TotalWtPercent.
- Nếu không có số hợp lệ → null.

E. StorageTemperature, StorageType
- Xác định StorageType từ Section 7 (Handling and Storage).
  * Nếu mô tả có cụm “cool”, “well-ventilated”, “ambient”, “dry, cool place”, “store in a dry, cool and well-ventilated area” → StorageType = "Kho mát".
  * Nếu mô tả có cụm “refrigerated”, “cold”, “store below 16°C” → StorageType = "Kho lạnh".
  * Nếu mô tả có cụm “high temperature”, “keep above 35°C”, hoặc chỉ ghi lưu trữ thông thường → StorageType = "Kho thường".
- StorageTemperature được gán theo StorageType:
  * Kho mát → "16–35°C"
  * Kho lạnh → "<16°C"
  * Kho thường → ">35°C"
- Nếu không xác định được StorageType → cả StorageType và StorageTemperature đều = null.

F. ClassNumber
- Lấy từ Section 14 (Transport) nếu tài liệu nêu “Class”/“Hazard Class”. Nếu có nhiều hệ (ADR/IMDG/IATA), chọn ADR hoặc ghi chuỗi tổng hợp ngắn gọn.
- Không có → null.

G. Has16Section
- Kiểm tra cấu trúc 16 mục chuẩn SDS.
- Nếu đủ → "Yes (Ngôn ngữ)".
- Nếu thiếu → "No (Ngôn ngữ)".
- Ngôn ngữ dựa theo nội dung văn bản (ví dụ: "Tiếng Việt", "Tiếng Anh").
- Nếu không chắc ngôn ngữ → chỉ trả "Yes" hoặc "No".

H. UNNumber
- Lấy từ Section 14 (“UN number”, “UN No.”).Nếu gặp trường hợp có 4 cột, sẽ lấy của IMDG và IATA. Không có → Not Regulated.

I. SpecialNoteForTransport
- Lấy từ Section 14 (Transport information).
- Tìm các cụm liên quan đến “Special precautions” hoặc “Special precaution for user”.
- Nếu có → ghi nguyên văn hoặc tóm gọn ngắn gọn.

J. PL1, PL2, PL3, PL4, PL5, DrugPrecursor, ScheduledChemical
- Dữ liệu nguồn: duyệt EXTRA_INFO.items[matched].notes_summary theo CAS của từng Element. Với mỗi regulations[] xét các cặp {title, note}:
- Chỉ dựa trên `title`.
- Ánh xạ:
  * "Nghị định 113 - Phụ lục 1" → PL1 = note (nếu note trống → null)
  * "Nghị định 113 - Phụ lục 2" → PL2 = note (nếu note trống → null)
  * "Nghị định 113 - Phụ lục 3" → PL3 = note (…)
  * "Nghị định 113 - Phụ lục 4" → PL4 = note (…)
  * "Nghị định 113 - Phụ lục 5" → PL5 = note (…)
  * "Nghị định 57" hoặc "Nghị định 90" hoặc "Nghị định 113 - Phụ lục 1 - Tiền chất nhóm 1" hoặc "Nghị định 113 - Phụ lục 1 - Tiền chất nhóm 2"→ DrugPrecursor = note (nếu note trống → null)
  * "Nghị định 33 - Phụ lục 1" → ScheduledChemical = note (nếu note trống → null)
- Nếu không khớp bất kỳ mục nào ở trên → tất cả PL1–PL5 = null, ScheduledChemical = null, DrugPrecursor = false.
- Không suy luận từ `note` hoặc `law_text`. Chỉ xét `title`.

K. Note
Nguồn dữ liệu:
- Duyệt EXTRA_INFO.items[matched].notes_summary theo CAS khớp với từng Element.CasNo.
- Chỉ xét regulations[] có title khớp các mẫu ở mục J.
Quy tắc:
- Lấy tất cả regulations[].law_text còn nội dung (không rỗng sau khi trim).
- Giữ nguyên thứ tự xuất hiện.
- Ghép các law_text thành chuỗi nhiều dòng, mỗi law_text một dòng.
- Loại bỏ trùng lặp sau khi chuẩn hóa khoảng trắng.
- Nếu không có law_text hợp lệ → Note = null.

L. PhysicalState
Lấy từ Section 9:
- Lấy physical state.

M. PhysicochemicalProperties
Lấy từ Section 9:
- Odor, Appearance, Physical state, Flash point, Boiling range, pH, Freeze Point

N. Toxicity
- Lấy từ section 2 phần Hazard Statements nếu không có -> null

O. DangerousChemical
-Lấy từ section 2 signal word, nếu nguy hiểm thì là true ngược lại false

P. ConditionalChemicalCertificate, RestrictedChemicalLicense, NoLicense  (ĐÁNH GIÁ Ở CẤP ELEMENT DỰA TRÊN NOTE)
- Chỉ sử dụng nội dung trong hai phần luật được cung cấp (Điều 8 và Điều 14) và trạng thái PL1/PL2 của Element.
- Đầu vào mỗi Element: PL1, PL2 (TRUE nếu có nội dung sau ánh xạ), Note (chuỗi đã ghép từ regulations.law_text).

1) Nhận dạng Điều 8 từ Note
- isD8_from_note = TRUE nếu Note KHỚP ÍT NHẤT MỘT trong các mô tả sau của Điều 8:
  a) Cụm “Điều 8” hoặc “hóa chất có điều kiện”.
  b) Chứa nhóm phân loại thuộc Điều 8:
     - “Nguy hại vật chất” cấp 1, 2, 3 hoặc kiểu A/B/C/D
     - “Độc cấp tính” cấp 2 hoặc 3
     - “Tổn thương nghiêm trọng/kích ứng mắt” cấp 1 hoặc 2/2A
     - “Ăn mòn/kích ứng da” cấp 1 hoặc 2
     - “Tác nhân gây ung thư/đột biến tế bào mầm/độc tính sinh sản” cấp 2
     - “Nguy hại môi trường” cấp 1

2) Nhận dạng Điều 14 từ Note
- isD14_from_note = TRUE nếu Note KHỚP ÍT NHẤT MỘT trong các mô tả sau của Điều 14:
  a) Cụm “Điều 14” hoặc “hóa chất hạn chế”.
  b) Chứa nhóm phân loại thuộc Điều 14:
     - “Độc cấp tính” cấp 1
     - “Tác nhân gây ung thư” cấp 1A hoặc 1B
     - “Độc tính sinh sản” cấp 1A hoặc 1B
     - “Đột biến tế bào mầm” cấp 1A hoặc 1B

- Chuẩn hoá khớp: không phân biệt hoa thường; chấp nhận cách viết số mức “1/2/3/1A/1B”, ký hiệu rút gọn đúng nghĩa (Carc., Repr., Muta.), nhưng KHÔNG suy đoán ngoài các hạng đã liệt kê.
- Nếu Note trống hoặc không nêu rõ các hạng đúng theo trên → isD8_from_note = FALSE, isD14_from_note = FALSE.

3) Luật quyết định trường phép
- RestrictedChemicalLicense:  
  - TRUE nếu (PL2 == TRUE) và (isD14_from_note == TRUE).  
  - Nếu TRUE thì tự động đặt ConditionalChemicalCertificate = FALSE và NoLicense = FALSE.  

- ConditionalChemicalCertificate:  
  - Chỉ xét nếu RestrictedChemicalLicense == FALSE.  
  - TRUE nếu ((PL1 == TRUE) hoặc (PL2 == TRUE)) và (isD8_from_note == TRUE).  
  - Nếu TRUE thì NoLicense = FALSE.  

- NoLicense:  
  - Chỉ xét nếu cả RestrictedChemicalLicense == FALSE và ConditionalChemicalCertificate == FALSE.  
  - TRUE nếu:  
    - Element thuộc bất kỳ PL* nào nhưng không khớp Điều 8 và Điều 14, hoặc  
    - Element không thuộc bất kỳ PL* nào.

4) Ràng buộc
- Tuyệt đối không sử dụng nguồn khác ngoài Note và PL1/PL2.
- Đánh giá độc lập từng Element. Không lan kết quả giữa các Element.
- Nếu không xác định Element thuộc PL nào → xử như KHÔNG thuộc PL.

Các trường CHƯA ĐỦ DỮ LIỆU – PHẢI ĐỂ TRỐNG, KHÔNG SUY ĐOÁN:
- Ở trong CasList:
  * LicenseNumber, VehiclePlate, ExpirationDate, PermittedRoute → luôn null.
  * MatchIngredientName, MatchUNNumber → luôn FALSE.
- Ở cấp SDS:
  * MatchClass → luôn FALSE.

  
Nguyên tắc chung:
- Chỉ trích dẫn thông tin có trong SDS. KHÔNG tự tạo/suy đoán.
- Nếu thiếu dữ liệu → điền null cho chuỗi/ngày, FALSE cho boolean, và không thêm trường ngoài schema.
- Output phải là MẢNG JSON HỢP LỆ DUY NHẤT, không bao nội dung khác.

"""

# ============================== VECTOR STORE (REUSE) ==============================
def get_or_create_vector_store(project: Project, db: Session):
    """
    Reuse: nếu project.vector_store_id có sẵn thì trả về object stub với .id.
    Nếu chưa có: tạo vector store mới, lưu vào DB, commit và trả về.
    """
    if project.vector_store_id:
        class _VS:  # stub đơn giản để giữ .id
            def __init__(self, _id): self.id = _id
        return _VS(project.vector_store_id)

    # tạo mới
    vs = client.vector_stores.create(name=f"{VS_PREFIX}{project.id}")
    project.vector_store_id = vs.id
    db.add(project)
    db.commit()
    db.refresh(project)
    return vs

def upload_pdf_to_vector_store_and_log(project: Project, merged_path: str, db: Session):
    """
    Tạo OpenAI File -> lấy file_id -> attach vào Vector Store -> ghi log + map JSON.
    Trả về file_id.
    """
    vs = get_or_create_vector_store(project, db)

    # 1) Tạo OpenAI File để lấy file_id
    merged_path = str(merged_path)
    with open(merged_path, "rb") as f:
        ofile = client.files.create(file=f, purpose="assistants")
    file_id = ofile.id

    # 2) Gắn file vào Vector Store (đồng bộ ingest)
    client.vector_stores.files.create(vector_store_id=vs.id, file_id=file_id)

    # 3) Ghi log
    save_log(
        "upload",
        project.id,
        {
            "message": "Upload & attach vào vector store thành công",
            "file_id": file_id,
            "vector_store_id": vs.id,
            "pdf_path": merged_path,
            "basename": Path(merged_path).name,
        },
    )

    # 4) Lưu mapping cục bộ (tùy chọn)
    map_path = Path("logs/file_id_map.json")
    map_path.parent.mkdir(parents=True, exist_ok=True)
    data = json.loads(map_path.read_text("utf-8") if map_path.exists() else "{}")
    data[str(project.id)] = file_id
    map_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def vector_store_has_file(vs_id: str, target_basename: str) -> bool:
    # liệt kê file trong vector store
    page = client.vector_stores.files.list(vector_store_id=vs_id)
    for vs_file in page.data:
        # vs_file không có filename; cần lấy metadata của File gốc
        file_id = getattr(vs_file, "file_id", None) or getattr(vs_file, "id", None)
        if not file_id:
            continue
        try:
            meta = client.files.retrieve(file_id)
        except Exception:
            continue
        name = (
            getattr(meta, "filename", None)
            or getattr(meta, "display_name", None)
            or getattr(meta, "name", None)
        )
        if name and name.endswith(target_basename):
            return True
    return False
# ============================== CORE SERVICE ==============================
async def extract_cas_from_merged_pdf_service(project_id: str, db: Session) -> List[dict]:
    # 0) kiểm tra project
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        return not_found(message="Không tìm thấy project")

    file_id = None

    # 1) Thử lấy file_id từ logs/file_id_map.json
    try:
        file_id = get_project_file_id(project_id)
    except HTTPException:
        pass  # Không có trong file → fallback sang vector store

    # 2) Nếu chưa có file_id thì fallback sang vector store
    if not file_id:
        vs = get_or_create_vector_store(project, db)

        files_page = client.vector_stores.files.list(vector_store_id=vs.id)

        if not files_page.data:
            raise HTTPException(status_code=400, detail="Vector store trống, chưa có file để đọc")

        file_id = files_page.data[0].id   # chỉ lấy file đầu tiên

    # 2) Gọi Responses API 
    resp = client.responses.create(
        model="gpt-5",
        reasoning={"effort": "minimal"},  # giảm effort để phản hồi nhanh hơn
        text={"verbosity": "low"},  # trả lời ngắn gọn, giảm độ trễ
        input=[
            {
                "role": "user",
                "content": [
                    {"type": "input_file", "file_id": file_id},
                    {"type": "input_text", "text": PROMPT_EXTRACT_MSDS_FIRST},
                ],
            }
        ],
    )
    
    # 5) parse json
    try:
        raw = resp.output_text
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Không lấy được text từ model: {e}")

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Model trả về dữ liệu không phải JSON hợp lệ")

    if isinstance(parsed, dict):
        parsed = [parsed]

    # 6) làm sạch CAS
    results: List[dict] = []
    for item in parsed or []:
        product = item.get("ProductName")
        cas_list = item.get("CasNoList") or []

        cleaned_cas_list = []
        for entry in cas_list:
            cas_number = (entry.get("CasNumber") or "").strip()
            cas_name = entry.get("CasName")
            wt = entry.get("Wt")

            # Giữ nguyên cả CAS hợp lệ và các giá trị đặc biệt theo prompt
            if cas_number and (
                re.fullmatch(CAS_REGEX, cas_number) 
                or cas_number.lower() in ["trade secret", "proprietary", "mixture", "n/a"]
            ):
                cleaned_cas_list.append({
                    "CasNumber": cas_number,
                    "CasName": cas_name,
                    "Wt": wt
                })

        results.append({
            "ProductName": product,
            "CasNoList": cleaned_cas_list
        })
    
    #import list casno vao msds
    payload = ProjectBatchCasIn(ProjectId=project_id, Results=results)
    out = handle_project_batch_notes_by_cas(db, payload)

    items = out.get("items") if isinstance(out, dict) else getattr(out, "items", [])
    id_map: Dict[str, int] = {}
    for it in items or []:
        # it có thể là dict hoặc model
        pname = (it.get("product_name") if isinstance(it, dict) else getattr(it, "product_name", None)) or ""
        mid = (it.get("msds_id") if isinstance(it, dict) else getattr(it, "msds_id", None))
        if pname and mid:
            id_map[pname] = mid

    for item in results:
        item["msds_id"] = id_map.get(item.get("ProductName") or "")

    return results

# return mockdata for testing
async def extract_cas_from_merged_pdf_service_mock(project_id: str, db: Session) -> List[dict]:
    
    # mock data thay cho parsed
    mock_data = [
        {
            "ProductName": "CHEMLOK 6250",
            "CasNoList": [
            {"CasNumber":"1330-20-7","CasName":"Xylene","Wt":"65"},
            {"CasNumber":"100-41-4","CasName":"Ethyl benzene","Wt":"15"},
            {"CasNumber":"1333-86-4","CasName":"Carbon black","Wt":"10"},
            {"CasNumber":"PROPRIETARY","CasName":"Nitrogen substituted aromatic","Wt":"10"},
            {"CasNumber":"PROPRIETARY","CasName":"Aromatic polyisocyanate","Wt":"5"},
            {"CasNumber":"101-68-8","CasName":"4,4'-Diphenylmethane diisocyanate","Wt":"5"},
            {"CasNumber":"5873-54-1","CasName":"2,4-Diphenylmethane diisocyanate","Wt":"0.9"}
            ]
        },
        {
            "ProductName": "CHEMLOK\u00ae 6254",
            "CasNoList": [
            {"CasNumber":"108-88-3","CasName":"Toluene","Wt":"60"},
            {"CasNumber":"1330-20-7","CasName":"Xylene","Wt":"15"},
            {"CasNumber":"PROPRIETARY","CasName":"Nitrogen substituted aromatic","Wt":"10"},
            {"CasNumber":"1314-13-2","CasName":"Zinc oxide (ZnO)","Wt":"5"},
            {"CasNumber":"100-41-4","CasName":"Ethyl benzene","Wt":"5"},
            {"CasNumber":"PROPRIETARY","CasName":"Imide","Wt":"5"},
            {"CasNumber":"1333-86-4","CasName":"Carbon black","Wt":"5"},
            {"CasNumber":"7782-49-2","CasName":"Selenium","Wt":"5"},
            {"CasNumber":"PROPRIETARY","CasName":"Epoxy novalac resin","Wt":"0.9"},
            {"CasNumber":"67-64-1","CasName":"Acetone","Wt":"0.9"}
            ]
        }
    ]
    # xử lý làm sạch CAS giống như code thật
   # 6) làm sạch CAS
    results: List[dict] = []
    for item in mock_data or []:
        product = item.get("ProductName")
        cas_list = item.get("CasNoList") or []

        cleaned_cas_list = []
        for entry in cas_list:
            cas_number = (entry.get("CasNumber") or "").strip()
            cas_name = entry.get("CasName")
            wt = entry.get("Wt")

            # Giữ nguyên cả CAS hợp lệ và các giá trị đặc biệt theo prompt
            if cas_number and (
                re.fullmatch(CAS_REGEX, cas_number) 
                or cas_number.lower() in ["trade secret", "proprietary", "mixture", "n/a"]
            ):
                cleaned_cas_list.append({
                    "CasNumber": cas_number,
                    "CasName": cas_name,
                    "Wt": wt
                })

        results.append({
            "ProductName": product,
            "CasNoList": cleaned_cas_list
        })

        #import list casno vao msds
    payload = ProjectBatchCasIn(ProjectId=project_id, Results=results)
    
    handle_project_batch_notes_by_cas(db,payload)

    return results

#extract output
async def extract_msds_output_service(project_id: str, db: Session) -> List[BatchOutputItemIn]:
    # 0) kiểm tra project
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=500, detail="Không tìm thấy project")
    if not project.vector_store_id:
         raise HTTPException(status_code=500, detail="Không tìm thấy vector store")
    
    #lấy extra info liên quan dến phụ lục
    extra_info = json.loads(
      project_id_cas_notes_preview(project_id, db).body.decode("utf-8")
    ).get("data")
    file_id = None
    # 1) Thử lấy file_id từ logs/file_id_map.json
    try:
        file_id = get_project_file_id(project_id)
    except HTTPException:
        pass  # Không có trong file → fallback sang vector store

    # 2) Nếu chưa có file_id thì fallback sang vector store
    if not file_id:
        vs = get_or_create_vector_store(project, db)

        files_page = client.vector_stores.files.list(vector_store_id=vs.id)

        if not files_page.data:
            raise HTTPException(status_code=400, detail="Vector store trống, chưa có file để đọc")

        file_id = files_page.data[0].id   # chỉ lấy file đầu tiên

    # 4) Gọi Responses API 
    resp = client.responses.create(
        model="gpt-5",
        reasoning={"effort": "minimal"},  # giảm effort để phản hồi nhanh hơn
        text={"verbosity": "low"},  # trả lời ngắn gọn, giảm độ trễ
        input=[
            {
                "role": "user",
                "content": [
                    {"type": "input_file", "file_id": file_id},
                    {"type": "input_text", "text": PROMPT_EXTRACT_MSDS_OUTPUT_V2},
                    {"type": "input_text", "text": json.dumps(extra_info, ensure_ascii=False)},
                ],
            }
        ],
    )
    # 5) parse json
    try:
        raw = resp.output_text
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Không lấy được text từ model: {e}")

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Model trả về dữ liệu không phải JSON hợp lệ")

    if isinstance(parsed, dict):
        parsed = [parsed]
    
    result: List[BatchOutputItemIn] = [BatchOutputItemIn(**item) for item in parsed]

    return result


