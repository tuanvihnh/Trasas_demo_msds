# app/services/chemical_mapping.py
from typing import Optional, Sequence, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import select, func, update, delete
from app.models.models import ChemicalMapping
from app.schemas.schemas import ChemicalMappingCreate, ChemicalMappingUpdate

def list_mappings(
    db: Session,
    *,
    chemical_id: Optional[int] = None,
    regulation_id: Optional[int] = None,
    article_id: Optional[int] = None,
    appendix_id: Optional[int] = None,
    status: Optional[int] = None,
    page: int = 1,
    size: int = 50
) -> Tuple[int, Sequence[ChemicalMapping]]:
    stmt = select(ChemicalMapping)
    count_stmt = select(func.count())

    # filters
    filters = []
    if chemical_id is not None:
        filters.append(ChemicalMapping.chemical_id == chemical_id)
    if regulation_id is not None:
        filters.append(ChemicalMapping.regulation_id == regulation_id)
    if article_id is not None:
        filters.append(ChemicalMapping.article_id == article_id)
    if appendix_id is not None:
        filters.append(ChemicalMapping.appendix_id == appendix_id)
    if status is not None:
        filters.append(ChemicalMapping.status == status)

    if filters:
        stmt = stmt.where(*filters)
        count_stmt = count_stmt.select_from(ChemicalMapping).where(*filters)
    else:
        count_stmt = count_stmt.select_from(ChemicalMapping)

    total = db.execute(count_stmt).scalar_one()
    items = db.execute(stmt.offset((page-1)*size).limit(size)).scalars().all()
    return total, items

def get(db: Session, mapping_id: int) -> Optional[ChemicalMapping]:
    return db.get(ChemicalMapping, mapping_id)

def create(db: Session, data: ChemicalMappingCreate) -> ChemicalMapping:
    obj = ChemicalMapping(**data.model_dump(exclude_unset=True))
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj

def update_one(db: Session, mapping_id: int, data: ChemicalMappingUpdate) -> Optional[ChemicalMapping]:
    obj = db.get(ChemicalMapping, mapping_id)
    if not obj:
        return None
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(obj, k, v)
    db.commit()
    db.refresh(obj)
    return obj

def delete_one(db: Session, mapping_id: int) -> bool:
    obj = db.get(ChemicalMapping, mapping_id)
    if not obj:
        return False
    db.delete(obj)
    db.commit()
    return True
