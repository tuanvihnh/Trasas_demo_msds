
from typing import Any, Dict, List, Optional
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from typing import Optional, List
from app.models.models import *
from app.schemas.schemas import *


def _get_or_create_chemical(db: Session, name: str, cas: Optional[str]):
    chem = None
    if cas:
        chem = db.query(Chemical).filter(Chemical.cas_no == cas).one_or_none()
    if not chem and name:
        chem = (
            db.query(Chemical)
            .filter(func.lower(Chemical.chemical_name) == name.strip().lower())
            .one_or_none()
        )
    if not chem:
        chem = Chemical(
            chemical_name=name.strip() if name else "Unknown",
            cas_no=cas.strip() if cas else None,
            status=1
        )
        db.add(chem)
        db.flush()  # để có chemical_id
    return chem
