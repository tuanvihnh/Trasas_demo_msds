from collections import defaultdict
from typing import Any, DefaultDict, List, Dict
from sqlalchemy import literal, select, func
from sqlalchemy.orm import Session


from app.schemas.schemas import (
    OutputFullOut, OutputPermitOut, ProductNotesShow, ProjectBatchCasIn, ProjectBatchCasOut, ProductNotes, ChemicalNote, SecondExtractBatchIn, SecondExtractIn, SecondExtractPermitIn, SecondExtractSavedOut
)
from sqlalchemy.orm import Session, aliased

# MODELS ĐANG DÙNG
from app.models.models import Appendix, Chemical, ChemicalMapping, MSDSChemical, Output, OutputElement, OutputPermit, Project, Regulation, RegulationAppendix
from app.models.models import MSDS
from app.utils.response import not_found, ok

def _pick_msds_wt_expr():
    """Chọn cột trọng lượng theo thứ tự ưu tiên: wtf -> pct_wt -> wt."""
    if hasattr(MSDSChemical, "wtf"):
        return MSDSChemical.wtf.label("wt")
    if hasattr(MSDSChemical, "pct_wt"):
        return MSDSChemical.pct_wt.label("wt")
    if hasattr(MSDSChemical, "wt"):
        return MSDSChemical.wt.label("wt")
    return None


def build_notes_summary_for_msds(db: Session, msds_id: int) -> list[dict]:
    # 0) chọn wt expr
    wt_col = _pick_msds_wt_expr()

    # 1) dòng hóa chất trong MSDS
    cols = [MSDSChemical.cas_no.label("cas_no")]
    if hasattr(MSDSChemical, "chemical_name"):
        cols.append(MSDSChemical.chemical_name.label("chemical_name"))
    if wt_col is not None:
        cols.append(wt_col)

    chem_lines = db.execute(
        select(*cols).where(MSDSChemical.msds_id == msds_id)
    ).all()
    if not chem_lines:
        return []

    cas_list = sorted({r._mapping["cas_no"] for r in chem_lines if r._mapping.get("cas_no")})

    # 2) master chemical để lấy hs_code
    Chem = aliased(Chemical)
    chem_master = db.execute(
        select(Chem.id, Chem.cas_no, Chem.hs_code).where(Chem.cas_no.in_(cas_list))
    ).all()
    cas2chem = {c.cas_no: c for c in chem_master}
    chem_ids = [c.id for c in chem_master]

    # 3) mapping -> appendix -> regulation (KHỬ TRÙNG LẶP)
    Map = aliased(ChemicalMapping)
    App = aliased(Appendix)
    Reg = aliased(Regulation)
    regs_by_chem_id: dict[int, list[dict]] = {}

    if chem_ids:
        rows = db.execute(
            select(
                Map.chemical_id,
                App.id.label("app_id"),
                App.title.label("appendix_title"),
                App.note.label("appendix_note"),
                App.law_text.label("appendix_law_text"),
                Reg.code.label("regulation_code"),
                Reg.title.label("regulation_title"),
            )
            .join(App, Map.appendix_id == App.id)
            .join(Reg, Reg.id == App.regulation_id, isouter=True)
            .where(Map.chemical_id.in_(chem_ids))
        ).all()

        seen = set()
        for r in rows:
            key = (
                r.chemical_id, r.app_id, r.appendix_title,
                r.appendix_note, r.appendix_law_text, r.regulation_code, r.regulation_title
            )
            if key in seen:
                continue
            seen.add(key)
            regs_by_chem_id.setdefault(r.chemical_id, []).append({
                # giữ key "title"/"note"/"law_text" để tương thích cũ
                "title": r.appendix_title,
                "note": r.appendix_note or "",
                "law_text": r.appendix_law_text or "",
                # trường "regulation" phải là CHUỖI -> dùng code (hoặc "")
                "regulation": (r.regulation_code or ""),
                # bonus: thêm tiêu đề nghị định (nếu muốn dùng phía client)
                "regulation_title": (r.regulation_title or None),
            })

    # 4) chuẩn hóa hs_code: bỏ dấu chấm
    def normalize_hs(hs):
        if not hs:
            return None
        return "".join(str(hs).split("."))

    # 5) ráp output
    out: list[dict] = []
    for r in chem_lines:
        m = r._mapping
        cas = m.get("cas_no")
        cm = cas2chem.get(cas)
        out.append({
            "cas_no": cas,
            "chemical_name": m.get("chemical_name"),
            "wt": m.get("wt"),
            "hs_code": normalize_hs(getattr(cm, "hs_code", None)),
            "regulations": regs_by_chem_id.get(getattr(cm, "id", -1), []),
        })
    return out
def _get_or_create_msds(db: Session, project_id: int, product_name: str | None) -> int:
    # idempotent theo (project_id, product_name)
    q = (
        select(MSDS.id)
        .where(MSDS.project_id == project_id)
        .where(MSDS.product_name == (product_name or None))
        .limit(1)
    )
    row = db.execute(q).first()
    if row:
        return row[0]
    ms = MSDS(project_id=project_id, product_name=product_name or None, status=1)
    db.add(ms)
    db.flush()
    return ms.id


def _insert_msds_chemicals(db: Session, msds_id: int, cas_list: List[str]) -> None:
    if not cas_list:
        return
    # tránh trùng (msds_id, cas_no)
    existing = set(
        db.execute(
            select(MSDSChemical.cas_no)
            .where(MSDSChemical.msds_id == msds_id)
            .where(MSDSChemical.cas_no.in_(cas_list))
        ).scalars().all()
    )
    for cas in cas_list:
        if cas in existing:
            continue
        db.add(MSDSChemical(msds_id=msds_id, cas_no=cas, status=1))
    db.flush()


def _collect_notes_for_cas_list(db: Session, cas_list: List[str]) -> Dict[str, ChemicalNote]:
    out: Dict[str, ChemicalNote] = {}
    if not cas_list:
        return out

    chems = db.execute(
        select(Chemical.id, Chemical.cas_no, Chemical.hs_code)
        .where(Chemical.cas_no.in_(cas_list))
    ).all()
    cas_to = {cas: {"id": cid, "hs": hs} for cid, cas, hs in chems}

    for cas in cas_list:
        out[cas] = ChemicalNote(cas_no=cas, hs_code=None, regulations=[])

    if not chems:
        return out

    chem_ids = [r[0] for r in chems]
    App = aliased(Appendix)
    Reg = aliased(Regulation)

    rows = db.execute(
        select(
            Chemical.id.label("cid"),
            App.title.label("appendix_title"),
            App.note.label("appendix_note"),
            App.law_text.label("appendix_law_text"),
            Reg.code.label("regulation_code"),
            Reg.title.label("regulation_title"),
        )
        .join(ChemicalMapping, ChemicalMapping.chemical_id == Chemical.id)
        .join(App, App.id == ChemicalMapping.appendix_id, isouter=True)
        .join(Reg, Reg.id == App.regulation_id, isouter=True)
        .where(Chemical.id.in_((chem_ids)))
    ).all()

    cid_to_cas = {v["id"]: k for k, v in cas_to.items()}
    for cid, app_title, app_note, app_law, reg_code, reg_title in rows:
        cas = cid_to_cas.get(cid)
        if not cas:
            continue
        if out[cas].hs_code is None and cas_to[cas]["hs"]:
            out[cas].hs_code = cas_to[cas]["hs"]
        out[cas].regulations.append({
            "appendix": app_title,
            "title": app_title,
            "note": app_note,
            "law_text": app_law,
            "regulation": (reg_code or ""),         # ép CHUỖI
            "regulation_title": (reg_title or None)
        })

    return out

def handle_project_batch_notes_by_cas(db: Session, payload: ProjectBatchCasIn) -> ProjectBatchCasOut:
    project_id = payload.ProjectId
    out_items: list[ProductNotes] = []

    for item in payload.Results:
        # tạo/lấy MSDS theo product_name trong project
        msds = (
            db.query(MSDS)
              .filter(MSDS.project_id == project_id, MSDS.product_name == item.ProductName)
              .one_or_none()
        )
        if msds is None:
            msds = MSDS(project_id=project_id, product_name=item.ProductName)
            db.add(msds)
            db.flush()

        # cache dòng đã có
        existing = {
            r.cas_no: r
            for r in db.query(MSDSChemical)
                       .filter(MSDSChemical.msds_id == msds.id).all()
        }

        # ghi lines theo CasNumber/CasName/Wt
        for c in item.CasNoList or []:
            if not c.CasNumber:
                continue
            row = existing.get(c.CasNumber)
            if row:  # cập nhật dòng cũ
                if hasattr(row, "chemical_name"):
                    row.chemical_name = c.CasName
                if hasattr(MSDSChemical, "wtf"):
                    row.wtf = c.Wt
                elif hasattr(MSDSChemical, "pct_wt"):
                    row.pct_wt = c.Wt
                elif hasattr(MSDSChemical, "wt"):
                    row.wt = c.Wt
            else:    # thêm mới
                kwargs = {"msds_id": msds.id, "cas_no": c.CasNumber}
                if hasattr(MSDSChemical, "chemical_name"):
                    kwargs["chemical_name"] = c.CasName
                if hasattr(MSDSChemical, "wtf"):
                    kwargs["wtf"] = c.Wt
                elif hasattr(MSDSChemical, "pct_wt"):
                    kwargs["pct_wt"] = c.Wt
                elif hasattr(MSDSChemical, "wt"):
                    kwargs["wt"] = c.Wt
                db.add(MSDSChemical(**kwargs))

        db.flush()

        # build summary
        notes = build_notes_summary_for_msds(db, msds.id)
        out_items.append(ProductNotes(
            product_name=item.ProductName,
            msds_id=msds.id,
            notes_summary=notes
        ))

    db.commit()
    return ProjectBatchCasOut(project_id=project_id, items=out_items)

def preview_project_batch_notes_by_cas(db: Session, payload: ProjectBatchCasIn) -> ProjectBatchCasOut:
    out_items: list[ProductNotes] = []

    for item in payload.Results:
        # Lấy CAS duy nhất theo thứ tự xuất hiện
        cas_list = []
        seen = set()
        for c in item.CasNoList or []:
            if c.CasNumber and c.CasNumber not in seen:
                seen.add(c.CasNumber)
                cas_list.append(c.CasNumber)

        # Tra cứu quy định theo CAS, không ghi DB
        notes_map = _collect_notes_for_cas_list(db, cas_list)

        # Bổ sung tên hóa chất và Wt từ input
        by_cas_input = {c.CasNumber: c for c in (item.CasNoList or []) if c.CasNumber}
        for cas in cas_list:
            note = notes_map.get(cas)
            if not note:
                continue
            # Nếu note lỡ là list (phiên bản cũ), bọc lại thành ChemicalNote
            if isinstance(note, list):
                note = ChemicalNote(cas_no=cas, hs_code=None, regulations=note)
                notes_map[cas] = note

            src = by_cas_input.get(cas)
            if src:
                note.chemical_name = src.CasName
                note.wt = src.Wt

        out_items.append(
            ProductNotes(
                product_name=item.ProductName,
                msds_id=0,
                notes_summary=[
                    (ChemicalNote(cas_no=cas, hs_code=None, regulations=notes_map[cas])
                    if isinstance(notes_map.get(cas), list)
                    else notes_map[cas])
                    for cas in cas_list if cas in notes_map
                ],
            )
        )

    return ProjectBatchCasOut(project_id=payload.ProjectId, items=out_items)

def _collect_notes_for_cas_list(db: Session, cas_list: List[str]) -> Dict[str, List[Dict[str, Any]]]:
    if not cas_list:
        return {}
    # bulk join 1 lần cho toàn bộ CAS
    stmt = (
        select(
            Chemical.cas_no.label("cas_no"),
            Chemical.chemical_name.label("chemical_name"),
            RegulationAppendix.id.label("appendix_id"),
            Regulation.code.label("appendix_code"),
            RegulationAppendix.title.label("appendix_title"),
            RegulationAppendix.note.label("note"),
            RegulationAppendix.law_text.label("law_text"),
            RegulationAppendix.regulation_text.label("regulation_text"),
        )
        .select_from(Chemical)
        .join(ChemicalMapping, ChemicalMapping.chemical_id == Chemical.id, isouter=True)
        .join(RegulationAppendix, RegulationAppendix.id == ChemicalMapping.appendix_id, isouter=True)
        .where(Chemical.cas_no.in_(cas_list))
    )
    rows = db.execute(stmt).all()
    out: DefaultDict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        # Nếu không có mapping, vẫn trả entry rỗng để biết CAS đã được xét
        out[r.cas_no].append({
            # "appendix": {"id": r.appendix_id, "code": r.appendix_code},
            "title": r.appendix_title,
            "note": r.note,
            "law_text": r.law_text,
            "regulation_text": r.regulation_text,
        } if r.appendix_id is not None else {})
    # Chuẩn hoá: nếu chỉ có dict rỗng, chuyển thành []
    for k, v in list(out.items()):
        v2 = [x for x in v if x]  # loại dict rỗng
        out[k] = v2
    return out


def project_id_cas_notes_preview(project_id: int, db: Session) -> ProjectBatchCasOut:
    # 1) Tồn tại project?
    proj = db.execute(select(Project.id).where(Project.id == project_id)).scalar()
    if not proj:
        # trả về object hợp lệ thay vì [] hay ok(...) để route bọc envelope
        return ProjectBatchCasOut(project_id=project_id, items=[])

    # 2) Lấy toàn bộ MSDS + CAS cho project
    wt_expr = _pick_msds_wt_expr()
    select_cols = [
        MSDS.id.label("msds_id"),
        MSDS.product_name.label("product_name"),
        MSDSChemical.cas_no.label("cas_no"),
    ]
    if hasattr(MSDSChemical, "chemical_name"):
        select_cols.append(MSDSChemical.chemical_name.label("cas_name"))
    else:
        select_cols.append(literal(None).label("cas_name"))
    if wt_expr is not None:
        select_cols.append(wt_expr)
    else:
        select_cols.append(literal(None).label("wt"))

    msds_rows = db.execute(
        select(*select_cols)
        .join(MSDSChemical, MSDSChemical.msds_id == MSDS.id, isouter=True)
        .where(MSDS.project_id == project_id)
        .order_by(MSDS.id.asc())
    ).all()

    # Không có MSDS thì trả object rỗng hợp lệ
    if not msds_rows:
        payload = {"project_id": project_id, "items": []}
        return ok(payload, "Không có MSDS cho project này")

    # 3) Gom theo MSDS
    items_map: Dict[int, Dict[str, Any]] = {}
    all_cas: set[str] = set()
    for row in msds_rows:
        if row.msds_id not in items_map:
            items_map[row.msds_id] = {
                "product_name": row.product_name,
                "msds_id": row.msds_id,
                "notes_summary": []
            }
        if row.cas_no:
            all_cas.add(row.cas_no)

    # 4) Lấy notes pháp lý cho toàn bộ CAS 1 lượt
    notes_map = _collect_notes_for_cas_list(db, list(all_cas))

    # 5) Lắp notes (tạo ChemicalNote để đồng bộ schema)
    for row in msds_rows:
        if not row.cas_no:
            continue
        base = notes_map.get(row.cas_no)
        if isinstance(base, list):
            base = ChemicalNote(cas_no=row.cas_no, hs_code=None, regulations=base)
        if base is None:
            base = ChemicalNote(cas_no=row.cas_no, hs_code=None, regulations=[])

        # base = notes_map.get(row.cas_no) or ChemicalNote(cas_no=row.cas_no, hs_code=None, regulations=[])
        base.chemical_name = row.cas_name
        base.wt = row.wt
        items_map[row.msds_id]["notes_summary"].append(base)


    # 6) Chuẩn hoá output
    items = list(items_map.values())
    payload = {
        "project_id": project_id,
        "items": items,
    }
    return ok(payload, "Fetched successfully")

def _dedup_permits(perms: list[SecondExtractPermitIn]) -> list[SecondExtractPermitIn]:
    seen, out = set(), []
    for p in perms:
        key = (p.un_number, p.match_chemical_name_core_component, p.match_un_number)
        if key in seen: continue
        seen.add(key); out.append(p)
    return out

def save_second_extract(db: Session, payload: SecondExtractIn) -> SecondExtractSavedOut:
    # Create the main Output
    output = Output(
        project_id=payload.project_id,
        product_name=payload.product_name,
        ghs_signal_word=payload.ghs_signal_word,
        ghs_hazard_statements=payload.ghs_hazard_statements,
        msds_id=payload.msds_id,
        total_pct=payload.total_pct,
        temperature_storage_at=payload.temperature_storage_at,
        warehouse_type=payload.warehouse_type,
        product_class=payload.product_class_number,
        is_msds_vn_16_field=payload.is_msds_vn_16_field,
        special_warnings_transportation=payload.special_warnings_transportation,
        match_class_of_products=payload.match_class_of_products,
        physical_state=payload.physical_state,
        physicochemical_properties=payload.physicochemical_properties,
        toxicity=payload.toxicity,
        status=payload.status,
        create_by=payload.create_by,
        update_by=payload.update_by
    )
    db.add(output)
    db.commit()
    db.refresh(output)
    
    # Create permits (loop over payload.permits)
    created_permits = []
    for permit_data in payload.permits:
        permit = OutputPermit(
            output_id=output.id,
            un_number=permit_data.un_number,
            match_chemical_name_core_component=permit_data.match_chemical_name_core_component,
            match_un_number=permit_data.match_un_number,
            license_number=permit_data.license_number,  # Fixed: access from permit_data
            license_plate_number=permit_data.license_plate_number,
            expiration_date=permit_data.expiration_date,
            route_allowed=permit_data.route_allowed,
            status=permit_data.status,
            create_by=permit_data.create_by,
            update_by=permit_data.update_by
        )
        db.add(permit)
        created_permits.append(permit)
    
    # Create elements (similar loop)
    created_elements = []
    for element_data in payload.elements:
        element = OutputElement(
            output_id=output.id,
            cas_no=element_data.cas_no,
            chemical_name=element_data.chemical_name,
            wtf=element_data.wtf,
            dangerous_chemical=element_data.dangerous_chemical,
            pl1=element_data.pl1,
            pl2=element_data.pl2,
            pl3=element_data.pl3,
            pl4=element_data.pl4,
            pl5=element_data.pl5,
            no_license=element_data.no_license,
            drug_precursors=element_data.drug_precursors,
            table_chemicals=element_data.table_chemicals,
            notes=element_data.notes,
            status=element_data.status,
            create_by=element_data.create_by,
            update_by=element_data.update_by
        )
        db.add(element)
        created_elements.append(element)
    
    db.commit()
    
    # Refresh all for output
    db.refresh(output)
    for p in created_permits:
        db.refresh(p)
    for e in created_elements:
        db.refresh(e)
    
    # Build response
    full_output = OutputFullOut(
        **output.__dict__,
        Permits=created_permits,
        Elements=created_elements
    )
    return SecondExtractSavedOut(output=full_output)

def save_second_extract_batch(db: Session, payload: SecondExtractBatchIn) -> List[SecondExtractSavedOut]:
    results = []
    for item in payload.items:
        results.append(save_second_extract(db, item))
    return results