import json
from pathlib import Path
from datetime import datetime

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

from typing import Any, Dict, Mapping, Optional


def save_log(subdir: str, project_id: str, content: Dict[str, Any]):
    """
    Ghi nội dung `content` ra file trong logs/{subdir}/{project_id}.json

    Args:
        subdir (str): Tên thư mục con trong thư mục logs.
        project_id (str): ID của dự án.
        content (Dict[str, Any]): Nội dung log dạng dictionary.
    """
    folder = LOG_DIR / subdir
    folder.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"{project_id}_{timestamp}.json"
    filepath = folder / filename

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(content, f, indent=2, ensure_ascii=False)

    return str(filepath)


def save_prompt_snapshot(
    context: str,
    project_id: str,
    prompts: Mapping[str, str],
    metadata: Optional[Dict[str, Any]] = None,
) -> str:
    """Persist the merged prompts before sending them to OpenAI."""

    payload: Dict[str, Any] = {
        "context": context,
        "prompts": dict(prompts),
    }
    if metadata:
        payload["metadata"] = metadata

    return save_log(f"prompt_snapshots/{context}", project_id, payload)
