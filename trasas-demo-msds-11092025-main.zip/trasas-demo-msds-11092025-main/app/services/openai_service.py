from app.core.openai_client import client
from typing import List


def create_file_from_path(file_path: str, purpose: str = "user_data"):
    """
    Tạo file trên OpenAI từ đường dẫn local
    """
    with open(file_path, "rb") as f:
        return client.files.create(file=f, purpose=purpose)


def send_prompt_with_file(file_id: str, prompt_text: str, model: str = "gpt-4.1"):
    """
    Gửi prompt kèm file_id đến Responses API
    """
    response = client.responses.create(
        model=model,
        input=[
            {
                "role": "user",
                "content": [
                    {"type": "input_file", "file_id": file_id},
                    {"type": "input_text", "text": prompt_text},
                ],
            }
        ],
    )
    return response.output_text


def send_multiple_prompts(file_id: str, prompts: List[str], model: str = "gpt-4.1"):
    """
    Gửi nhiều prompt khác nhau với cùng 1 file_id → trả về danh sách kết quả
    """
    results = []
    for prompt in prompts:
        output = send_prompt_with_file(file_id, prompt, model)
        results.append(output)
    return results

