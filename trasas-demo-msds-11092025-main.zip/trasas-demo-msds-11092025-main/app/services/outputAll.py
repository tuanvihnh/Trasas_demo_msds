# services/outputAll.py
from typing import List
from fastapi import HTTPException, status
from sqlalchemy import delete, select, func
from sqlalchemy.orm import joinedload, selectinload
from app.models.models import Project, Output, User, OutputPermit, OutputElement
from app.schemas.schemas import *
from app.utils.response import not_found, ok
from datetime import datetime
from sqlalchemy.orm import Session

def to_bool(v):
    if isinstance(v, bool): return v
    if v is None: return False
    if isinstance(v, str):
        v_lower = v.lower()
        if v_lower in ('true', '1', 'yes'): return True
        if v_lower in ('false', '0', 'no'): return False
    if isinstance(v, int):
        return bool(v)
    raise ValueError(f"Invalid boolean value: {v}")

def get_mock_outputs_service(db: Session, current: User):
    try:
        projects_with_outputs = (
            db.query(Project)
            .join(Output, Project.id == Output.project_id)
            .options(
                selectinload(Project.outputs)
                .selectinload(Output.elements),
                selectinload(Project.outputs)
                .selectinload(Output.permits)
            )
            .distinct()
            .all()
        )
        
        if not projects_with_outputs:
            return not_found(message="No projects with outputs found")
        
        formatted_projects = []
        
        for project in projects_with_outputs:
            creator_name = "Unknown"
            if project.owner:
                creator_name = project.owner.username
            elif project.user_id:
                user = db.query(User).filter(User.id == project.user_id).first()
                if user:
                    creator_name = user.username
            
            msds_list = []
            for output in project.outputs:
                elements = []
                for element in output.elements:
                    element_dict = {
                        "CasNo": element.cas_no or "",
                        "ChemicalName": element.chemical_name or "",
                        "WtPercent": element.wtf or "",
                        "PL1": element.pl1,
                        "PL2": element.pl2,
                        "PL3": element.pl3,
                        "PL4": element.pl4,
                        "PL5": element.pl5,
                        "NoLicense": element.no_license or False,
                        "DrugPrecursor": element.drug_precursors,
                        "ScheduledChemical": element.table_chemicals,
                        "Note": element.notes,
                        "conditional_license": element.conditional_license,
                        "restricted_chemical_license": element.restricted_chemical_license
                    }
                    elements.append(element_dict)
                
                permits = []
                for permit in output.permits:
                    permit_dict = {
                        "MatchIngredientName": permit.match_chemical_name_core_component or False,
                        "MatchUNNumber": permit.match_un_number or False,
                        "LicenseNumber": permit.license_number,
                        "VehiclePlate": permit.license_plate_number,
                        "ExpirationDate": permit.expiration_date.strftime("%Y-%m-%d") if permit.expiration_date else None,
                        "PermittedRoute": permit.route_allowed
                    }
                    permits.append(permit_dict)
                
                ghs = ""
                if output.ghs_signal_word and output.ghs_hazard_statements:
                    ghs = f"{output.ghs_signal_word}; {output.ghs_hazard_statements}"
                elif output.ghs_hazard_statements:
                    ghs = output.ghs_hazard_statements
                elif output.ghs_signal_word:
                    ghs = output.ghs_signal_word
                
                msds_item = {
                    "ProductName": output.product_name or "",
                    "GHS": ghs,
                    "DangerousChemical": output.dangerous_chemical or False,
                    "Element": elements,
                    "Permit": permits,
                    "TotalWtPercent": float(output.total_pct) if output.total_pct is not None else None,
                    "StorageTemperature": output.temperature_storage_at or "",
                    "StorageType": output.warehouse_type or "",
                    "ClassNumber": output.product_class or "Unknown",
                    "Has16Section": output.is_msds_vn_16_field or "",
                    "UNNumber": output.permits[0].un_number if output.permits else "",
                    "SpecialNoteForTransport": output.special_warnings_transportation or "",
                    "MatchClass": output.match_class_of_products or False,
                    "PhysicalState": output.physical_state or "",
                    "PhysicochemicalProperties": output.physicochemical_properties or "",
                    "Toxicity": output.toxicity or ""
                }
                msds_list.append(msds_item)
            
            project_item = {
                "id": str(project.id),
                "name": project.project_name,
                "creator": creator_name,
                "createdAt": project.created_at.strftime("%d/%m/%Y") if project.created_at else "Unknown",
                "msds": msds_list
            }
            formatted_projects.append(project_item)
        
        return ok(formatted_projects, "Data fetched successfully from database")
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching data from database: {str(e)}"
        )

def create_output_from_ai_service(payload: OutputFromAI, db: Session, current: User):
    output = Output(
        project_id=payload.project_id,
        product_name=payload.product_name,
        ghs_signal_word=payload.ghs_signal_word,
        ghs_hazard_statements=payload.ghs_hazard_statements,
        msds_id=payload.msds_id,
        total_pct=payload.total_pct,
        temperature_storage_at=payload.temperature_storage_at,
        warehouse_type=payload.warehouse_type,
        product_class=payload.product_class,
        is_msds_vn_16_field=payload.is_msds_vn_16_field,
        special_warnings_transportation=payload.special_warnings_transportation,
        match_class_of_products=to_bool(payload.match_class_of_products),
        physical_state=payload.physical_state,
        physicochemical_properties=payload.physicochemical_properties,
        toxicity=payload.toxicity,
        status=to_bool(payload.status),
    )
    db.add(output)
    db.commit()
    db.refresh(output)
    return ok(output, "Created successfully")

def list_outputs_service(db: Session):
    items = (
        db.query(Output)
        .options(joinedload(Output.permits), joinedload(Output.elements))
        .all()
    )
    data = [OutputOut.model_validate(o) for o in items]
    return ok(data, "OK", status.HTTP_200_OK)

def get_output_service(output_id: int, db: Session):
    o = (
        db.query(Output)
        .options(joinedload(Output.permits), joinedload(Output.elements))
        .filter(Output.id == output_id)
        .first()
    )
    if not o:
        return not_found(message="Output not found")
    return ok(OutputOut.model_validate(o), "OK", status.HTTP_200_OK)

def update_output_service(output_id: int, payload: OutputUpdate, db: Session, current: User):
    output = db.query(Output).filter(Output.id == output_id).first()
    if not output:
        return not_found(message="Output not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        if key in ['match_class_of_products', 'status']:
            value = to_bool(value)
        setattr(output, key, value)
    db.commit()
    db.refresh(output)
    return ok(output, "Updated successfully", status.HTTP_200_OK)

def delete_output_service(output_id: int, db: Session):
    o = db.get(Output, output_id)
    if not o:
        return not_found(message="Output not found")
    db.delete(o)
    db.commit()
    return ok(None, "Deleted", status.HTTP_200_OK)

def delete_outputs_by_project_service(project_id: int, db: Session):
    proj = db.execute(
        select(Project.id).where(Project.id == project_id).limit(1)
    ).first()
    if not proj:
        return not_found({"deleted": 0}, "Project not found")
    total_outputs = db.execute(
        select(func.count(Output.id)).where(Output.project_id == project_id)
    ).scalar_one()
    if total_outputs == 0:
        return not_found({"deleted": 0}, "No outputs found for this project")
    res = db.execute(delete(Output).where(Output.project_id == project_id))
    db.commit()
    deleted = res.rowcount or 0
    return ok({"deleted": deleted}, "Delete outputs successfully")

def create_batch_outputs_service(project_id: int, payload: List[BatchOutputItemIn], db: Session):
    created_outputs = []
    
    for item in payload:
        try:
            output = Output(
                project_id=project_id,
                product_name=item.ProductName,
                ghs_hazard_statements=item.GHS,
                dangerous_chemical=item.DangerousChemical,
                total_pct=item.TotalWtPercent,
                temperature_storage_at=item.StorageTemperature,
                warehouse_type=item.StorageType,
                product_class=item.ClassNumber,
                is_msds_vn_16_field=item.Has16Section,
                special_warnings_transportation=item.SpecialNoteForTransport,
                match_class_of_products=item.MatchClass,
                physical_state=item.PhysicalState,
                physicochemical_properties=item.PhysicochemicalProperties,
                toxicity=item.Toxicity,
                status=True,
            )
            db.add(output)
            db.flush()

            for permit_data in item.Permit:
                expiration_date = None
                if permit_data.ExpirationDate:
                    try:
                        expiration_date = datetime.strptime(permit_data.ExpirationDate, '%Y-%m-%d').date()
                    except ValueError:
                        pass

                permit = OutputPermit(
                    output_id=output.id,
                    un_number=item.UNNumber,
                    match_chemical_name_core_component=permit_data.MatchIngredientName or False,
                    match_un_number=permit_data.MatchUNNumber or False,
                    license_number=permit_data.LicenseNumber,
                    license_plate_number=permit_data.VehiclePlate,
                    expiration_date=expiration_date,
                    route_allowed=permit_data.PermittedRoute,
                    status=True,
                )
                db.add(permit)

            for element_data in item.Element:
                element = OutputElement(
                    output_id=output.id,
                    cas_no=element_data.CasNo,
                    chemical_name=element_data.ChemicalName,
                    wtf=element_data.WtPercent,
                    pl1=element_data.PL1,
                    pl2=element_data.PL2,
                    pl3=element_data.PL3,
                    pl4=element_data.PL4,
                    pl5=element_data.PL5,
                    conditional_license=element_data.ConditionalChemicalCertificate,
                    restricted_chemical_license=element_data.RestrictedChemicalLicense,
                    no_license=element_data.NoLicense or False,
                    drug_precursors=element_data.DrugPrecursor,
                    table_chemicals=element_data.ScheduledChemical,
                    notes=element_data.Note,
                    dangerous_chemical=False,
                    status=True,
                )
                db.add(element)

            created_outputs.append(output)
            
        except Exception as e:
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Error creating output: {str(e)}"
            )

    db.commit()

    output_ids = [output.id for output in created_outputs]
    outputs_with_relations = (
        db.query(Output)
        .options(joinedload(Output.permits), joinedload(Output.elements))
        .filter(Output.id.in_(output_ids))
        .all()
    )

    data = []
    for output in outputs_with_relations:
        un_number = output.permits[0].un_number if output.permits else None
        
        item_out = BatchOutputItemOut(
            ProductName=output.product_name,
            GHS=output.ghs_hazard_statements,
            DangerousChemical=output.dangerous_chemical,
            TotalWtPercent=float(output.total_pct) if output.total_pct else None,
            StorageTemperature=output.temperature_storage_at,
            StorageType=output.warehouse_type,
            ClassNumber=output.product_class,
            Has16Section=output.is_msds_vn_16_field,
            UNNumber=un_number,
            SpecialNoteForTransport=output.special_warnings_transportation,
            MatchClass=output.match_class_of_products,
            PhysicalState=output.physical_state,
            PhysicochemicalProperties=output.physicochemical_properties,
            Toxicity=output.toxicity,
            Element=[
                ElementItemOut(
                    CasNo=e.cas_no or "",
                    ChemicalName=e.chemical_name or "",
                    WtPercent=e.wtf or "",
                    PL1=e.pl1,
                    PL2=e.pl2,
                    PL3=e.pl3,
                    PL4=e.pl4,
                    PL5=e.pl5,
                    ConditionalChemicalCertificate=e.conditional_license,
                    RestrictedChemicalLicense=e.restricted_chemical_license,
                    NoLicense=e.no_license or False,
                    DrugPrecursor=e.drug_precursors,
                    ScheduledChemical=e.table_chemicals or "",
                    Note=e.notes or "",
                ) for e in output.elements
            ],
            Permit=[
                PermitItemOut(
                    MatchIngredientName=p.match_chemical_name_core_component or False,
                    MatchUNNumber=p.match_un_number or False,
                    LicenseNumber=p.license_number or "",
                    VehiclePlate=p.license_plate_number or "",
                    ExpirationDate=p.expiration_date.strftime('%Y-%m-%d') if p.expiration_date else None,
                    PermittedRoute=p.route_allowed or "",
                ) for p in output.permits
            ]
        )
        data.append(item_out)
    return ok(data, "Extract thành công")

def get_full_outputs_service(project_id: int, db: Session, current: User):
    try:
        project = (
            db.query(Project)
            .options(
                selectinload(Project.outputs)
                .selectinload(Output.elements),
                selectinload(Project.outputs)
                .selectinload(Output.permits)
            )
            .filter(Project.id == project_id)
            .first()
        )
        
        if not project:
            return not_found(message="Project not found")
        
        if not project.outputs:
            return not_found(message="No outputs found for this project")
        
        creator_name = "Unknown"
        if project.owner:
            creator_name = project.owner.username
        elif project.user_id:
            user = db.query(User).filter(User.id == project.user_id).first()
            if user:
                creator_name = user.username
        
        msds_list = []
        for output in project.outputs:
            elements = []
            for element in output.elements:
                element_dict = {
                    "CasNo": element.cas_no or "",
                    "ChemicalName": element.chemical_name or "",
                    "WtPercent": element.wtf or "",
                    "PL1": element.pl1,
                    "PL2": element.pl2,
                    "PL3": element.pl3,
                    "PL4": element.pl4,
                    "PL5": element.pl5,
                    "NoLicense": element.no_license or False,
                    "DrugPrecursor": element.drug_precursors,
                    "ScheduledChemical": element.table_chemicals,
                    "Note": element.notes,
                    "conditional_license": element.conditional_license,
                    "restricted_chemical_license": element.restricted_chemical_license
                }
                elements.append(element_dict)
            
            permits = []
            for permit in output.permits:
                permit_dict = {
                    "MatchIngredientName": permit.match_chemical_name_core_component or False,
                    "MatchUNNumber": permit.match_un_number or False,
                    "LicenseNumber": permit.license_number,
                    "VehiclePlate": permit.license_plate_number,
                    "ExpirationDate": permit.expiration_date.strftime("%Y-%m-%d") if permit.expiration_date else None,
                    "PermittedRoute": permit.route_allowed
                }
                permits.append(permit_dict)
            
            ghs = ""
            if output.ghs_signal_word and output.ghs_hazard_statements:
                ghs = f"{output.ghs_signal_word}; {output.ghs_hazard_statements}"
            elif output.ghs_hazard_statements:
                ghs = output.ghs_hazard_statements
            elif output.ghs_signal_word:
                ghs = output.ghs_signal_word
            
            msds_item = {
                "ProductName": output.product_name or "",
                "GHS": ghs,
                "DangerousChemical": output.dangerous_chemical or False,
                "Element": elements,
                "Permit": permits,
                "TotalWtPercent": float(output.total_pct) if output.total_pct is not None else None,
                "StorageTemperature": output.temperature_storage_at or "",
                "StorageType": output.warehouse_type or "",
                "ClassNumber": output.product_class or "Unknown",
                "Has16Section": output.is_msds_vn_16_field or "",
                "UNNumber": output.permits[0].un_number if output.permits else "",
                "SpecialNoteForTransport": output.special_warnings_transportation or "",
                "MatchClass": output.match_class_of_products or False,
                "PhysicalState": output.physical_state or "",
                "PhysicochemicalProperties": output.physicochemical_properties or "",
                "Toxicity": output.toxicity or ""
            }
            msds_list.append(msds_item)
        
        project_item = {
            "id": str(project.id),
            "name": project.project_name,
            "creator": creator_name,
            "createdAt": project.created_at.strftime("%d/%m/%Y") if project.created_at else "Unknown",
            "msds": msds_list
        }
        
        return ok(project_item, "Data fetched successfully from database")
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching data from database: {str(e)}"
        )

# Element services

def list_output_elements_service(db: Session, output_id: Optional[int], cas_no: Optional[str], status: Optional[bool], q: Optional[str], page: int, size: int):
    page = max(1, page); size = max(1, min(200, size))
    offset = (page - 1) * size

    base = db.query(OutputElement)
    if output_id is not None:
        base = base.filter(OutputElement.output_id == output_id)
    if cas_no:
        base = base.filter(OutputElement.cas_no == cas_no)
    if q:
        like = f"%{q}%"
        base = base.filter(or_(OutputElement.cas_no.ilike(like), OutputElement.chemical_name.ilike(like)))

    total = base.order_by(None).count()
    items = base.order_by(OutputElement.id.desc()).offset(offset).limit(size).all()
    return ok({"meta": {"total": total, "page": page, "size": size}, "items": items})

def get_output_element_service(element_id: int, db: Session):
    obj = db.query(OutputElement).get(element_id)
    if not obj: return not_found("OutputElement not found")
    return ok(obj)

def create_output_element_service(body: OutputElementIn, db: Session):
    try:
        element_data = body.model_dump(exclude_unset=True)
        
        obj = OutputElement(**element_data)
        db.add(obj)
        db.commit()
        db.refresh(obj)
        return ok(obj, "Created successfully")
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error creating output element: {str(e)}"
        )

def update_output_element_service(element_id: int, payload: OutputElementUpdate, db: Session):
    item = db.get(OutputElement, element_id)
    if not item:
        return not_found(message="Not found")

    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(item, k, v)

    db.add(item)
    db.commit()
    db.refresh(item)
    return ok(item, "Updated")

def update_output_element_partial_service(element_id: int, body: OutputElementUpdate, db: Session):
    obj = db.query(OutputElement).get(element_id)
    if not obj: return not_found("OutputElement not found")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(obj, k, v)
    db.commit(); db.refresh(obj)
    return ok(obj, "Updated")

def delete_output_element_service(element_id: int, db: Session):
    obj = db.query(OutputElement).get(element_id)
    if not obj: return not_found("OutputElement not found")
    db.delete(obj); db.commit()
    return ok({"id": element_id})

# Permit services

def list_output_permits_service(db: Session, output_id: Optional[int], un_number: Optional[str], match_chemical_name_core_component: Optional[bool], match_un_number: Optional[bool], license_number: Optional[str], license_plate_number: Optional[str], route_allowed: Optional[str], status: Optional[bool], q: Optional[str], page: int, size: int):
    page = max(1, page); size = max(1, min(200, size))
    offset = (page - 1) * size

    base = db.query(OutputPermit)
    if output_id is not None:
        base = base.filter(OutputPermit.output_id == output_id)
    if un_number:
        base = base.filter(OutputPermit.un_number == un_number)
    if q:
        like = f"%{q}%"
        base = base.filter(OutputPermit.un_number.ilike(like))

    total = base.order_by(None).count()
    items = base.order_by(OutputPermit.id.desc()).offset(offset).limit(size).all()
    return ok({"meta": {"total": total, "page": page, "size": size}, "items": items})

def get_output_permit_service(permit_id: int, db: Session):
    obj = db.query(OutputPermit).get(permit_id)
    if not obj: return not_found("OutputPermit not found")
    return ok(obj)

def create_output_permit_service(body: OutputPermitIn, db: Session):
    try:
        permit_data = body.model_dump(exclude_unset=True)
        
        obj = OutputPermit(**permit_data)
        db.add(obj)
        db.commit()
        db.refresh(obj)
        return ok(obj, "Created successfully")
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error creating output permit: {str(e)}"
        )

def update_output_permit_service(permit_id: int, payload: OutputPermitUpdate, db: Session):
    item = db.get(OutputPermit, permit_id)
    if not item:
        return not_found(message="Not found")

    for k, v in payload.model_dump(exclude_unset=True).items():
        setattr(item, k, v)

    db.add(item)
    db.commit()
    db.refresh(item)
    return ok(item, "Updated")

def update_output_permit_partial_service(permit_id: int, body: OutputPermitUpdate, db: Session):
    obj = db.query(OutputPermit).get(permit_id)
    if not obj: return not_found("OutputPermit not found")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(obj, k, v)
    db.commit(); db.refresh(obj)
    return ok(obj, "Updated")

def delete_output_permit_service(permit_id: int, db: Session):
    obj = db.query(OutputPermit).get(permit_id)
    if not obj: return not_found("OutputPermit not found")
    db.delete(obj); db.commit()
    return ok({"id": permit_id}, "Deleted")