import json
import os
import logging
from pathlib import Path
import requests
from typing import List
from fastapi import Depends, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db
from app.models.models import Project, UploadedFile
from app.utils.file_utils import (
    delete_all_files_in_dir,
    save_uploaded_files_with_given_id,
    merge_project_pdfs,
    ensure_pdf_has_text_layer
)
from app.utils.response import not_found

# LLM_API_BASE_URL = settings.LLM_API_BASE_URL


def upload_files_to_project_service(
    db: Session, project_id: str, files: List[UploadFile]
):
    # # Start/Reset upload timing at the moment POST upload is received
    # timing = db.query(UploadTiming).filter_by(project_id=project_id).first()
    # if timing:
    #     timing.started_at = now()
    #     timing.ready_ms = None
    # else:
    #     db.add(UploadTiming(project_id=project_id, started_at=now()))
    # db.commit()

    uploaded_files, failed_files = [], []

    try:

         # 🔍 Kiểm tra project có tồn tại không
        project = db.query(Project).filter(Project.id == project_id).first()
        if not project:
            return not_found(message="Project không tồn tại")
        # 1) Xoá bản ghi cũ

        db.query(UploadedFile).filter(UploadedFile.project_id == project_id).delete()

        # 2. Xoá thư mục cũ trên đĩa
        project_dir = os.path.join("app/static/project_files", project_id)
        delete_all_files_in_dir(project_dir)

        # 3. Lưu file mới
        saved_paths = save_uploaded_files_with_given_id(project_id, files)
        root = "app"

        for up_file, path in zip(files, saved_paths):
            if not path:
                failed_files.append(up_file.filename)
                continue

            rel_path = os.path.relpath(path, start=root)
            db.add(
                UploadedFile(
                    project_id=project_id,
                    file_name=os.path.basename(path),
                    file_path=rel_path,
                )
            )
            uploaded_files.append(os.path.basename(path))

        # 3.1. Nếu có file Excel, chuyển từng sheet thành PDF rồi gộp lại (tham khảo excel_preprocessing)
        try:
            from excel_preprocessing.excel_processing import (
                excel_to_combined_pdf_libreoffice,
                excel_to_combined_pdf_excel,
                excel_to_pdf_libreoffice_direct,
            )
            import sys
        except Exception:
            excel_to_combined_pdf_libreoffice = None  # type: ignore
            excel_to_combined_pdf_excel = None  # type: ignore
            excel_to_pdf_libreoffice_direct = None  # type: ignore

        EXCEL_EXTS = {".xls", ".xlsx", ".xlsm", ".xlsb"}
        for saved in list(saved_paths):
            if not saved:
                continue
            name_lower = saved.lower()
            _, ext = os.path.splitext(name_lower)
            if ext not in EXCEL_EXTS:
                continue

            try:
                base_name = os.path.splitext(os.path.basename(saved))[0]
                out_pdf = os.path.join(project_dir, f"{base_name}_merged.pdf")

                # Chọn engine theo nền tảng: Windows → Excel COM; còn lại → LibreOffice
                if ext == ".xlsb":
                    # Với .xlsb: dùng Excel COM trên Windows; non-Windows dùng LibreOffice direct mode
                    if sys.platform.startswith("win") and excel_to_combined_pdf_excel:
                        excel_to_combined_pdf_excel(saved, out_pdf)
                    elif excel_to_pdf_libreoffice_direct:
                        excel_to_pdf_libreoffice_direct(saved, out_pdf)
                    else:
                        raise RuntimeError(
                            "Thiếu engine chuyển đổi Excel→PDF cho .xlsb (LibreOffice/Excel)."
                        )
                else:
                    if sys.platform.startswith("win") and excel_to_combined_pdf_excel:
                        excel_to_combined_pdf_excel(saved, out_pdf)
                    elif excel_to_combined_pdf_libreoffice:
                        excel_to_combined_pdf_libreoffice(saved, out_pdf)
                    else:
                        raise RuntimeError(
                            "Thiếu engine chuyển đổi Excel→PDF (LibreOffice/Excel)."
                        )

                # OCR nếu cần, tránh lỗi nếu thiếu ocrmypdf
                try:
                    ensure_pdf_has_text_layer(out_pdf)
                except Exception as e:
                    print(e)
                    pass

                # Lưu record PDF sinh ra vào DB
                rel_pdf = os.path.relpath(out_pdf, start=root)
                db.add(
                    UploadedFile(
                        project_id=project_id,
                        file_name=os.path.basename(out_pdf),
                        file_path=rel_pdf
                    )
                )
                uploaded_files.append(os.path.basename(out_pdf))
            except Exception as ex:
                failed_files.append(os.path.basename(saved))
                # Không fail toàn bộ; tiếp tục với file khác
                print(f"[WARN] Excel→PDF failed for {saved}: {ex}")

        db.commit()

        # 4. Merge PDF
        merge_project_pdfs(project_id)

        # # 6. POST project_id tới server LLM  ──────────────────────── NEW
        # try:
        #     llm_resp = requests.post(
        #         f"{LLM_API_BASE_URL}/api/upload/merged-pdf/{project_id}",
        #         json={"project_id": project_id},
        #         timeout=10,
        #     )
        #     llm_resp.raise_for_status()
        # except Exception as ex:
        #     # Không phá hỏng luồng chính – chỉ log
        #     logging.warning("LLM sync failed for project %s: %s", project_id, ex)

        return {
            "status": "success",
            "message": "Upload thành công",
            "uploaded_files": uploaded_files,
            "failed_files": failed_files,
        }

    except Exception as e:
        db.rollback()
        print(e)
        return {
            "status": "error",
            "message": "Upload thất bại",
            "error": str(e),
            "failed_files": [
                f.filename for f in files if f.filename not in uploaded_files
            ],
        }

def get_project_file_id(project_id: str, db: Session = Depends(get_db)) -> str:
    file_id_map_path = Path("logs/file_id_map.json")
    if file_id_map_path.exists():
        with open(file_id_map_path, "r", encoding="utf-8") as f:
            file_id_map = json.load(f)
        if project_id in file_id_map:
            return file_id_map[project_id]
    
    raise HTTPException(status_code=404, detail="Không tìm thấy file_id cho project này")


