import os

from typing import List

from fastapi import  HTTPException
from sqlalchemy.orm import Session

from app.api.msds import intake_msds
from app.schemas.schemas import ChemicalIn, MsdsCreateResult, MsdsIn         # chuẩn Session dependency của bạn


# ============================== UTILS ==============================
def uniq_keep_order(xs: List[str]) -> List[str]:
    seen, out = set(), []
    for x in xs:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out

def merge_project_pdfs(project_id: str) -> str:
    path = os.path.join("app", "static", "merged_pdfs", str(project_id), f"merged_{project_id}.pdf")
    if not os.path.exists(path):
        raise HTTPException(status_code=400, detail=f"Không tìm thấy merged PDF: {path}")
    return path

def import_msds_from_results(project_id: str, results: List[dict], db: Session) -> List[dict]:
    """
    Import dữ liệu CAS từ results (output của extract_cas_from_merged_pdf_service_mock)
    vào DB thông qua intake_msds.
    """
    imported = []

    for item in results:
        payload = MsdsIn(
            project_id=project_id,
            product_name=item.get("ProductName"),
            description="Imported from CAS extract results",
            chemical=[
                ChemicalIn(
                    chemical_name=None,
                    cas_number=cas,
                    role="Active"
                )
                for cas in item.get("CasNoList", [])
            ]
        )

        # gọi trực tiếp intake_msds
        result: MsdsCreateResult = intake_msds(payload, db)
        imported.append(result.model_dump())

    return imported
