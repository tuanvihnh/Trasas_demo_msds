# app/utils/download.py
from pathlib import Path
from fastapi import HTTPException

BASE_DIR = Path(__file__).resolve().parents[2]
STATIC_ROOT = BASE_DIR / "app/static"
PROJECT_FILES_ROOT = STATIC_ROOT / "project_files"

def resolve_file(project_id: int, filename: str) -> Path:
    safe = Path(filename).name  # chặn ../
    return PROJECT_FILES_ROOT / str(project_id) / safe
# def _resolve_fs_path(db_path: str) -> Path:
#     # db_path có thể là "55/filename.pdf" hoặc "static/project_files/55/filename.pdf"
#     p = Path(db_path.replace("\\", "/"))
#     if "static/project_files" in p.as_posix():
#         p = Path(*p.parts[p.parts.index("static"):])  # cắt từ static/...
#         p = (BASE_DIR / p).resolve()
#     else:
#         p = (UPLOAD_ROOT / p).resolve()

#     # chặn traversal
#     if UPLOAD_ROOT not in p.parents and p != UPLOAD_ROOT:
#         raise HTTPException(status_code=400, detail="invalid path")

#     if not p.is_file():
#         raise HTTPException(status_code=404, detail="file not found on disk")
#     return p

# def _build_download_url(project_id: int, filename: str) -> str:
#     # URL FE dùng để tải (đã mount StaticFiles("/static", ...))
#     return f"/static/project_files/{project_id}/{filename}"
