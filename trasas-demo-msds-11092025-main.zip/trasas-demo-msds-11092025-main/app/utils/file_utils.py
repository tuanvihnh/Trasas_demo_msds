# File: app/utils/file_utils.py

import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional

from fastapi import UploadFile
from pypdf import PdfReader, PdfWriter

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
# STORAGE_DIR = os.path.join(BASE_DIR, "app/static/project_files")
STORAGE_DIR = os.path.join(BASE_DIR, "static", "project_files") 

def _pdf_has_text(file_path: str) -> bool:
    try:
        reader = PdfReader(file_path)
        for page in reader.pages:
            txt = page.extract_text() or ""
            if txt.strip():
                return True
    except Exception:
        return False
    return False


def ensure_pdf_has_text_layer(file_path: str, lang: str = "eng+vie") -> None:
    if _pdf_has_text(file_path):
        return
    if shutil.which("ocrmypdf") is None:
        raise RuntimeError("ocrmypdf is not installed")
    tmp_out = Path(file_path).with_suffix(".ocr.pdf")
    cmd = [
        "ocrmypdf",
        "--force-ocr",
        "--optimize",
        "0",
        "--rotate-pages",
        "--deskew",
        "--language",
        lang,
        file_path,
        str(tmp_out),
    ]
    subprocess.run(cmd, check=True)
    os.replace(tmp_out, file_path)


def save_uploaded_files_with_given_id(
    project_id: str, files: List[UploadFile]
) -> List[Optional[str]]:
    saved_paths = []
    for file in files:
        try:
            folder = os.path.join("app/static/project_files", project_id)
            os.makedirs(folder, exist_ok=True)
            file_path = os.path.join(folder, file.filename)
            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            if file_path.lower().endswith(".pdf"):
                ensure_pdf_has_text_layer(file_path)
            saved_paths.append(file_path)
        except Exception:
            saved_paths.append(None)
    return saved_paths


import os


def merge_project_pdfs(project_id: str):
    folder = os.path.join("app/static/merged_pdfs", project_id)
    os.makedirs(folder, exist_ok=True)
    merged_pdf_path = os.path.join(folder, f"merged_{project_id}.pdf")
    project_dir = os.path.join("app/static/project_files", project_id)

    # Lấy danh sách file .pdf (bỏ qua file đã gộp trước đó)
    pdf_files = [
        os.path.join(project_dir, f)
        for f in os.listdir(project_dir)
        if f.lower().endswith(".pdf") and not f.startswith("merged_")
    ]

    if not pdf_files:
        print(f" Không có file PDF nào để gộp cho project {project_id}")
        return

    if len(pdf_files) == 1:
        shutil.copyfile(pdf_files[0], merged_pdf_path)
    else:
        pdf_writer = PdfWriter()
        for pdf in sorted(pdf_files):
            try:
                reader = PdfReader(pdf)
                for page in reader.pages:
                    pdf_writer.add_page(page)
            except Exception as e:
                print(f" Lỗi khi thêm {pdf}: {e}")
        with open(merged_pdf_path, "wb") as out_f:
            pdf_writer.write(out_f)
    print(f"✅ Đã gộp PDF: {merged_pdf_path}")


from app.core.config import settings  # nếu cần lấy thư mục lưu


def merge_pdfs_in_project(project_id: str):
    """
    Gộp tất cả các file PDF trong project thành 1 file duy nhất.
    Lưu vào thư mục: app/merged_pdfs/{project_id}_merged.pdf
    """
    base_dir = "app/project_files"
    output_dir = "app/merged_pdfs"
    os.makedirs(output_dir, exist_ok=True)

    folder_path = os.path.join(base_dir, project_id)
    output_path = os.path.join(output_dir, f"{project_id}_merged.pdf")

    if not os.path.exists(folder_path):
        raise FileNotFoundError(f"Không tìm thấy thư mục: {folder_path}")

    files = [f for f in os.listdir(folder_path) if f.lower().endswith(".pdf")]
    if not files:
        raise ValueError("Không có file PDF nào trong project.")

    if len(files) == 1:
        shutil.copyfile(os.path.join(folder_path, files[0]), output_path)
    else:
        pdf_writer = PdfWriter()
        for filename in sorted(files):
            file_path = os.path.join(folder_path, filename)
            try:
                reader = PdfReader(file_path)
                for page in reader.pages:
                    pdf_writer.add_page(page)
            except Exception as e:
                raise RuntimeError(f"Lỗi khi đọc file {filename}: {str(e)}")

        with open(output_path, "wb") as f_out:
            pdf_writer.write(f_out)

    return output_path


def delete_all_files_in_dir(directory_path: str):
    if not os.path.exists(directory_path):
        return
    for filename in os.listdir(directory_path):
        file_path = os.path.join(directory_path, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f"Lỗi khi xoá {file_path}: {e}")


UPLOAD_DIRECTORY = os.path.join("project_files")
MERGED_PDF_DIR = os.path.join("app", "merged_pdfs")


def delete_all_project_files(project_id: str):
    # Xoá thư mục chứa các file PDF của project
    project_folder = os.path.join(UPLOAD_DIRECTORY, project_id)
    if os.path.exists(project_folder):
        shutil.rmtree(project_folder)

    # Xoá file merged
    merged_path = os.path.join(MERGED_PDF_DIR, f"{project_id}_merged.pdf")
    if os.path.exists(merged_path):
        os.remove(merged_path)
