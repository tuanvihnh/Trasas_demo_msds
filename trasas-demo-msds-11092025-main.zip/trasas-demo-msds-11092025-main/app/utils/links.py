from datetime import date, datetime
from decimal import Decimal
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional, List
from sqlalchemy.sql import text as sql_text
from fastapi import APIRouter, Depends, HTTPException, Path, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.utils.response import not_found, ok, fail
from app.schemas.common import ResponseEnvelope, Paginated, PageMeta
from app.models.models import Chemical, ChemicalMapping, RegulationAppendix



def _conv(v: Any):
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, Decimal):
        return float(v)
    return v

def _sa_to_dict(obj) -> Dict[str, Any]:
    return {c.name: _conv(getattr(obj, c.name)) for c in obj.__table__.columns}


def _resolve_chemical_id(db: Session, chemical_id: Optional[int], cas_no: Optional[str]) -> Optional[int]:
    if chemical_id:
        return chemical_id
    if cas_no:
        chem = db.query(Chemical.id).filter(Chemical.cas_no == cas_no).first()
        if not chem:
            return not_found(message=f"CAS not found: {cas_no}")
        return chem[0]
    return None


def _resolve_chem_id(db: Session, chem_id: int | None, cas_no: str | None) -> int | None:
    if chem_id: return chem_id
    if cas_no:
        r = db.query(Chemical.id).filter(Chemical.cas_no == cas_no).first()
        if not r: return not_found(message="CAS not found")
        return r[0]
    return None

def _resolve_regapp_id(db: Session, regapp_id: int | None, code: str | None) -> int | None:
    if regapp_id: return regapp_id
    if code:
        r = db.query(RegulationAppendix.id).filter(RegulationAppendix.code == code).first()
        if not r: return not_found(message="RegulationAppendix code not found")
        return r[0]
    return None