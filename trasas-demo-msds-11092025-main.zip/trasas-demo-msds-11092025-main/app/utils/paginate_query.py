def paginate_query(query, page: int = 1, size: int = 10):
    if page < 1:
        page = 1
    if size < 1:
        size = 1
    offset = (page - 1) * size
    return query.offset(offset).limit(size)

