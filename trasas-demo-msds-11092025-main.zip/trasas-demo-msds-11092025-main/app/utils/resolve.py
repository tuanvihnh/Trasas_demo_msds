from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.models.models import Regulation
from app.models.models import Appendix
from app.utils.response import conflict, not_found

def resolve_regulation_id(db: Session, regulation_id: int = None, regulation_code: str = None) -> int:
    if regulation_id:
        r = db.query(Regulation).filter(Regulation.id == regulation_id).first()
        if not r:
            # raise HTTPException(status_code=404, detail="regulation_id not found")
            return not_found("regulation_id not found")
        return r.id
    if regulation_code:
        r = db.query(Regulation).filter(Regulation.code == regulation_code).first()
        if not r:
            # raise HTTPException(status_code=404, detail="regulation_code not found")
            return not_found("regulation_code not found")
        return r.id
    # raise HTTPException(status_code=400, detail="Either regulation_id or regulation_code is required")
    return not_found("Either regulation_id or regulation_code is required")
def resolve_appendix_id(db: Session, appendix_id: int = None, regulation_code: str = None, appendix_title: str = None) -> int:
    if appendix_id:
        a = db.query(Appendix).filter(Appendix.id == appendix_id).first()
        if not a:
            # raise HTTPException(status_code=404, detail="appendix_id not found")
            return not_found("appendix_id not found")
        return a.id
    if regulation_code and appendix_title:
        q = (db.query(Appendix.id)
               .join(Regulation, Regulation.id == Appendix.regulation_id)
               .filter(Regulation.code == regulation_code, Appendix.title == appendix_title))
        rows = q.all()
        if not rows:
            # raise HTTPException(status_code=404, detail="No appendix matches (regulation_code, appendix_title)")
            return not_found("No appendix matches (regulation_code, appendix_title)")
        if len(rows) > 1:
            return conflict("Multiple appendix matched; please specify appendix_id")
            # raise HTTPException(status_code=409, detail="Multiple appendix matched; please specify appendix_id")
        return rows[0][0]
    # raise HTTPException(status_code=400, detail="appendix_id or (regulation_code & appendix_title) required")
    return not_found("appendix_id or (regulation_code & appendix_title) required")