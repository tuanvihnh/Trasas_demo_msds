# app/utils/response.py
from typing import Any, Optional, Dict
from fastapi.encoders import jsonable_encoder
from starlette.responses import JSONResponse

def envelope(
    success: bool,
    message: str = "",
    data: Any = None,
    status_code: int = 200,
    headers: Optional[Dict[str, str]] = None,
):
    if success:
        status = "success"
    else:
        status = "error"
    payload = {
        "status": status,  # CHUẨN HOÁ: dùng "success" và "fail"
        "message": message,  # CHUẨN HOÁ: dùng "message" (không "messege")
        "data": jsonable_encoder(data),  # <— quan trọng
    }
    return JSONResponse(content=payload, status_code=status_code, headers=headers)

def ok(data: Any = None, message: str = "OK", http_status: int = 200, headers: Optional[Dict[str, str]] = None):
    return envelope(True, message, data, http_status, headers)

def fail(message: str = "Error", http_status: int = 400, data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, http_status, headers)

def not_found(message: str = "Not Found", data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, 404, headers)

def unauthorized(message: str = "Unauthorized", data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, 401, headers)

def forbidden(message: str = "Forbidden", data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, 403, headers)
def conflict(message: str = "Conflict", data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, 409, headers)
def server_error(message: str = "Internal Server Error", data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, 500, headers)
def bad_request(message: str = "Bad Request", data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, 400, headers)
def validation_error(message: str = "Validation Error", data: Any = None, headers: Optional[Dict[str, str]] = None):
    return envelope(False, message, data, 422, headers)