import os
import subprocess
import tempfile
import shutil
from pathlib import Path
import argparse
import sys

# Optional: pandas is convenient but not strictly required at import time
try:
    import pandas as pd
except Exception:  # pragma: no cover - allow running help/CLI without pandas installed
    pd = None

# Optional: for freezing formulas to values
try:  # pragma: no cover
    from openpyxl import load_workbook
except Exception:  # pragma: no cover
    load_workbook = None  # type: ignore

# Prefer pypdf (listed in requirements) with fallback to PyPDF2
try:  # pragma: no cover
    from pypdf import PdfWriter, PdfReader
except Exception:  # pragma: no cover
    try:
        from PyPDF2 import PdfWriter, PdfReader  # type: ignore
    except Exception as e:  # pragma: no cover
        raise ImportError(
            "Neither 'pypdf' nor 'PyPDF2' is available. Install one to merge PDFs."
        ) from e

import shutil as _shutil


def _find_soffice():
    # Ưu tiên PATH
    p = _shutil.which("soffice")
    if p:
        return p
    # macOS cài mặc định
    mac_path = "/Applications/LibreOffice.app/Contents/MacOS/soffice"
    if os.path.exists(mac_path):
        return mac_path
    raise FileNotFoundError(
        "Không tìm thấy 'soffice'. Hãy cài LibreOffice hoặc thêm vào PATH."
    )


def _is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


# ===== Excel COM (Windows) support =====
def _import_win32com():  # pragma: no cover - platform specific
    if not _is_windows():
        raise EnvironmentError(
            "Excel COM engine requires Windows. Use --engine libreoffice on this platform."
        )
    try:
        import win32com.client as win32  # type: ignore
        import pythoncom  # type: ignore

        return win32, pythoncom
    except Exception as e:
        raise ImportError(
            "pywin32 is required for --engine excel. Install it: pip install pywin32"
        ) from e


def _excel_visible_sheets_com(wb):  # pragma: no cover - platform specific
    visible = []
    try:
        for ws in wb.Worksheets:
            # xlSheetVisible == -1, xlSheetHidden == 0, xlSheetVeryHidden == 2
            if int(ws.Visible) == -1:
                visible.append(ws)
    except Exception:
        pass
    return visible


def excel_to_pdf_excel_com(
    xlsx_path: str,
    out_pdf_path: str,
    *,
    recalc: bool = True,
):  # pragma: no cover - platform specific
    """Export entire workbook to a single PDF via Microsoft Excel COM."""
    win32, pythoncom = _import_win32com()
    pythoncom.CoInitialize()
    excel = None
    wb = None
    try:
        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        wb = excel.Workbooks.Open(str(Path(xlsx_path).resolve()), ReadOnly=True)

        if recalc:
            try:
                wb.RefreshAll()
                try:
                    excel.CalculateUntilAsyncQueriesDone()
                except Exception:
                    pass
                excel.CalculateFullRebuild()
            except Exception:
                pass

        out_pdf = str(Path(out_pdf_path).resolve())
        # Type=0 (xlTypePDF), Quality=0 (xlQualityStandard)
        wb.ExportAsFixedFormat(0, out_pdf, 0, True, False)
    finally:
        try:
            if wb is not None:
                wb.Close(SaveChanges=False)
        except Exception:
            pass
        try:
            if excel is not None:
                excel.Quit()
        except Exception:
            pass
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def excel_split_sheets_to_pdfs_excel(
    xlsx_path: str,
    out_dir: str,
    *,
    fit_to_page: bool = True,
    recalc: bool = True,
):  # pragma: no cover - platform specific
    """Export each visible sheet to a separate single-page PDF via Excel COM.

    Returns list of produced PDF paths.
    """
    win32, pythoncom = _import_win32com()
    pythoncom.CoInitialize()
    excel = None
    wb = None
    produced = []
    try:
        out_dir_path = Path(out_dir)
        out_dir_path.mkdir(parents=True, exist_ok=True)

        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        wb = excel.Workbooks.Open(str(Path(xlsx_path).resolve()), ReadOnly=True)

        if recalc:
            try:
                wb.RefreshAll()
                try:
                    excel.CalculateUntilAsyncQueriesDone()
                except Exception:
                    pass
                excel.CalculateFullRebuild()
            except Exception:
                pass

        sheets = _excel_visible_sheets_com(wb)
        base = Path(xlsx_path).resolve().stem
        for i, ws in enumerate(sheets, 1):
            try:
                if fit_to_page:
                    ps = ws.PageSetup
                    ps.Zoom = False
                    ps.FitToPagesWide = 1
                    ps.FitToPagesTall = 1
            except Exception:
                pass

            safe = _sanitize_sheet_name(str(ws.Name))
            out_pdf = out_dir_path / f"{base}_{i:02d}_{safe}.pdf"
            print(f"[XL] Export sheet: {ws.Name} -> {out_pdf.name}")
            ws.ExportAsFixedFormat(0, str(out_pdf), 0, True, False)
            produced.append(str(out_pdf))
    finally:
        try:
            if wb is not None:
                wb.Close(SaveChanges=False)
        except Exception:
            pass
        try:
            if excel is not None:
                excel.Quit()
        except Exception:
            pass
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass
    return produced


def excel_to_combined_pdf_excel(
    xlsx_path: str,
    out_pdf_path: str,
    *,
    fit_to_page: bool = True,
    recalc: bool = True,
):  # pragma: no cover - platform specific
    """Export visible sheets to separate PDFs via Excel COM and merge into one."""
    tmpdir = tempfile.mkdtemp()
    try:
        pdfs = excel_split_sheets_to_pdfs_excel(
            xlsx_path, tmpdir, fit_to_page=fit_to_page, recalc=recalc
        )
        writer = PdfWriter()
        for p in pdfs:
            if hasattr(writer, "append"):
                writer.append(p)  # type: ignore[attr-defined]
            else:
                reader = PdfReader(p)
                for page in reader.pages:
                    writer.add_page(page)
        writer.write(out_pdf_path)
        print(f"[DONE] File PDF gộp (Excel): {out_pdf_path}")
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def export_sheet_to_pdf_libreoffice(xlsx_path: str, sheet_name: str, out_pdf: str):
    """
    Tạo workbook tạm chỉ có 1 sheet rồi export bằng LibreOffice ở chế độ headless.
    Dùng profile tạm để tránh xung đột user profile.
    """
    xlsx_path = Path(xlsx_path).resolve()
    out_pdf = Path(out_pdf).resolve()
    soffice = _find_soffice()

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        tmp_xlsx = tmpdir_path / "__single_sheet__.xlsx"

        # Lưu 1 workbook chỉ gồm sheet cần in (dùng openpyxl thông qua pandas)
        if pd is None:
            raise ImportError(
                "pandas is required for the per-sheet export path. Please install pandas."
            )
        with pd.ExcelWriter(tmp_xlsx, engine="openpyxl") as writer:
            df = pd.read_excel(xlsx_path, sheet_name=sheet_name, dtype=str)
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            # Ensure 1 sheet -> 1 page by using Fit to 1x1 pages
            try:
                ws = writer.sheets[sheet_name]
                ws.page_setup.fitToWidth = 1
                ws.page_setup.fitToHeight = 1
                # Some consumers require this flag for FitToWidth/Height to apply
                if hasattr(ws, "sheet_properties") and hasattr(
                    ws.sheet_properties, "pageSetUpPr"
                ):
                    pr = ws.sheet_properties.pageSetUpPr
                    if pr is not None:
                        pr.fitToPage = True
            except Exception:
                # Best-effort; if openpyxl interface changes, proceed without hard fail
                pass

        # Tạo profile LibreOffice tạm (tránh xung đột)
        lo_profile = tmpdir_path / "lo_profile"
        lo_profile.mkdir(parents=True, exist_ok=True)
        lo_profile_uri = f"file://{lo_profile.as_posix()}"

        # Một số phiên bản cần HOME là thư mục hợp lệ
        env = os.environ.copy()
        env.setdefault("HOME", str(tmpdir_path))

        # Gợi ý: Không dùng --infilter; để LO tự nhận xlsx→Calc, export filter là calc_pdf_Export
        cmd = [
            soffice,
            "--headless",
            "--nologo",
            "--nodefault",
            "--nolockcheck",
            "--norestore",
            f"-env:UserInstallation={lo_profile_uri}",
            "--convert-to",
            "pdf:calc_pdf_Export",  # hoặc chỉ "pdf"
            "--outdir",
            str(tmpdir_path),
            str(tmp_xlsx),
        ]

        # Bắt stdout/stderr để debug khi lỗi
        proc = subprocess.run(cmd, capture_output=True, text=True, env=env)
        if proc.returncode != 0:
            raise RuntimeError(
                "LibreOffice export failed.\n"
                f"CMD: {' '.join(cmd)}\n"
                f"STDOUT:\n{proc.stdout}\n\nSTDERR:\n{proc.stderr}"
            )

        produced_pdf = tmpdir_path / "__single_sheet__.pdf"
        if not produced_pdf.exists():
            # fallback nếu tên khác
            candidates = sorted(tmpdir_path.glob("*.pdf"))
            if not candidates:
                raise FileNotFoundError("LibreOffice không tạo được PDF từ sheet.")
            produced_pdf = candidates[0]

        shutil.move(str(produced_pdf), str(out_pdf))


def _sanitize_sheet_name(name: str) -> str:
    # Safe filename from sheet name
    import re

    s = name.strip()
    # Replace invalid filename chars with underscore
    s = re.sub(r"[\\/:*?\"<>|]", "_", s)
    # Collapse whitespace
    s = re.sub(r"\s+", "_", s)
    # Limit length to something reasonable
    return s[:80] if len(s) > 80 else s


def _visible_sheet_names(xlsx_path: str) -> list[str]:
    names: list[str] = []
    try:
        if load_workbook is None:
            raise ImportError
        wb = load_workbook(xlsx_path, read_only=True, data_only=False)
        for ws in wb.worksheets:
            state = getattr(ws, "sheet_state", "visible")
            if state == "visible":
                names.append(ws.title)
        return names
    except Exception:
        # Fallback: use pandas to enumerate when openpyxl unavailable
        if pd is None:
            return names
        xls = pd.ExcelFile(xlsx_path)
        # pandas cannot detect hidden; return all names as last resort
        return xls.sheet_names


def excel_split_sheets_to_pdfs(xlsx_path: str, out_dir: str | None = None) -> list[str]:
    """Export each sheet to a separate single-page PDF.

    Returns list of produced PDF file paths.
    """
    if pd is None:
        raise ImportError(
            "pandas is required to enumerate sheets for export. Please install pandas."
        )
    xlsx_path = str(Path(xlsx_path))
    base = Path(xlsx_path).resolve()
    out_dir = out_dir or str(base.parent)
    os.makedirs(out_dir, exist_ok=True)

    sheet_names = _visible_sheet_names(xlsx_path)
    produced: list[str] = []
    for i, sh in enumerate(sheet_names, 1):
        safe = _sanitize_sheet_name(sh)
        out_pdf = Path(out_dir) / f"{base.stem}_{i:02d}_{safe}.pdf"
        print(f"[LO] Export sheet: {sh} -> {out_pdf.name}")
        export_sheet_to_pdf_libreoffice(xlsx_path, sh, str(out_pdf))
        produced.append(str(out_pdf))
    return produced


def excel_to_combined_pdf_libreoffice(xlsx_path: str, out_pdf_path: str):
    """Export visible sheets only, one page per sheet, and merge into a single PDF.

    This path renders each visible sheet as values (not formulas) into a
    temporary one-sheet workbook so cross-sheet references won't break.
    Hidden sheets are skipped.
    """
    sheet_names = _visible_sheet_names(xlsx_path)
    if not sheet_names:
        raise ValueError("No visible sheets to export.")

    tmpdir = tempfile.mkdtemp()
    tmp_pdfs: list[str] = []
    try:
        for i, sh in enumerate(sheet_names, 1):
            out_pdf = Path(tmpdir) / f"{i:02d}_{_sanitize_sheet_name(sh)}.pdf"
            print(f"[LO] Export sheet: {sh}")
            export_sheet_to_pdf_libreoffice(xlsx_path, sh, str(out_pdf))
            tmp_pdfs.append(str(out_pdf))

        writer = PdfWriter()
        for p in tmp_pdfs:
            if hasattr(writer, "append"):
                writer.append(p)  # type: ignore[attr-defined]
            else:
                reader = PdfReader(p)
                for page in reader.pages:
                    writer.add_page(page)
        writer.write(out_pdf_path)
        print(f"[DONE] File PDF gộp: {out_pdf_path}")
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def _default_output_path(xlsx_path: str) -> str:
    p = Path(xlsx_path)
    return str(p.with_suffix("")) + "_merged.pdf"


def _default_output_path_direct(xlsx_path: str) -> str:
    p = Path(xlsx_path)
    return str(p.with_suffix(".pdf"))


def excel_to_pdf_libreoffice_direct(
    xlsx_path: str, out_pdf_path: str, freeze_formulas: bool = False
):
    """Call LibreOffice directly to convert the entire workbook to a single PDF,
    matching the behavior of:
        soffice --headless --convert-to pdf <file.xlsx>
    """
    soffice = _find_soffice()
    xlsx_path = Path(xlsx_path).resolve()
    out_pdf_path = Path(out_pdf_path).resolve()

    outdir = out_pdf_path.parent
    outdir.mkdir(parents=True, exist_ok=True)

    def _lo_convert(src_xlsx: Path):
        # Convert given XLSX using LibreOffice headless
        nonlocal out_pdf_path
        outdir = out_pdf_path.parent
        expected_name = src_xlsx.with_suffix(".pdf").name

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir_path = Path(tmpdir)
            lo_profile = tmpdir_path / "lo_profile"
            lo_profile.mkdir(parents=True, exist_ok=True)
            lo_profile_uri = f"file://{lo_profile.as_posix()}"

            env = os.environ.copy()
            env.setdefault("HOME", str(tmpdir_path))

            cmd = [
                soffice,
                "--headless",
                "--nologo",
                "--nodefault",
                "--nolockcheck",
                "--norestore",
                f"-env:UserInstallation={lo_profile_uri}",
                "--convert-to",
                "pdf:calc_pdf_Export",
                "--outdir",
                str(outdir),
                str(src_xlsx),
            ]

            print(f"[LO] Direct convert: {' '.join(cmd)}")
            proc = subprocess.run(cmd, capture_output=True, text=True, env=env)
            if proc.returncode != 0:
                raise RuntimeError(
                    "LibreOffice direct export failed.\n"
                    f"CMD: {' '.join(cmd)}\n"
                    f"STDOUT:\n{proc.stdout}\n\nSTDERR:\n{proc.stderr}"
                )

            produced = outdir / expected_name
            if not produced.exists():
                candidates = [
                    p for p in outdir.glob("*.pdf") if p.stem == src_xlsx.stem
                ]
                if candidates:
                    produced = candidates[0]
                else:
                    raise FileNotFoundError(
                        "LibreOffice did not create the expected PDF."
                    )

            if produced != out_pdf_path:
                if out_pdf_path.exists():
                    out_pdf_path.unlink()
                produced.rename(out_pdf_path)

    if freeze_formulas:
        if load_workbook is None:
            raise ImportError(
                "openpyxl is required for --freeze-formulas (convert formulas to values)."
            )
        # Create a temporary values-only copy (uses cached results stored in the file)
        with tempfile.TemporaryDirectory() as tmp_values_dir:
            tmp_values = Path(tmp_values_dir) / "__values_only__.xlsx"
            wb = load_workbook(xlsx_path, data_only=True)
            wb.save(tmp_values)
            _lo_convert(tmp_values)
    else:
        _lo_convert(xlsx_path)
    print(f"[DONE] Direct PDF: {out_pdf_path}")


def main():  # pragma: no cover - CLI utility
    parser = argparse.ArgumentParser(
        description=(
            "Convert an Excel workbook to a single merged PDF (one page per sheet) "
            "using headless LibreOffice (Calc)."
        )
    )
    parser.add_argument("input", help="Path to the input .xlsx file")
    parser.add_argument(
        "-o",
        "--out",
        dest="out",
        help=(
            "Output PDF path. Defaults: direct mode → <input>.pdf; "
            "per-sheet mode → <input>_merged.pdf"
        ),
    )
    parser.add_argument(
        "--mode",
        choices=["direct", "per-sheet", "split"],
        default="direct",
        help=(
            "Conversion mode: 'direct' to mimic 'soffice --convert-to pdf' "
            "or 'per-sheet' to export each sheet as a single page and merge, "
            "or 'split' to export each sheet to its own PDF file."
        ),
    )
    parser.add_argument(
        "--engine",
        choices=["libreoffice", "excel"],
        default=("excel" if _is_windows() else "libreoffice"),
        help=(
            "Rendering engine: 'libreoffice' (cross-platform) or 'excel' (Windows, uses COM). "
            "Default: excel on Windows, otherwise libreoffice."
        ),
    )
    parser.add_argument(
        "--out-dir",
        dest="out_dir",
        help=(
            "Output directory for --mode split. Defaults to the input file's directory."
        ),
    )
    parser.add_argument(
        "--freeze-formulas",
        action="store_true",
        help=(
            "Convert formulas to their cached values before export (uses openpyxl). "
            "Useful when you want to ensure static values are printed."
        ),
    )
    parser.add_argument(
        "--fit-to-page",
        action="store_true",
        help=(
            "For per-sheet/split: force Fit-to-Page (1x1) when supported. "
            "With engine=excel, applies Excel PageSetup; with engine=libreoffice, handled via temp workbook."
        ),
    )
    parser.add_argument(
        "--no-recalc",
        action="store_true",
        help=("With engine=excel: skip recalculation/refresh before export."),
    )

    args = parser.parse_args()
    in_path = args.input
    if not os.path.exists(in_path):
        raise FileNotFoundError(f"Input Excel not found: {in_path}")

    if args.mode == "direct":
        out_path = args.out or _default_output_path_direct(in_path)
    elif args.mode == "per-sheet":
        out_path = args.out or _default_output_path(in_path)
    else:
        out_path = args.out  # not used; split uses out_dir
    if args.mode in {"direct", "per-sheet"}:
        out_dir = os.path.dirname(out_path) or "."
        os.makedirs(out_dir, exist_ok=True)

    if args.engine == "excel":
        recalc = not args.no_recalc
        if args.mode == "direct":
            print(f"[START][Excel] Excel → PDF (direct): {in_path} → {out_path}")
            excel_to_pdf_excel_com(in_path, out_path, recalc=recalc)
        elif args.mode == "per-sheet":
            print(f"[START][Excel] Excel → PDF merge: {in_path} → {out_path}")
            excel_to_combined_pdf_excel(
                in_path, out_path, fit_to_page=args.fit_to_page or False, recalc=recalc
            )
        else:
            out_dir = args.out_dir or os.path.dirname(in_path) or "."
            print(
                f"[START][Excel] Excel → PDFs split: {in_path} → {out_dir}/<name>_<sheet>.pdf"
            )
            files = excel_split_sheets_to_pdfs_excel(
                in_path, out_dir, fit_to_page=args.fit_to_page or False, recalc=recalc
            )
            print("[DONE] Split PDFs:")
            for f in files:
                print(f"  - {f}")
    else:
        if args.mode == "direct":
            print(f"[START] Excel → PDF (direct): {in_path} → {out_path}")
            excel_to_pdf_libreoffice_direct(
                in_path, out_path, freeze_formulas=args.freeze_formulas
            )
        elif args.mode == "per-sheet":
            print(f"[START] Excel → PDF merge: {in_path} → {out_path}")
            excel_to_combined_pdf_libreoffice(in_path, out_path)
        else:
            out_dir = args.out_dir or os.path.dirname(in_path) or "."
            print(
                f"[START] Excel → PDFs split: {in_path} → {out_dir}/<name>_<sheet>.pdf"
            )
            files = excel_split_sheets_to_pdfs(in_path, out_dir)
            print("[DONE] Split PDFs:")
            for f in files:
                print(f"  - {f}")


if __name__ == "__main__":  # pragma: no cover
    main()
